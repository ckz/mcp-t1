import pytest
from pydantic import BaseModel
from litellm import completion
from agents.utils.llm_function_calling import StructuredOutputInstructor
from services.bedrock_service import BedrockModel

# Test response model
class TestResponse(BaseModel):
    message: str
    score: int

def test_structured_output_instructor_initialization():
    instructor = StructuredOutputInstructor(TestResponse)
    assert instructor.response_model == TestResponse

def test_invoke_with_valid_response(monkeypatch):
    try:
        # Mock the instructor client
        class MockCompletions:
            def create(self, model, response_model, messages, fallbacks=None):
                # Use litellm mock_response
                response = completion(
                    model=model,
                    messages=messages,
                    mock_response='{"message": "Test message", "score": 100}'
                )
                # Convert the mock response to the expected type
                return TestResponse(message="Test message", score=100)

        class MockChat:
            def __init__(self):
                self.completions = MockCompletions()

        class MockClient:
            def __init__(self):
                self.chat = MockChat()

        # Apply the mock
        import instructor
        monkeypatch.setattr(instructor, 'from_litellm', lambda _: MockClient())
        
        instructor = StructuredOutputInstructor(TestResponse)
        response = instructor.invoke(
            model="gpt-3.5-turbo",
            prompt="Test prompt"
        )
        
        assert isinstance(response, TestResponse)
        assert response.message == "Test message"
        assert response.score == 100
        
    except Exception as e:
        pytest.fail(f"Error occurred: {e}")

def test_invoke_plus(monkeypatch):
    try:
        # Mock the instructor client
        class MockCompletions:
            def create(self, model, response_model, messages, fallbacks=None):
                # Use litellm mock_response
                response = completion(
                    model=model,
                    messages=messages,
                    mock_response='{"message": "Plus model response", "score": 90}'
                )
                # Convert the mock response to the expected type
                return TestResponse(message="Plus model response", score=90)

        class MockChat:
            def __init__(self):
                self.completions = MockCompletions()

        class MockClient:
            def __init__(self):
                self.chat = MockChat()

        # Apply the mock
        import instructor
        monkeypatch.setattr(instructor, 'from_litellm', lambda _: MockClient())
        
        instructor = StructuredOutputInstructor(TestResponse)
        response = instructor.invoke_plus("Test prompt")
        
        assert isinstance(response, TestResponse)
        assert response.message == "Plus model response"
        assert response.score == 90
        
    except Exception as e:
        pytest.fail(f"Error occurred: {e}")

def test_invoke_pro(monkeypatch):
    try:
        # Mock the instructor client
        class MockCompletions:
            def create(self, model, response_model, messages, fallbacks=None):
                # Use litellm mock_response
                response = completion(
                    model=model,
                    messages=messages,
                    mock_response='{"message": "Pro model response", "score": 95}'
                )
                # Convert the mock response to the expected type
                return TestResponse(message="Pro model response", score=95)

        class MockChat:
            def __init__(self):
                self.completions = MockCompletions()

        class MockClient:
            def __init__(self):
                self.chat = MockChat()

        # Apply the mock
        import instructor
        monkeypatch.setattr(instructor, 'from_litellm', lambda _: MockClient())
        
        instructor = StructuredOutputInstructor(TestResponse)
        response = instructor.invoke_pro("Test prompt")
        
        assert isinstance(response, TestResponse)
        assert response.message == "Pro model response"
        assert response.score == 95
        
    except Exception as e:
        pytest.fail(f"Error occurred: {e}")

def test_invoke_with_invalid_response(monkeypatch):
    # Mock the instructor client
    class MockCompletions:
        def create(self, model, response_model, messages, fallbacks=None):
            # Use litellm mock_response with invalid data
            response = completion(
                model=model,
                messages=messages,
                mock_response='{"different_field": "Invalid data"}'
            )
            # This should raise a validation error since it doesn't match TestResponse
            return {"different_field": "Invalid data"}

    class MockChat:
        def __init__(self):
            self.completions = MockCompletions()

    class MockClient:
        def __init__(self):
            self.chat = MockChat()

    # Apply the mock
    import instructor
    monkeypatch.setattr(instructor, 'from_litellm', lambda _: MockClient())
    
    instructor = StructuredOutputInstructor(TestResponse)
    
    with pytest.raises(ValueError):
        response = instructor.invoke(
            model="gpt-3.5-turbo",
            prompt="Test prompt"
        )