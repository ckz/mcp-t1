import unittest
from unittest.mock import patch, MagicMock
from datetime import date
import pytest
from services.femini_service import FeminiAPIError
from agents.tools.campaign_spends_querier import CampaignSpendsQuerierTool
from services.constants import SLACK_USER_PREFIX

class TestCampaignSpendsQuerierTool(unittest.TestCase):
    def setUp(self):
        """Set up test environment before each test"""
        self.env_patcher = patch.dict('os.environ', {
            'FEMINI_API_KEY': 'test-api-key',
            'FEMINI_BASE_URL': 'https://femini.feedmob.com'
        })
        self.env_patcher.start()

    def tearDown(self):
        """Clean up test environment after each test"""
        self.env_patcher.stop()

    def test_init_web_user(self):
        """Test tool initialization with web user"""
        tool = CampaignSpendsQuerierTool(user_identifier="test@example.com")
        self.assertEqual(tool.service.platform, "web")
        self.assertEqual(tool.service.user_email, "test@example.com")

    def test_init_slack_user(self):
        """Test tool initialization with slack user"""
        tool = CampaignSpendsQuerierTool(user_identifier=f"{SLACK_USER_PREFIX}test@example.com")
        self.assertEqual(tool.service.platform, "slack")
        self.assertEqual(tool.service.user_email, "test@example.com")

    def test_init_invalid_email(self):
        """Test tool initialization with invalid email"""
        with self.assertRaises(ValueError) as context:
            CampaignSpendsQuerierTool(user_identifier="invalid-email")
        self.assertIn("Invalid email format", str(context.exception))

    @patch('services.femini_service.FeminiService.get_campaign_spends')
    def test_run_success_web_user(self, mock_get_spends):
        """Test successful campaign spends query with web user"""
        # Setup mock response with both data and source_url
        mock_response = {
            'data': {'spends': [{'client_id': 1, 'amount': 100}]},
            'source_url': 'https://femini.feedmob.com/campaign_spends?query[date_gteq]=2024-01-01'
        }
        mock_get_spends.return_value = mock_response

        tool = CampaignSpendsQuerierTool(user_identifier="test@example.com")
        result = tool._run(
            level="client",
            date_gteq="2024-01-01",
            date_lteq="2024-01-31",
            legacy_client_id_in=[1, 2],
            legacy_partner_id_in=[3, 4]
        )

        # Verify the complete response structure
        self.assertEqual(result, mock_response)
        
        mock_get_spends.assert_called_once_with(
            level="client",
            date_gteq="2024-01-01",
            date_lteq="2024-01-31",
            legacy_client_id_in=[1, 2],
            legacy_partner_id_in=[3, 4]
        )

    @patch('services.femini_service.FeminiService.get_campaign_spends')
    def test_run_success_slack_user(self, mock_get_spends):
        """Test successful campaign spends query with slack user"""
        # Setup mock response with both data and source_url
        mock_response = {
            'data': {'spends': [{'client_id': 1, 'amount': 100}]},
            'source_url': 'https://femini.feedmob.com/campaign_spends?query[date_gteq]=2024-01-01'
        }
        mock_get_spends.return_value = mock_response

        tool = CampaignSpendsQuerierTool(user_identifier=f"{SLACK_USER_PREFIX}test@example.com")
        result = tool._run(
            level="client",
            date_gteq="2024-01-01",
            date_lteq="2024-01-31"
        )

        # Verify the complete response structure
        self.assertEqual(result, mock_response)

    @patch('services.femini_service.FeminiService.get_campaign_spends')
    def test_run_api_error(self, mock_get_spends):
        """Test error handling in campaign spends query"""
        mock_get_spends.side_effect = FeminiAPIError(
            "API Error",
            status_code=500,
            response={"error": "Internal Server Error"}
        )

        tool = CampaignSpendsQuerierTool(user_identifier="test@example.com")
        with self.assertRaises(Exception) as context:
            tool._run(level="client")
        self.assertIn("Failed to fetch campaign spends", str(context.exception))

    @pytest.mark.asyncio
    async def test_arun(self):
        """Test async execution of the tool"""
        with patch('services.femini_service.FeminiService.get_campaign_spends') as mock_get_spends:
            # Setup mock response with both data and source_url
            mock_response = {
                'data': {'spends': [{'client_id': 1, 'amount': 100}]},
                'source_url': 'https://femini.feedmob.com/campaign_spends?query[date_gteq]=2024-01-01'
            }
            mock_get_spends.return_value = mock_response

            tool = CampaignSpendsQuerierTool(user_identifier="test@example.com")
            result = await tool._arun(
                level="client",
                date_gteq="2024-01-01",
                date_lteq="2024-01-31"
            )

            # Verify the complete response structure
            self.assertEqual(result, mock_response)

if __name__ == '__main__':
    unittest.main()