import unittest
from unittest.mock import patch, MagicMock
from datetime import date
import pytest
import requests
from services.femini_service import FeminiService, FeminiAPIError
from services.constants import SLACK_USER_PREFIX

class TestFeminiService(unittest.TestCase):
    def setUp(self):
        """Set up test environment before each test"""
        self.env_patcher = patch.dict('os.environ', {
            'FEMINI_API_KEY': 'test-api-key',
            'FEMINI_BASE_URL': 'https://femini.feedmob.com'
        })
        self.env_patcher.start()

    def tearDown(self):
        """Clean up test environment after each test"""
        self.env_patcher.stop()

    def test_init_web_user(self):
        """Test initialization with web user"""
        service = FeminiService("test@example.com")
        self.assertEqual(service.platform, "web")
        self.assertEqual(service.user_email, "test@example.com")
        self.assertEqual(service.session.headers['X-User-Email'], "test@example.com")
        self.assertEqual(service.session.headers['X-Platform'], "web")

    def test_init_slack_user(self):
        """Test initialization with slack user"""
        slack_email = f"{SLACK_USER_PREFIX}test@example.com"
        service = FeminiService(slack_email)
        self.assertEqual(service.platform, "slack")
        self.assertEqual(service.user_email, "test@example.com")
        self.assertEqual(service.session.headers['X-User-Email'], "test@example.com")
        self.assertEqual(service.session.headers['X-Platform'], "slack")

    def test_init_invalid_email(self):
        """Test initialization with invalid email format"""
        with self.assertRaises(ValueError) as context:
            FeminiService("invalid-email")
        self.assertIn("Invalid email format", str(context.exception))

    def test_init_empty_identifier(self):
        """Test initialization with empty user identifier"""
        with self.assertRaises(ValueError) as context:
            FeminiService("")
        self.assertEqual(str(context.exception), "User identifier cannot be empty")

    def test_init_slack_invalid_email(self):
        """Test initialization with invalid slack email format"""
        with self.assertRaises(ValueError) as context:
            FeminiService(f"{SLACK_USER_PREFIX}invalid-email")
        self.assertIn("Invalid email format", str(context.exception))

    def test_init_missing_api_key(self):
        """Test initialization with missing API key"""
        with patch.dict('os.environ', {'FEMINI_BASE_URL': 'https://femini.feedmob.com'}, clear=True):
            with self.assertRaises(ValueError) as context:
                FeminiService("test@example.com")
            self.assertEqual(str(context.exception), "FEMINI_API_KEY environment variable is not set")

    def test_init_missing_base_url(self):
        """Test initialization with missing base URL"""
        with patch.dict('os.environ', {'FEMINI_API_KEY': 'test-api-key'}, clear=True):
            with self.assertRaises(ValueError) as context:
                FeminiService("test@example.com")
            self.assertEqual(str(context.exception), "FEMINI_BASE_URL environment variable is not set")

    @patch("services.femini_service.FeminiService._make_api_request")
    def test_list_documents_default_params(self, mock_make_api_request):
        """Test list_documents with default parameters"""
        # Setup mock response
        mock_response = {
            "documents": [{"id": 1, "title": "Test Document"}],
            "pagination": {"count": 1, "page": 1}
        }
        mock_make_api_request.return_value = mock_response

        service = FeminiService("test@example.com")
        result = service.list_documents()

        # Verify API parameters
        expected_params = {
            'query[sort_by]': 'date_desc',
            'query[limit]': 10,
            'page': 1
        }
        mock_make_api_request.assert_called_once_with("get", "documents.json", params=expected_params)
        self.assertEqual(result, mock_response)

    @patch("services.femini_service.FeminiService._make_api_request")
    def test_list_documents_with_all_params(self, mock_make_api_request):
        """Test list_documents with all optional parameters"""
        mock_response = {
            "documents": [{"id": 1, "title": "Test Document"}],
            "pagination": {"count": 1, "page": 1}
        }
        mock_make_api_request.return_value = mock_response

        service = FeminiService("test@example.com")
        result = service.list_documents(
            page=2,
            limit=20,
            sort_by="date_asc",
            search="test",
            date_gteq="2025-02-13",
            date_lteq="2025-02-14",
            doc_type="email"
        )

        # Verify API parameters
        expected_params = {
            'query[sort_by]': 'date_asc',
            'query[limit]': 20,
            'page': 2,
            'query[search]': 'test',
            'query[date_gteq]': '2025-02-13',
            'query[date_lteq]': '2025-02-14',
            'query[doc_type]': 'email'
        }
        mock_make_api_request.assert_called_once_with("get", "documents.json", params=expected_params)
        self.assertEqual(result, mock_response)

    @patch("services.femini_service.FeminiService._make_api_request")
    def test_list_documents_with_date_objects(self, mock_make_api_request):
        """Test list_documents with date objects instead of strings"""
        mock_response = {
            "documents": [{"id": 1, "title": "Test Document"}],
            "pagination": {"count": 1, "page": 1}
        }
        mock_make_api_request.return_value = mock_response

        service = FeminiService("test@example.com")
        result = service.list_documents(
            date_gteq=date(2025, 2, 13),
            date_lteq=date(2025, 2, 14)
        )

        # Verify API parameters
        expected_params = {
            'query[sort_by]': 'date_desc',
            'query[limit]': 10,
            'page': 1,
            'query[date_gteq]': '2025-02-13',
            'query[date_lteq]': '2025-02-14'
        }
        mock_make_api_request.assert_called_once_with("get", "documents.json", params=expected_params)
        self.assertEqual(result, mock_response)

    @patch("services.femini_service.FeminiService._make_api_request")
    def test_list_documents_error(self, mock_make_api_request):
        """Test error handling in list_documents"""
        mock_make_api_request.side_effect = FeminiAPIError("API Error")

        service = FeminiService("test@example.com")
        with self.assertRaises(FeminiAPIError) as context:
            service.list_documents()
        self.assertIn("API Error", str(context.exception))

    @patch("services.femini_service.FeminiService._make_api_request")
    def test_get_campaign_spends_query_params(self, mock_make_api_request):
        """Test that campaign spends query parameters are correctly mapped"""
        # Setup mock to simulate API response
        api_response = {"data": "test-data"}
        mock_make_api_request.return_value = api_response

        service = FeminiService("test@example.com")
        result = service.get_campaign_spends(
            level="client",
            date_gteq="2024-01-01",
            date_lteq="2024-01-31",
            legacy_client_id_in=[1, 2],
            legacy_partner_id_in=[3, 4],
        )

        # Verify API parameters
        expected_params = {
            "level": "client",
            "date_gteq": "2024-01-01",
            "date_lteq": "2024-01-31",
            "legacy_client_id_in[]": [1, 2],
            "legacy_partner_id_in[]": [3, 4],
        }
        mock_make_api_request.assert_called_once_with("get", "campaign_spends.json", params=expected_params)

        # Verify response structure
        self.assertEqual(result["data"], api_response)
        self.assertIn("source_url", result)
        self.assertTrue(result["source_url"].startswith(f"{service.base_url}/campaign_spends?"))

    @patch('services.femini_service.FeminiService._make_api_request')
    def test_get_campaign_spends_error(self, mock_make_api_request):
        """Test error handling in campaign spends retrieval"""
        mock_make_api_request.side_effect = FeminiAPIError("API Error")

        service = FeminiService("test@example.com")
        with self.assertRaises(FeminiAPIError) as context:
            service.get_campaign_spends(level="client")
        self.assertIn("API Error", str(context.exception))

    @patch('services.femini_service.FeminiService._make_api_request')
    def test_get_campaign_spends_with_default_dates(self, mock_make_api_request):
        """Test campaign spends with default dates"""
        mock_make_api_request.return_value = {'spend_data': 'test-data'}

        service = FeminiService("test@example.com")
        result = service.get_campaign_spends(level="client")

        # Verify API call
        call_kwargs = mock_make_api_request.call_args[1]
        params = call_kwargs['params']
        
        # Check default date parameters
        self.assertIn('date_gteq', params)
        self.assertIn('date_lteq', params)
        
        # Verify result structure
        self.assertEqual(result['data'], {'spend_data': 'test-data'})
        self.assertIn('source_url', result)
        self.assertIn('campaign_spends?', result['source_url'])

    def test_build_campaign_spends_url_formatting(self):
        """Test URL building with proper query parameter formatting"""
        service = FeminiService("test@example.com")
        url = service._FeminiService__build_campaign_spends_url(
            date_gteq='2024-01-01',
            date_lteq='2024-01-31',
            legacy_client_id_in=[1, 2],
            legacy_partner_id_in=[3, 4]
        )
        
        # Verify URL structure and parameter formatting
        self.assertTrue(url.startswith(f"{service.base_url}/campaign_spends?"))
        self.assertIn('query%5Bdate_gteq%5D=2024-01-01', url)
        self.assertIn('query%5Bdate_lteq%5D=2024-01-31', url)
        self.assertIn('query%5Blegacy_client_id_in%5D%5B%5D=1', url)
        self.assertIn('query%5Blegacy_client_id_in%5D%5B%5D=2', url)
        self.assertIn('query%5Blegacy_partner_id_in%5D%5B%5D=3', url)
        self.assertIn('query%5Blegacy_partner_id_in%5D%5B%5D=4', url)

    def test_build_campaign_spends_url_optional_params(self):
        """Test URL building with missing optional parameters"""
        service = FeminiService("test@example.com")
        url = service._FeminiService__build_campaign_spends_url(
            date_gteq='2024-01-01',
            date_lteq='2024-01-31'
        )
        
        # Verify required parameters are present
        self.assertIn('query%5Bdate_gteq%5D=2024-01-01', url)
        self.assertIn('query%5Bdate_lteq%5D=2024-01-31', url)
        
        # Verify optional parameters are not included
        self.assertNotIn('legacy_client_id_in', url)
        self.assertNotIn('legacy_partner_id_in', url)

    @patch('requests.Session.get')
    def test_search_clients_success(self, mock_get):
        """Test successful client search"""
        mock_response = MagicMock()
        mock_response.json.return_value = {'clients': [{'id': 1, 'name': 'Test Client'}]}
        mock_response.raise_for_status.return_value = None
        mock_get.return_value = mock_response

        service = FeminiService("test@example.com")
        result = service.search_clients(name_cont="Test")

        self.assertEqual(result, {'clients': [{'id': 1, 'name': 'Test Client'}]})
        mock_get.assert_called_once()
        call_kwargs = mock_get.call_args[1]
        self.assertEqual(call_kwargs['json']['query']['name_cont'], 'Test')

    @patch('requests.Session.get')
    def test_search_clients_error(self, mock_get):
        """Test error handling in client search"""
        mock_get.side_effect = requests.exceptions.RequestException("API Error")

        service = FeminiService("test@example.com")
        with self.assertRaises(FeminiAPIError) as context:
            service.search_clients(name_cont="Test")
        self.assertIn("Femini API request failed", str(context.exception))

    @patch('requests.Session.get')
    def test_search_partners_success(self, mock_get):
        """Test successful partner search"""
        mock_response = MagicMock()
        mock_response.json.return_value = {'partners': [{'id': 1, 'name': 'Test Partner'}]}
        mock_response.raise_for_status.return_value = None
        mock_get.return_value = mock_response

        service = FeminiService("test@example.com")
        result = service.search_partners(name_cont="Test")

        self.assertEqual(result, {'partners': [{'id': 1, 'name': 'Test Partner'}]})
        mock_get.assert_called_once()
        call_kwargs = mock_get.call_args[1]
        self.assertEqual(call_kwargs['json']['query']['name_cont'], 'Test')

    @patch('requests.Session.get')
    def test_search_partners_error(self, mock_get):
        """Test error handling in partner search"""
        mock_get.side_effect = requests.exceptions.RequestException("API Error")

        service = FeminiService("test@example.com")
        with self.assertRaises(FeminiAPIError) as context:
            service.search_partners(name_cont="Test")
        self.assertIn("Femini API request failed", str(context.exception))

if __name__ == '__main__':
    unittest.main()
