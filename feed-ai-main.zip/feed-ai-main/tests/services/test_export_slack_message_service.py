import unittest
from unittest.mock import MagicMock, patch
from datetime import datetime
from services.export_slack_message_service import ExportSlackMessageService, ExportSlackMessageToCSV

class TestExportSlackMessageService(unittest.TestCase):
    def setUp(self):
        self.qdrant_client = MagicMock()
        self.service = ExportSlackMessageService(qdrant_client=self.qdrant_client)

    @patch('services.export_slack_message_service.ExportSlackMessageToCSV.export')
    @patch('services.export_slack_message_service.ExportSlackMessageToMarkdown.export')
    def test_export(self, mock_export_markdown, mock_export_csv):
        mock_export_csv.return_value = 'path/to/csv_file.csv'
        mock_export_markdown.return_value = ['path/to/markdown_file.md']

        start_time = datetime(2023, 1, 1)
        end_time = datetime(2023, 1, 31)
        result = self.service.export(start_time, end_time)

        mock_export_csv.assert_called_once_with(start_time, end_time)
        mock_export_markdown.assert_called_once_with(start_time, end_time)
        self.assertEqual(result, ['path/to/markdown_file.md'])

class TestExportSlackMessageToCSV(unittest.TestCase):
    def setUp(self):
        self.qdrant_client = MagicMock()
        self.exporter = ExportSlackMessageToCSV(qdrant_client=self.qdrant_client)

    @patch('tempfile.NamedTemporaryFile')
    @patch('csv.writer')
    def test_export(self, mock_csv_writer, mock_tempfile):
        mock_tempfile.return_value.__enter__.return_value.name = 'temp_file.csv'
        mock_writer = MagicMock()
        mock_csv_writer.return_value = mock_writer

        start_time = datetime(2023, 1, 1)
        end_time = datetime(2023, 1, 31)
        self.qdrant_client.scroll.return_value = ([], None)

        result = self.exporter.export(start_time, end_time)

        self.assertEqual(result, 'temp_file.csv')
        mock_writer.writerow.assert_called_once_with(["ID", "Timestamp", "Workspace", "Channel", "Permalink", "Message Content"])

if __name__ == '__main__':
    unittest.main()
