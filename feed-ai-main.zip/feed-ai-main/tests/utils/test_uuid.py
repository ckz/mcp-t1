import uuid
import pytest
from utils.uuid import generate_uuid, generate_uuid_str

def test_generate_uuid():
    # Test with a sample text
    test_text = "example.com"
    result = generate_uuid(test_text)
    
    # Check if result is a UUID object
    assert isinstance(result, uuid.UUID)
    
    # Check if the same input produces the same UUID
    assert generate_uuid(test_text) == generate_uuid(test_text)
    
    # Check if different inputs produce different UUIDs
    assert generate_uuid("test1.com") != generate_uuid("test2.com")

def test_generate_uuid_str():
    # Test with a sample text
    test_text = "example.com"
    result = generate_uuid_str(test_text)
    
    # Check if result is a string
    assert isinstance(result, str)
    
    # Check if the string is a valid UUID format
    assert len(result) == 36
    
    # Check if the same input produces the same UUID string
    assert generate_uuid_str(test_text) == generate_uuid_str(test_text)
    
    # Check if different inputs produce different UUID strings
    assert generate_uuid_str("test1.com") != generate_uuid_str("test2.com")

def test_empty_string():
    # Test with empty string
    assert isinstance(generate_uuid(""), uuid.UUID)
    assert isinstance(generate_uuid_str(""), str)

