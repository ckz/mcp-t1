import pytest
from datetime import datetime, timezone, timedelta
from utils.datetime import normalize_time

def test_normalize_time_with_timezone():
    # Create datetime with timezone
    dt = datetime(2023, 1, 1, 12, 0, tzinfo=timezone(timezone.utc.utcoffset(None)))
    result = normalize_time(dt)
    assert result == datetime(2023, 1, 1, 12, 0)
    assert result.tzinfo is None

def test_normalize_time_with_different_timezone():
    # Create datetime with EST timezone
    est = timezone(offset=timezone.utc.utcoffset(None) - timedelta(hours=5))
    dt = datetime(2023, 1, 1, 12, 0, tzinfo=est)
    result = normalize_time(dt)
    assert result == datetime(2023, 1, 1, 17, 0)  # EST to UTC adds 5 hours
    assert result.tzinfo is None

def test_normalize_time_without_timezone():
    dt = datetime(2023, 1, 1, 12, 0)
    result = normalize_time(dt)
    assert result == datetime(2023, 1, 1, 12, 0)
    assert result.tzinfo is None
