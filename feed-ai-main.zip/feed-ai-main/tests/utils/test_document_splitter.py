import pytest
from langchain_core.documents import Document
from langchain_core.messages import AIMessage
from utils.document_splitter import split_markdown_document, split_text_document, __summarize_content, SummaryResult
from utils.uuid import generate_uuid_str
from unittest.mock import patch, MagicMock, ANY
from services.bedrock_service import BedrockModel

@pytest.fixture
def sample_document():
    return Document(
        page_content="# Header\nThis is a test content.\n## Section\nMore content here.",
        metadata={"source": "test.md"},
        id="test-doc-id"
    )

@pytest.fixture
def long_document():
    # Create a document that's longer than the default chunk size
    return Document(
        page_content="# " + "very long content " * 1000,
        metadata={"source": "test.md"},
        id="test-doc-id"
    )

@patch('utils.document_splitter.__summarize_content')
def test_split_text_document(mock_summarize):
    mock_summarize.return_value = "Summary"
    
    # Test case 1: Basic text splitting
    text1 = "Short text that fits in one chunk."
    doc1 = Document(
        page_content=text1,
        metadata={"source": "test1.txt"},
        id=generate_uuid_str("doc1")
    )
    chunks1 = split_text_document(doc1, chunk_size=100, chunk_overlap=0)
    assert len(chunks1) == 1
    assert chunks1[0].page_content == text1
    assert chunks1[0].id == generate_uuid_str("doc1")

    # Test case 2: Multiple paragraphs with overlap
    text2 = """First paragraph with some content.

    Second paragraph that continues here
    and spans multiple lines.

    Third paragraph with more text
    that should create multiple chunks."""

    doc2 = Document(
        page_content=text2,
        metadata={"source": "test2.txt"},
        id=generate_uuid_str("doc2")
    )
    chunks2 = split_text_document(doc2, chunk_size=50, chunk_overlap=10)
    assert len(chunks2) > 1
    assert all(chunk.metadata["source"] == "test2.txt" for chunk in chunks2)
    assert chunks2[0].id == generate_uuid_str("doc2")
    for i, chunk in enumerate(chunks2[1:]):
        assert chunk.metadata["parent_id"] == generate_uuid_str("doc2")
        assert i == chunk.metadata["chunk_index"]
        assert chunk.id == generate_uuid_str(f"{doc2.id}-{i}")

    # Test case 3: Edge case with empty text
    text3 = ""
    doc3 = Document(
        page_content=text3,
        metadata={"source": "test3.txt"},
        id=generate_uuid_str("doc3")
    )
    chunks3 = split_text_document(doc3, chunk_size=100, chunk_overlap=0)
    assert len(chunks3) == 1
    assert chunks3[0].page_content == ""
    assert chunks3[0].id == generate_uuid_str("doc3")

    # Test case 4: Text with special characters
    text4 = "Special chars: !@#$%^&*()\nNew line and    multiple    spaces"
    doc4 = Document(
        page_content=text4,
        metadata={"source": "test4.txt"},
        id=generate_uuid_str("doc4")
    )
    chunks4 = split_text_document(doc4, chunk_size=100, chunk_overlap=0)
    assert len(chunks4) == 1
    assert chunks4[0].page_content == text4
    assert chunks4[0].id == generate_uuid_str("doc4")

@patch('utils.document_splitter.__summarize_content')
def test_split_markdown_document_single_chunk(mock_summarize, sample_document):
    mock_summarize.return_value = "Summary"
    result = split_markdown_document(sample_document)
    
    assert len(result) == 1
    assert result[0].page_content == sample_document.page_content
    assert result[0].metadata["has_chunks"] == False

@patch('utils.document_splitter.__summarize_content')
def test_split_markdown_document_multiple_chunks(mock_summarize, long_document):
    mock_summarize.return_value = "Summary"
    result = split_markdown_document(long_document)
    
    assert len(result) > 1
    assert result[0].metadata["has_chunks"] == True
    assert result[0].metadata["is_chunk"] == False
    assert result[0].id == "test-doc-id"
    assert result[0].page_content == "Summary"
    
    # Test first chunk
    assert result[1].metadata["is_chunk"] == True
    assert result[1].metadata["chunk_index"] == 0
    assert result[1].metadata["parent_id"] == "test-doc-id"
    
    # Verify chunk ID using the same UUID generation
    expected_chunk_id = f"test-doc-id-{result[1].metadata['chunk_index']}"
    assert result[1].id == generate_uuid_str(expected_chunk_id)

@patch('utils.document_splitter.__summarize_content')
def test_chunk_metadata_consistency(mock_summarize, long_document):
    mock_summarize.return_value = "Summary"
    result = split_markdown_document(long_document)
    
    for i in range(1, len(result)):
        chunk = result[i]
        assert chunk.metadata["is_chunk"] == True
        assert chunk.metadata["chunk_index"] == i - 1
        assert chunk.metadata["parent_id"] == long_document.id
        
        # Verify chunk ID
        expected_chunk_id = f"test-doc-id-{chunk.metadata['chunk_index']}"
        assert chunk.id == generate_uuid_str(expected_chunk_id)
        
        if i > 1:
            expected_previous_id = f"test-doc-id-{chunk.metadata['chunk_index']-1}"
            assert chunk.metadata["previous_chunk_id"] == generate_uuid_str(expected_previous_id)

@patch('utils.document_splitter.StructuredOutputInstructor')
def test_summarize_content(mock_instructor):
    # Mock the instructor instance
    mock_instance = MagicMock()
    mock_instance.invoke.return_value = SummaryResult(summary="Test summary")
    mock_instructor.return_value = mock_instance

    content = "Test content to summarize"
    result = __summarize_content(content)

    # Verify the mock was called with correct parameters
    mock_instructor.assert_called_once_with(SummaryResult)
    mock_instance.invoke.assert_called_once_with(BedrockModel.NOVA_LITE_MODEL_ID.value, ANY)
    
    assert isinstance(result, str)
    assert result == "Test summary"

@patch('utils.document_splitter.__summarize_content')
def test_custom_chunk_size(mock_summarize):
    mock_summarize.return_value = "Summary"
    doc = Document(
        page_content="Test " * 100,
        metadata={"source": "test.md"},
        id="test-doc-id"
    )
    
    result = split_markdown_document(doc, chunk_size=100, chunk_overlap=10)
    assert len(result) > 1
    assert result[0].metadata["chunk_count"] > 1
