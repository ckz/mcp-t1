import os
import pytest

from utils.app_stage import AppStage, get_app_stage, enable_db_migration


class TestAppStage:

    def test_get_app_stage_stable(self, monkeypatch):
        monkeypatch.setenv("APP_STAGE", "stable")
        assert get_app_stage() == AppStage.STABLE

    def test_get_app_stage_beta(self, monkeypatch):
        monkeypatch.setenv("APP_STAGE", "beta")
        assert get_app_stage() == AppStage.BETA

    def test_get_app_stage_default(self, monkeypatch):
        # Unset APP_STAGE to test the default value
        monkeypatch.delenv("APP_STAGE", raising=False)
        assert get_app_stage() == AppStage.STABLE

    def test_get_app_stage_invalid(self, monkeypatch):
        monkeypatch.setenv("APP_STAGE", "invalid")
        with pytest.raises(ValueError):
            get_app_stage()

    def test_enable_db_migration_true(self, monkeypatch):
        monkeypatch.setenv("ENABLE_DB_MIGRATION", "true")
        assert enable_db_migration() is True

    def test_enable_db_migration_false(self, monkeypatch):
        monkeypatch.setenv("ENABLE_DB_MIGRATION", "false")
        assert enable_db_migration() is False

    def test_enable_db_migration_not_set(self, monkeypatch):
        monkeypatch.delenv("ENABLE_DB_MIGRATION", raising=False)
        assert enable_db_migration() is False