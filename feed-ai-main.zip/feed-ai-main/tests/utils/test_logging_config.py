import logging
import pytest
from unittest.mock import patch

from utils.logging_config import setup_logging, logger

@pytest.fixture(autouse=True)
def reset_logging():
    """Reset logging configuration before each test"""
    # Store the original handlers
    original_handlers = logging.getLogger('utils.logging_config').handlers[:]
    
    # Clear handlers for the test
    root = logging.getLogger()
    for handler in root.handlers[:]:
        root.removeHandler(handler)
    test_logger = logging.getLogger('utils.logging_config')
    for handler in test_logger.handlers[:]:
        test_logger.removeHandler(handler)
        
    yield
    
    # Restore original handlers after the test
    test_logger = logging.getLogger('utils.logging_config')
    for handler in original_handlers:
        test_logger.addHandler(handler)

def test_setup_logging_default_level():
    """Test that setup_logging creates a logger with default INFO level"""
    test_logger = setup_logging()
    assert test_logger.level == logging.INFO
    assert len(test_logger.handlers) > 0

def test_setup_logging_custom_level():
    """Test that setup_logging respects custom log level"""
    test_logger = setup_logging(log_level=logging.DEBUG)
    assert test_logger.level == logging.DEBUG

def test_logger_handler_configuration():
    """Test that the logger has properly configured handler"""
    test_logger = setup_logging()
    assert len(test_logger.handlers) == 1
    
    handler = test_logger.handlers[0]
    assert isinstance(handler, logging.StreamHandler)
    assert handler.level == logging.INFO

def test_logger_formatter():
    """Test that the logger's handler has the correct formatter"""
    test_logger = setup_logging()
    handler = test_logger.handlers[0]
    formatter = handler.formatter
    
    assert isinstance(formatter, logging.Formatter)
    assert formatter._fmt == '%(asctime)s - %(name)s - %(levelname)s - %(message)s'

@patch('sys.stderr')
def test_logger_messages(mock_stderr):
    """Test that the logger properly formats and handles messages"""
    test_logger = setup_logging()
    test_message = "Test info message"
    
    test_logger.info(test_message)
    
    # Verify the message was logged to stderr
    assert mock_stderr.write.called

def test_global_logger_instance():
    """Test that the global logger instance is properly configured"""
    # The logger is already imported at the module level
    assert isinstance(logger, logging.Logger)
    assert logger.level == logging.INFO
    
    # Since the logger might be reset by other tests, let's ensure it's properly configured
    if not logger.handlers:
        setup_logging()
    
    # Now verify it has handlers
    assert len(logger.handlers) > 0