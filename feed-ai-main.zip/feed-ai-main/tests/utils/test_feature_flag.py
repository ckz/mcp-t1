import pytest
import unittest
import json
from unittest.mock import patch
from utils.feature_flag import FeatureFlag
from utils.app_stage import AppStage

@pytest.fixture
def feature_flag():
    return FeatureFlag()

class TestFeatureFlag:

    @patch("utils.feature_flag.get_app_stage")
    def test_is_enabled_feature_enabled(self, mock_get_app_stage, feature_flag):
        mock_get_app_stage.return_value = AppStage.BETA
        user_id = "test_user"
        feature_name = "test_feature"
        with patch("utils.feature_flag.FeatureManager.is_enabled", return_value=True) as mock_is_enabled:
            result = feature_flag.is_enabled(feature_name, user_id)
            assert result is True
            mock_is_enabled.assert_called_once_with(feature_name,  unittest.mock.ANY)

    @patch("utils.feature_flag.get_app_stage")
    def test_is_enabled_feature_disabled(self, mock_get_app_stage, feature_flag):
        mock_get_app_stage.return_value = AppStage.BETA
        user_id = "test_user"
        feature_name = "test_feature"
        with patch("utils.feature_flag.FeatureManager.is_enabled", return_value=False) as mock_is_enabled:
            result = feature_flag.is_enabled(feature_name, user_id)
            assert result is False
            mock_is_enabled.assert_called_once_with(feature_name, unittest.mock.ANY)

    def test_feature_flag_singleton(self, feature_flag):
        feature_flag1 = FeatureFlag()
        feature_flag2 = FeatureFlag()
        assert feature_flag1 is feature_flag2

    def test_feature_flags_json_structure(self, feature_flag):
        with open("utils/feature_flags.json", "r", encoding="utf-8") as f:
            feature_flags = json.load(f)

        assert "feature_management" in feature_flags
        assert "feature_flags" in feature_flags["feature_management"]
        assert isinstance(feature_flags["feature_management"]["feature_flags"], list)
        for feature in feature_flags["feature_management"]["feature_flags"]:
            assert "id" in feature
            assert "enabled" in feature

        # Check if FeatureFlag is working properly
        user_id = "test_user"
        for feature in feature_flags["feature_management"]["feature_flags"]:
            feature_name = feature["id"]
            expected_value = feature["enabled"]
            app_stage = AppStage.BETA
            with patch("utils.feature_flag.get_app_stage", return_value=app_stage):
                result = feature_flag.is_enabled(feature_name, user_id)
                assert result == expected_value