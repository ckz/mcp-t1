import pytest
from utils.text_converter import clean_unicode_escapes, markdown_to_text, html_to_text

def test_markdown_to_text_with_simple_markdown():
    markdown = "# Heading\n\n- Item 1\n- Item 2"
    result = markdown_to_text(markdown).lower()
    assert "heading" in result
    assert "item 1" in result
    assert "item 2" in result
    assert result == "heading item 1 item 2"

def test_html_to_text_with_simple_html():
    html = "<p>Hello <b>world</b>!</p>"
    result = html_to_text(html).lower()
    assert "hello" in result
    assert "world" in result
    assert result == "hello world!"

def test_html_to_text_with_complex_html():
    html = """
    <div class="email-body">
        <h1>Meeting Notes</h1>
        <p>Date: <span>2024-02-14</span></p>
        <ul>
            <li>First item</li>
            <li>Second item</li>
        </ul>
        <div class="signature">
            Best regards,<br>
            John
        </div>
    </div>
    """
    result = html_to_text(html).lower()
    assert "meeting notes" in result
    assert "date: 2024-02-14" in result
    assert "first item" in result
    assert "second item" in result
    assert "best regards" in result
    assert "john" in result

def test_html_to_text_with_nested_structure():
    html = """
    <div>
        <div>
            <p>Nested <strong>content</strong></p>
            <p>Multiple <i>paragraphs</i></p>
        </div>
    </div>
    """
    result = html_to_text(html).lower()
    assert "nested content" in result
    assert "multiple paragraphs" in result

def test_html_to_text_with_empty_input():
    assert html_to_text("") == ""
    assert html_to_text(None) == ""

def test_html_to_text_with_whitespace():
    html = """
    <div>
        <p>   Lots of    spaces   </p>
        <p>
            Multiple
            lines
        </p>
    </div>
    """
    result = html_to_text(html).lower()
    assert "lots of spaces" in result
    assert "multiple" in result
    assert "lines" in result

def test_html_to_text_with_special_characters():
    html = "<p>&amp; &lt; &gt; &quot; &apos;</p>"
    result = html_to_text(html)
    assert "&" in result
    assert "<" in result
    assert ">" in result
    assert '"' in result
    assert "'" in result

def test_html_to_text_with_tables():
    html = """
    <table>
        <tr>
            <th>Header 1</th>
            <th>Header 2</th>
        </tr>
        <tr>
            <td>Cell 1</td>
            <td>Cell 2</td>
        </tr>
    </table>
    """
    result = html_to_text(html).lower()
    assert "header 1" in result
    assert "header 2" in result
    assert "cell 1" in result
    assert "cell 2" in result

def test_clean_unicode_escapes():
    text = "Wen \u003Cwen@feedmob.com\u003E"
    result = clean_unicode_escapes(text)
    assert result == "Wen <wen@feedmob.com>"
