import os
import uuid
import pytest
import asyncio
from datetime import datetime, timedelta
from unittest.mock import AsyncMock

# Import the classes from your module.
# Adjust the import paths if needed according to your project structure.
from jobs.sync_github_issues_to_db_job import (
    SyncGithubIssueToDb,
    GithubRepo,
)

from langchain_core.documents import Document


# -----------------------------------------------------------------------------
# Fixture for environment variables used in the tests.
# -----------------------------------------------------------------------------
@pytest.fixture(autouse=True)
def set_env_vars(monkeypatch):
    monkeypatch.setenv("GITHUB_PERSONAL_ACCESS_TOKEN", "dummy_token")
    monkeypatch.setenv("QDRANT_URL", "http://localhost:6333")
    monkeypatch.setenv("QDRANT_API_KEY", "dummy_key")


# -----------------------------------------------------------------------------
# Helper: Create a dummy Document for testing.
# -----------------------------------------------------------------------------
def create_dummy_doc(url_suffix, created_at_str, title="Dummy Issue", content="Content text"):
    doc = Document(page_content=content)
    # Populate necessary metadata; later processing in SyncGithubIssueToDb
    doc.metadata = {
        "created_at": created_at_str,
        "url": f"https://github.com/dummy/repo/{url_suffix}",
        "title": title
    }
    return doc


# -----------------------------------------------------------------------------
# Test: run() processes documents in batches and ignores docs after end_time.
# -----------------------------------------------------------------------------
@pytest.mark.asyncio
async def test_sync_github_issues_run(monkeypatch):
    # Prepare a dummy vector store with an async aadd_documents method to monitor.
    mock_vector_store = type("DummyVectorStore", (), {})()
    # Use AsyncMock for asynchronous behavior.
    mock_vector_store.aadd_documents = AsyncMock()

    BATCH_SIZE = 10

    # Set up start_time and end_time.
    start_time = datetime(2025, 1, 1, 0, 0, 0)
    end_time = datetime(2025, 2, 5, 0, 0, 0)
    created_at_in_range = "2025-02-04T21:00:45Z"  # This timestamp is before end_time.

    # Build a list of BATCH_SIZE documents all within the allowed time.
    docs_in_range = [
        create_dummy_doc(url_suffix=f"{i}", created_at_str=created_at_in_range)
        for i in range(BATCH_SIZE)
    ]

    # Create one extra document with created_at after end_time (should be skipped).
    created_at_after = (end_time + timedelta(days=1)).strftime('%Y-%m-%dT%H:%M:%SZ')
    extra_doc = create_dummy_doc(url_suffix="extra", created_at_str=created_at_after)

    # Combine into a single list: in-range docs followed by an out-of-range doc.
    all_docs = docs_in_range + [extra_doc]

    # Simulate a lazy loader yielding these documents.
    def fake_lazy_load():
        for d in all_docs:
            yield d

    # Replace the __loader method on the instance so that it returns a fake loader.
    def fake_loader():
        class FakeLoader:
            def lazy_load(self):
                return fake_lazy_load()
        return FakeLoader()

    # Instantiate the SyncGithubIssueToDb job with our dummy vector store.
    sync_job = SyncGithubIssueToDb(
        vector_sotre=mock_vector_store,
        repo=GithubRepo.FEEDMOB,
        start_time=start_time,
        end_time=end_time
    )

    # Patch the __loader method (name mangling: _SyncGithubIssueToDb__loader).
    monkeypatch.setattr(sync_job, "_SyncGithubIssueToDb__loader", fake_loader)

    # Execute the run() method, which should process the documents.
    await sync_job.run()

    # Assert:
    # The fake loader yields 10 valid docs and one extra doc (which is skipped), so
    # we expect __add_to_vector_store to be called exactly once.
    assert mock_vector_store.aadd_documents.call_count == 1

    # Get the positional arguments passed to the vector store method.
    # Because the production code wraps the batch in a list, we expect a list of one element.
    called_args = mock_vector_store.aadd_documents.call_args[0]
    # Verify that we got one argument.
    assert isinstance(called_args[0], list)
    assert len(called_args[0]) == 1  # Because the entire batch was wrapped in a list.

    # Now check that the contained batch has BATCH_SIZE documents.
    batch_docs = called_args[0][0]
    assert isinstance(batch_docs, list)
    assert len(batch_docs) == BATCH_SIZE

    # Validate that each document got processed:
    sample_doc = batch_docs[0]
    # The document id should be assigned via uuid5 based on its URL.
    expected_id = str(uuid.uuid5(uuid.NAMESPACE_DNS, sample_doc.metadata["url"]))
    assert sample_doc.id == expected_id
    # The page_content should start with the title followed by two newlines.
    assert sample_doc.page_content.startswith(sample_doc.metadata["title"] + "\n\n")
    # The repo information should be included in document metadata.
    assert sample_doc.metadata.get("repo") == GithubRepo.FEEDMOB.value


# -----------------------------------------------------------------------------
# Test: start_time later than end_time should raise a ValueError.
# -----------------------------------------------------------------------------
def test_invalid_time():
    start_time = datetime(2025, 2, 10, 0, 0, 0)
    end_time = datetime(2025, 2, 5, 0, 0, 0)
    with pytest.raises(ValueError, match="start_time must be before end_time"):
        SyncGithubIssueToDb(
            vector_sotre=None,  # The vector store isn’t used in time validation.
            repo=GithubRepo.FEEDMOB,
            start_time=start_time,
            end_time=end_time,
        )


# -----------------------------------------------------------------------------
# Test: Loading issues without a GITHUB_PERSONAL_ACCESS_TOKEN
# should raise a ValueError.
# -----------------------------------------------------------------------------
def test_loader_missing_access_token(monkeypatch):
    # Remove the GITHUB_PERSONAL_ACCESS_TOKEN environment variable.
    monkeypatch.delenv("GITHUB_PERSONAL_ACCESS_TOKEN", raising=False)
    start_time = datetime(2025, 1, 1, 0, 0, 0)
    end_time = datetime(2025, 2, 5, 0, 0, 0)
    sync_job = SyncGithubIssueToDb(
        vector_sotre=None,
        repo=GithubRepo.FEEDMOB,
        start_time=start_time,
        end_time=end_time
    )
    # Expect a ValueError when __loader() is called due to missing access token.
    with pytest.raises(ValueError, match="GITHUB_PERSONAL_ACCESS_TOKEN env var is not set."):
        _ = sync_job._SyncGithubIssueToDb__loader()
