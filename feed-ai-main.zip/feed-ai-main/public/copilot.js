const getAccessToken = async () => {
  const token = localStorage.getItem("token")
  return fetch("/chat/copilot/validate_access_token", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Authorization": `Bearer ${token}`
    }
  }).then(response => {
    if (response.status === 401) {
      alert("Unauthorized access. Please login to access this page")
      window.location.href = "/chat/login"
    }
    if (!response.ok) {
      throw new Error("Failed to generate access token")
    }
    return response.json()
  }).then(_data => {
    return token
  }).catch(error => {
    console.error("Error:", error)
  })
}

const tryClickButton = () => {
  const copilot = document.querySelector("#chainlit-copilot");
  if (copilot) {
    if (copilot.shadowRoot) {
      const button = copilot.shadowRoot.querySelector("#chainlit-copilot-button");
      if (button) {
        try {
          button.click();
          console.log('Button clicked successfully');
          button.innerHTML = "🤖";
          button.disabled = true;
          button.style.visibility = "hidden";

          setTimeout(() => {
            const uploadButton = copilot.shadowRoot.querySelector("#upload-button");
            if (uploadButton) {
              uploadButton.remove();
            }

            const watermark = copilot.shadowRoot.querySelector(".watermark");
            if (watermark) {
              watermark.remove();
            }

            const headerSection = copilot.shadowRoot.querySelector("#chainlit-copilot-popover div")?.firstElementChild
            const buttonSection = headerSection?.lastElementChild;
            if (buttonSection) {
              buttonSection.remove();
            }
            const headerButtons = headerSection?.querySelectorAll("button");
            headerButtons.forEach(button => {
              button.remove();
            });
          }, 1000);

          return true;
        } catch (e) {
          console.error('Error clicking button:', e);
        }
      }
    }
  }
  return false;
};

window.addEventListener("chainlit-call-fn", (e) => {
  const { name, _args, _callback } = e.detail;
  if (name === "ready") {
    const urlParams = new URLSearchParams(window.location.search);
    const outputMessage = urlParams.get('content') || "Please tell me how can you help me?";

    if (outputMessage && outputMessage.length > 0) {
      window.sendChainlitMessage({
        type: "user_message",
        output: outputMessage,
      });
    }
  }
});

document.addEventListener('DOMContentLoaded', () => {
  const chainlitServer = `${window.location.origin}/chat`
  getAccessToken().then(accessToken => {
    window.mountChainlitWidget({
      chainlitServer: chainlitServer,
      accessToken: accessToken,
      theme: "light",
    });

    // Try immediately after mounting
    if (!tryClickButton()) {
      // If immediate attempt fails, set up observer
      console.log('Setting up MutationObserver...');

      const observer = new MutationObserver((mutations, obs) => {
        console.log('Mutation observed');

        if (tryClickButton()) {
          console.log('Button clicked via observer, disconnecting...');
          obs.disconnect();
        }
      });

      // Observe both body and document for changes
      const copilot = document.querySelector("#chainlit-copilot");
      observer.observe(copilot.shadowRoot, {
        childList: true,
        subtree: true,
        attributes: true
      });

      // Set a timeout to stop observing after some time
      setTimeout(() => {
        observer.disconnect();
        console.log('Observer disconnected after timeout');
      }, 10000); // 10 second timeout
    }
  });
})
