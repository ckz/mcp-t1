from botocore.client import BaseClient as BotocoreBaseClient
from langchain_core.language_models import BaseChatModel
from langgraph.checkpoint.postgres.aio import AsyncPostgresSaver
from langgraph.prebuilt import create_react_agent

from .tools.all_client_monthly_goal_querier import AllClientMonthlyGoalQuerierTool
from .tools.client_billing_querier import ClientBillingQuerierTool
from .tools.vendor_billing_querier import VendorBillingQuerierTool
from .utils.agent_wrapper import AgentWrapper


def create_billing_information_agent(
    llm: BaseChatModel,
    bedrock_client: BotocoreBaseClient,
    checkpointer: AsyncPostgresSaver,
) -> AgentWrapper:
    client_monthly_goal_querier = AllClientMonthlyGoalQuerierTool()
    client_billing_querier = ClientBillingQuerierTool()
    vendor_billing_querier = VendorBillingQuerierTool()

    tools = [
        client_monthly_goal_querier,
        client_billing_querier,
        vendor_billing_querier,
    ]

    agent = create_react_agent(
        llm,
        tools=tools,
        checkpointer=checkpointer,
    )
    return AgentWrapper(agent)
