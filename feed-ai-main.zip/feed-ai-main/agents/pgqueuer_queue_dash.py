import os
from smolagents import LiteLLMModel, FinalAnswerTool, CodeAgent, tool
from sqlalchemy.engine import Engine
from services.bedrock_service import BedrockModel
from sqlalchemy import (
    create_engine,
    inspect,
    text,
)

def create_pgqueuer_queue_dash() -> CodeAgent:
    llm = LiteLLMModel(
        model_id=f"bedrock/{BedrockModel.PRO_MODEL_ID.value}",
    )

    sql_engine.description = __get_updated_tool_description()
    tools = [sql_engine, FinalAnswerTool()]
    return CodeAgent(tools=tools, model=llm)

@tool
def sql_engine(query: str) -> str:
    """
    Allows you to perform SQL queries on the table. Returns a string representation of the result.

    Args:
        query: The query to perform. This should be correct SQL.
    """
    output = ""
    engine = get_engine()
    with engine.connect() as con:
        rows = con.execute(text(query))
        for row in rows:
            output += "\n" + str(row)
    return output

def __get_updated_tool_description() -> str:
    updated_description = """Allows you to perform SQL queries on the table. Beware that this tool's output is a string representation of the execution output.
It can use the following tables:"""

    inspector = inspect(get_engine())
    if inspector is None:
        raise Exception("Inspector is None")

    for table in ["pgqueuer", "pgqueuer_schedules", "pgqueuer_statistics"]:
        columns_info = [(col["name"], col["type"]) for col in inspector.get_columns(table)]

        table_description = f"Table '{table}':\n"

        table_description += "Columns:\n" + "\n".join([f"  - {name}: {col_type}" for name, col_type in columns_info])
        updated_description += "\n\n" + table_description

    updated_description += """
    \n\nThe following are descriptions of each table:
    - pgqueuer: Contains the queue information, you could use this table to know if entrypoint (or job) is enqueued or not.
    - pgqueuer_schedules: Contains the schedules information.
    - pgqueuer_statistics: Contains the statistics information
    """
    return updated_description

def __create_engine() -> Engine:
    database_url = os.environ["CHECKPOINTER_DATABASE_URL"]
    return create_engine(
        url=database_url,
        echo=True,
        pool_size=5,
        max_overflow=10,
        pool_timeout=30,
        pool_recycle=1800  # Recycle connections after 30 minutes
    )

# Create a single engine instance
_engine: Engine | None = None

def get_engine() -> Engine:
    global _engine
    if _engine is None:
        _engine = __create_engine()
    return _engine
