from langchain_core.language_models import BaseChatModel
from langgraph.checkpoint.postgres.aio import AsyncPostgresSaver

from agents.utils.agent_wrapper import AgentWrapper
from agents.utils.create_react_agent import create_react_agent
from agents.utils.user_specific_mcp_tools import load_user_mcp_tools


def create_chat_bot_agent(
    llm: BaseChatModel, checkpointer: AsyncPostgresSaver
) -> AgentWrapper:
    tools = load_user_mcp_tools()  # Call the function to get the tools
    agent = create_react_agent(
        model=llm, checkpointer=checkpointer, version="v2", tools=tools
    )
    return AgentWrapper(agent, is_streaming=True)
