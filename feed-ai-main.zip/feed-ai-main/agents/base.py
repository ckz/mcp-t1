from pydantic import BaseModel
from typing import Dict, Optional

class AgentQuerierResult(BaseModel):
    content: str
    reference: Optional[str]
    metadata: Optional[Dict]
    score: Optional[float] = None
