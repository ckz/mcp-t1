from datetime import datetime, timezone
from typing import Any

from botocore.client import BaseClient as BotocoreBaseClient
from chainlit import PersistedUser
from langchain_core.language_models import BaseChatModel
from langchain_core.prompts import ChatPromptTemplate
from langgraph.checkpoint.postgres.aio import AsyncPostgresSaver
from langgraph.store.base import BaseStore

from agents.utils.create_react_agent import create_react_agent
from agents.utils.final_answer import FEED_AI_WEB_PROMPT_TEMPLATE

from .tools import load_all_tools
from .utils.agent_wrapper import AgentWrapper
from .utils.user_specific_mcp_tools import load_user_mcp_tools


async def create_feed_ai_thinking_agent(
    user: PersistedUser,
    llm: BaseChatModel,
    bedrock_client: BotocoreBaseClient,
    checkpointer: AsyncPostgresSaver,
    memory_store: BaseStore,
) -> AgentWrapper:
    tools = await load_all_tools(user, memory_store, bedrock_client)
    tools.extend(load_user_mcp_tools())

    agent = create_react_agent(
        llm,
        tools=tools,
        checkpointer=checkpointer,
        prompt=__system_prompt(),
        version="v2",
        final_answer_prompt_tempalte=FEED_AI_WEB_PROMPT_TEMPLATE,
    )
    return AgentWrapper(agent, is_streaming=False)


def __system_prompt() -> Any:
    current_time = datetime.now(timezone.utc).isoformat()
    prompt = ChatPromptTemplate.from_messages(
        [
            (
                "system",
                f"""
🤖 FeedMob AI Assistant
Current Time: {current_time}

You are a specialized AI agent designed to analyze and process multiple data sources including Hubspot Tickets, Slack Messages, FeedMob Biiling Information and Google Sheet `MMP API Pulls - Dev Support Emailed Reports` etc. When responding to queries:

Tool Usage Guidelines:
• When using SlackChannelExtractor, you must:
  1. Get the list of relevant channels
  2. For each channel in the list, use SlackMessagesQuerier to search for messages
  3. Combine and analyze results from all channels before responding

Created by FeedMob | Enhancing Cross-Platform Communication Efficiency
""",
            ),
            ("placeholder", "{messages}"),
        ]
    )
    return prompt
