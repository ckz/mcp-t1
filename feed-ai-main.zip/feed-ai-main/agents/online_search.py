from smolagents import LiteLLMModel, DuckDuckGoSearchTool, ManagedAgent, VisitWebpageTool, FinalAnswerTool, CodeAgent, ToolCallingAgent, Tool
from smolagents.prompts import CODE_SYSTEM_PROMPT
from .tools.smolagents.add_reference_tool import AddReferenceTool
from services.bedrock_service import BedrockModel

def create_online_search_agent() -> CodeAgent:
    llm = LiteLLMModel(
        model_id=f"bedrock/{BedrockModel.PRO_MODEL_ID.value}",
    )

    tools = [
        DuckDuckGoSearchTool(),
        VisitWebpageTool(),
        __tavily_search_results_tool(),
        AddReferenceTool(),
        FinalAnswerTool()
    ]

    agent = ToolCallingAgent(
        tools=tools,
        model=llm,
    )
    managed_agent = ManagedAgent(
        agent=agent,
        name="managed_agent",
        description="This is an agent that can do web search.",
    )

    system_prompt = CODE_SYSTEM_PROMPT + f"""
For time-sensitive information (prices, current events, recent data):
1. Use web_search to get the most up-to-date information
2. Include the source and date of the information in your response

For all responses:
- Provide helpful, accurate information
- Include citations to sources
- Note when information might be outdated
"""

    agent = CodeAgent(model=llm, tools=tools, managed_agents=[managed_agent], system_prompt=system_prompt)
    return agent

def __tavily_search_results_tool() -> Tool:
    from langchain_community.tools import TavilySearchResults

    search_tool = TavilySearchResults(
        name="tavily_search_results",
        max_results=5,
        search_depth="advanced",
        include_answer=True,
        include_raw_content=False,
        include_images=False
    )
    return Tool.from_langchain(search_tool)
