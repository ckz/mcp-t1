from datetime import datetime
from typing import Any, List

from langchain_community.agent_toolkits.sql.toolkit import SQLDatabaseToolkit
from langchain_community.utilities.sql_database import SQLDatabase
from langchain_core.language_models import BaseChatModel
from langchain_core.prompts import ChatPromptTemplate
from langgraph.checkpoint.postgres.aio import AsyncPostgresSaver
from langgraph.prebuilt import create_react_agent

from .utils.agent_wrapper import AgentWrapper

# Rebuild the SQLDatabaseToolkit model
SQLDatabaseToolkit.model_rebuild(force=True, raise_errors=True)


def create_db_query_agent(
    llm: BaseChatModel,
    db_url: str,
    checkpointer: AsyncPostgresSaver,
    ignore_tables: List[str] = [],
    suffix_system_prompt: str = "",
) -> AgentWrapper:
    """
    Interacting with SQL databases
    """
    db = SQLDatabase.from_uri(db_url, ignore_tables=ignore_tables)
    toolkit = SQLDatabaseToolkit(
        db=db,
        llm=llm,
    )
    agent = create_react_agent(
        model=llm,
        tools=toolkit.get_tools(),
        prompt=__system_message(
            dialect=toolkit.dialect, top_k=10, suffix_system_prompt=suffix_system_prompt
        ),
        checkpointer=checkpointer,
    )
    return AgentWrapper(agent)


def __system_message(dialect: str, top_k: int, suffix_system_prompt: str = "") -> Any:
    current_date = datetime.now().strftime("%Y-%m-%d")
    system_prompt = f"""
You are an agent designed to interact with a SQL database.
Current date: {current_date}

Given an input question, create a syntactically correct {dialect} query to run, then look at the results of the query and return the answer.
Unless the user specifies a specific number of examples they wish to obtain, always limit your query to at most {top_k} results.
You can order the results by a relevant column to return the most interesting examples in the database.
Never query for all the columns from a specific table, only ask for the relevant columns given the question.
You have access to tools for interacting with the database.
Only use the below tools. Only use the information returned by the below tools to construct your final answer.
You MUST double check your query before executing it. If you get an error while executing a query, rewrite the query and try again.

DO NOT make any DML statements (INSERT, UPDATE, DELETE, DROP etc.) to the database.

To start you should ALWAYS look at the tables in the database to see what you can query.
Do NOT skip this step.
Then you should query the schema of the most relevant tables.

{suffix_system_prompt}
"""
    return ChatPromptTemplate.from_messages(
        [
            ("system", system_prompt),
            ("placeholder", "{messages}"),
        ]
    )
