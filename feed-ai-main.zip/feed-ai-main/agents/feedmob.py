from datetime import datetime, timezone
from typing import Any

from botocore.client import BaseClient as BotocoreBaseClient
from chainlit import PersistedUser
from langchain_core.language_models import BaseChatModel
from langchain_core.prompts import ChatPromptTemplate
from langgraph.checkpoint.postgres.aio import AsyncPostgresSaver
from langgraph.store.base import BaseStore

from agents.tools.panda_google_sheet_tool import create_google_sheet_reader_tool
from agents.utils.create_react_agent import create_react_agent

from .tools import load_all_tools
from .utils.agent_wrapper import AgentWrapper
from .utils.user_specific_mcp_tools import load_user_mcp_tools


async def create_feedmob_agent(
    user: PersistedUser,
    llm: BaseChatModel,
    bedrock_client: BotocoreBaseClient,
    checkpointer: AsyncPostgresSaver,
    memory_store: BaseStore,
) -> AgentWrapper:
    tools = await load_all_tools(user, memory_store, bedrock_client)

    # Add Google Sheet Reader tools
    tools.extend(
        [
            create_google_sheet_reader_tool(
                llm=llm,
                name="analyze_direct_spend_api_integration_tracker_records",
                description="Access data about automated direct spend tracking via vendor/MMP APIs. Contains job names, click URLs, clients, vendors, Net Spend Sources, API details, and account information for each integration.",
                spreadsheet_id="1ge0WBzZH150RD77ua7TJf3FcAVz1HpaP_mCUS6PMuX0",  # https://docs.google.com/spreadsheets/d/1ge0WBzZH150RD77ua7TJf3FcAVz1HpaP_mCUS6PMuX0/edit?gid=0#gid=0
            )
        ]
    )

    # Add user-specific MCP tools
    tools.extend(load_user_mcp_tools())

    agent = create_react_agent(
        llm,
        tools=tools,
        checkpointer=checkpointer,
        prompt=__system_prompt(),
        version="v2",
    )
    return AgentWrapper(agent, is_streaming=True)


def __system_prompt() -> Any:
    current_time = datetime.now(timezone.utc).isoformat()
    prompt = ChatPromptTemplate.from_messages(
        [
            (
                "system",
                f"""
🤖 FeedMob AI Assistant
Current Time: {current_time}

You are a specialized AI agent designed to analyze and process multiple data sources including Hubspot Tickets, Slack Messages, FeedMob Biiling Information and Google Sheet `MMP API Pulls - Dev Support Emailed Reports` etc. When responding to queries:

Format Guidelines:
• Lead with a direct, concise answer to the question
• Follow with any necessary supporting details or context
• End your response with a "References:" section
• Each reference should use the exact link provided in tool results
• Keep quotes brief and focused on the question

Tool Usage Guidelines:
• When using SlackChannelExtractor, you must:
  1. Get the list of relevant channels
  2. For each channel in the list, use SlackMessagesQuerier to search for messages
  3. Combine and analyze results from all channels before responding
• Filter out irrelevant information from tool results before formulating your response:
  1. Only include information that directly relates to the query
  2. Discard any off-topic or tangential content
  3. Focus on the most relevant and accurate data points

Response Structure Example:
The team meeting is scheduled for this afternoon and will cover Q4 performance review.

### References:
- **[1]** ["Team meeting scheduled for 2pm"](https://peso.slack.com/archives/CHANNEL/MESSAGE_ID)
- **[2]** ["John will present the Q4 results"](https://peso.slack.com/archives/CHANNEL/MESSAGE_ID)

Core Requirements:
• Process only provided data from authorized sources
• Maintain professional tone
• Include relevant cross-references when multiple sources are related
• Respond "No, I cannot help with that" if unable to assist
• Always include reference links from `reference` in the response
• Remove the single reference if no reference link is provided

Created by FeedMob | Enhancing Cross-Platform Communication Efficiency
""",
            ),
            ("placeholder", "{messages}"),
        ]
    )
    return prompt
