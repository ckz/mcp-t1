import uuid
from typing import Type

import chainlit as cl
from langchain_core.tools import BaseTool
from pydantic import BaseModel, Field

from agents.utils.message import send_tool_call_messaage
from utils.run_async import run_async


class DisplayImageToolInput(BaseModel):
    name: str = Field(description="The name of the image")
    image_url: str = Field(description="The URL of the image to display")
    message: str = Field(description="The message to display alongside the image")


class DisplayImageTool(BaseTool):
    name: str = "display_image"
    description: str = "Display an image from a given URL"
    args_schema: Type[BaseModel] = DisplayImageToolInput

    def _run(self, image_url: str, name: str, message: str):
        run_async(self._arun(image_url, name, message))

    async def _arun(self, image_url: str, name: str, message: str):
        name = f"image__{name}__{uuid.uuid4()}"
        image = cl.Image(url=image_url, name=name, display="inline", size="large")
        await send_tool_call_messaage(message, [image])
