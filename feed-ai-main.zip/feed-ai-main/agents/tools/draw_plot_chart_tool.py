import tempfile
import uuid
from typing import Type

import chainlit as cl
import plotly
from langchain_core.tools import BaseTool
from pydantic import BaseModel, Field

from agents.utils.message import send_tool_call_messaage


class DrawPlotChartInput(BaseModel):
    message: str = Field(description="The message to display alongside the chart")
    plotly_json_fig: str = Field(
        description="A JSON string representing the Plotly figure to be drawn"
    )


class DrawPlotChartTool(BaseTool):
    name: str = "DrawPlotChart"
    description: str = "Draws a Plotly chart based on the provided JSON figure and displays it with an accompanying message."
    args_schema: Type[BaseModel] = DrawPlotChartInput

    def _run(self, message: str, plotly_json_fig: str):
        import asyncio

        loop = asyncio.get_event_loop()
        return loop.run_until_complete(self._arun(message, plotly_json_fig))

    async def _arun(self, message: str, plotly_json_fig: str):
        fig = plotly.io.from_json(plotly_json_fig)
        name = f"chart__{uuid.uuid4()}"
        elements = [cl.Plotly(name=name, figure=fig, display="inline")]
        await send_tool_call_messaage(message, elements)


class DrawImagePlotChartTool(BaseTool):
    name: str = "DrawImagePlotChart"
    description: str = "Draws a Plotly chart based on the provided JSON figure and displays it with an accompanying message."
    args_schema: Type[BaseModel] = DrawPlotChartInput

    def _run(self, message: str, plotly_json_fig: str):
        import asyncio

        loop = asyncio.get_event_loop()
        return loop.run_until_complete(self._arun(message, plotly_json_fig))

    async def _arun(self, message: str, plotly_json_fig: str):
        fig = plotly.io.from_json(plotly_json_fig)
        name = f"chart__{uuid.uuid4()}"
        with tempfile.NamedTemporaryFile(
            mode="w", prefix=name, suffix=".png", delete=False
        ) as temp_file:
            fig.write_image(temp_file.name)
            image = cl.Image(
                path=temp_file.name, name=name, display="inline", size="large"
            )
            await send_tool_call_messaage(message, [image])
