from langchain.agents import AgentExecutor
from langchain_core.language_models import BaseChatModel
from langchain_core.tools import StructuredTool
from langchain_experimental.agents.agent_toolkits import create_pandas_dataframe_agent
from pydantic import BaseModel, Field

from services.google_sheet_reader_service import GoogleSheetReaderService
from utils.run_async import run_async


def create_google_sheet_reader_tool(
    llm: BaseChatModel,
    name: str,
    description: str,
    spreadsheet_id: str,
    worksheet_index: int = 0,
) -> StructuredTool:
    return StructuredTool.from_function(
        func=ChatWithGoogleSheetTool(llm, spreadsheet_id, worksheet_index).run,
        name=name,
        description=description,
        args_schema=ChatWithGoogleSheetInput,
    )


class ChatWithGoogleSheetInput(BaseModel):
    query: str = Field(description="The query to perform on the Google Sheet.")


class ChatWithGoogleSheetTool:
    def __init__(self, llm: BaseChatModel, spreadsheet_id: str, worksheet_index: int):
        self.llm = llm
        self.spreadsheet_id = spreadsheet_id
        self.worksheet_index = worksheet_index

    def run(self, query: str) -> str:
        return run_async(self.arun(query))

    async def arun(self, query: str) -> str:
        agent = self.__create_panda_df_agent(
            self.llm, self.spreadsheet_id, self.worksheet_index
        )
        result = await agent.ainvoke(query)
        return result["output"]

    def __create_panda_df_agent(
        self, llm: BaseChatModel, spreadsheet_id: str, worksheet_index: int
    ) -> AgentExecutor:
        service = GoogleSheetReaderService()
        df = service.read_all_records_as_df(spreadsheet_id, worksheet_index)
        spreadsheet_name = service.get_spreadsheet_name(spreadsheet_id)

        return create_pandas_dataframe_agent(
            llm=llm,
            df=df,
            allow_dangerous_code=True,
            include_df_in_prompt=True,
            verbose=True,
            prefix=f"This data is from google sheet, and the name of google sheet is {spreadsheet_name}",
        )
