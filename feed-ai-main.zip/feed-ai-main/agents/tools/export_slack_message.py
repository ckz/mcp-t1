import os
import chainlit as cl
from datetime import datetime, timedelta
from langchain_core.tools import BaseTool
from typing import Optional, Type
from pydantic import BaseModel, Field
from qdrant_client import QdrantClient
from services.export_slack_message_service import ExportSlackMessageService

class ExportSlackMessageInput(BaseModel):
    daterange: Optional[dict] = Field(None, description="Optional date range")

class ExportSlackMessageTool(BaseTool):
    name: str = "ExportSlackMessage"
    description: str = "Export Slack messages from a specific time range and send them to the user"
    args_schema: Type[BaseModel] = ExportSlackMessageInput

    def _run(self, daterange: Optional[dict] = None):
        import asyncio
        loop = asyncio.get_event_loop()
        return loop.run_until_complete(self._arun(daterange))

    async def _arun(self, daterange: Optional[dict] = None):
        start, end = self.__extract_daterange(daterange)
        qdrant_client = self.__qdrant_client()
        markdown_files = ExportSlackMessageService(qdrant_client).export(start_time=start, end_time=end)
        elements = [
            cl.File(
                name=file.filename(),
                path=file.path,
                display="inline",
                mime=file.mime()
            )
            for file in markdown_files
        ]
        await cl.Message(
            content=f"Exported Slack messages from {start} to {end}",
            elements=elements
        ).send()

        return None

    def __extract_daterange(self, daterange: Optional[dict] = None) -> tuple[datetime, datetime]:
        start_date_str = daterange.get('start') if daterange else None
        end_date_str = daterange.get('end') if daterange else None
        start_date = datetime.strptime(start_date_str, '%Y-%m-%d').date() if start_date_str is not None else None
        end_date = datetime.strptime(end_date_str, '%Y-%m-%d').date() if end_date_str is not None else None
        start_time = datetime.combine(start_date, datetime.min.time()) if start_date is not None else datetime.now() - timedelta(days=1)
        end_time = datetime.combine(end_date, datetime.max.time()) if end_date is not None else datetime.now()
        return start_time, end_time

    def __qdrant_client(self) -> QdrantClient:
        return QdrantClient(url=os.environ["QDRANT_URL"], api_key=os.environ["QDRANT_API_KEY"])
