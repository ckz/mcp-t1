import os
from langchain.tools import BaseTool
import pandas as pd
import httpx
from io import StringIO
from typing import List, Dict, Optional, Type
from pydantic import BaseModel, Field
from datetime import datetime
from utils.logging_config import logger

CLIENT_BILLING_API_URL = os.getenv("CLIENT_BILLING_API_URL")
CLIENT_BILLING_API_TOKEN = os.getenv("CLIENT_BILLING_API_TOKEN")
if not CLIENT_BILLING_API_URL or not CLIENT_BILLING_API_TOKEN:
    raise ValueError("CLIENT_BILLING_API_URL and CLIENT_BILLING_API_TOKEN environment variables must be set.")

class ClientBillingQuerierInput(BaseModel):
    month: str = Field(
        default=datetime.now().strftime("%Y-%m"),
        description="The month for which to query billing information in 'YYYY-MM' format."
    )

class ClientBillingQuerierTool(BaseTool):
    name: str = "ClientBillingQuerier"
    description: str = "Queries the billing information for clients."
    args_schema: Type[BaseModel] = ClientBillingQuerierInput

    def _run(self, month: str) -> List[Dict]:
        import asyncio
        loop = asyncio.get_event_loop()
        return loop.run_until_complete(self._arun(month))

    async def _arun(self, month: str) -> List[Dict]:
        logger.info(f"Querying client billing information for month: {month}")
        df = await self.__fetch_csv(month)
        if df is None:
            return []

        return df.to_dict(orient="records")

    async def __fetch_csv(self, month: str) -> Optional[pd.DataFrame]:
        url = f"{CLIENT_BILLING_API_URL}/client_billings"
        headers = {
            "Authorization": f"Bearer {CLIENT_BILLING_API_TOKEN}"
        }

        params = {"month": month}

        async with httpx.AsyncClient() as client:
            response = await client.get(url, headers=headers, params=params)
            if response.status_code == 200:
                logger.info("Successfully fetched CSV data.")
                csv_data = StringIO(response.text)  # Convert text response to a file-like object
                df = pd.read_csv(csv_data, on_bad_lines='skip')
                logger.info(f"CSV data shape: {df.shape}")
                return df
            else:
                logger.error(f"Failed to fetch CSV data. Status code: {response.status_code}")
                return None

