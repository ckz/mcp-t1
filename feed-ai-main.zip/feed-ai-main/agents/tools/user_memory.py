import uuid
from typing import Annotated, Optional

from langchain_core.tools import InjectedToolArg, BaseTool
from langgraph.store.base import BaseStore
from pydantic import BaseModel, Field

class UserMemory(BaseModel):
    id: Optional[uuid.UUID] = Field(None, description="The unique identifier for the memory.")
    content: str = Field(description="The content of the memory.")
    context: str = Field(description="The context of the memory.")

class PersistUserMemoryToolInput(BaseModel):
    memory: UserMemory = Field(description="The memory to store.")

class PersistUserMemoryTool(BaseTool):
    name: str = "PersistUserMemory"
    description: str = "Store user memories with context"

    def _run(
        self,
        memory: UserMemory,
        user_id: Annotated[str, InjectedToolArg],
        store: Annotated[BaseStore, InjectedToolArg],
    ) -> str:
        import asyncio
        loop = asyncio.get_event_loop()
        return loop.run_until_complete(self._arun(memory, user_id=user_id, store=store))

    async def _arun(
        self,
        memory: UserMemory,
        user_id: Annotated[str, InjectedToolArg],
        store: Annotated[BaseStore, InjectedToolArg],
    ) -> str:
        return await upsert_memory(memory, user_id=user_id, store=store)


async def upsert_memory(
    memory: UserMemory,
    *,
    # Hide these arguments from the model.
    user_id: Annotated[str, InjectedToolArg],
    store: Annotated[BaseStore, InjectedToolArg],
):
    mem_id = memory.id or uuid.uuid4()
    await store.aput(
        ("memories", user_id),
        key=str(mem_id),
        value={"content": memory.content, "context": memory.context},
    )
    return f"Stored memory {mem_id}"
