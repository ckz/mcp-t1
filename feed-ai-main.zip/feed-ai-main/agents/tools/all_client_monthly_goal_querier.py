import os
from datetime import datetime
from io import StringIO
from typing import Dict, List, Optional, Type

import httpx
import pandas as pd
from langchain.tools import BaseTool
from pydantic import BaseModel, Field

from utils.logging_config import logger

ALL_CLIENT_MONTHLY_GOAL_API_URL = os.getenv("ALL_CLIENT_MONTHLY_GOAL_API_URL")
ALL_CLIENT_MONTHLY_GOAL_API_TOKEN = os.getenv("ALL_CLIENT_MONTHLY_GOAL_API_TOKEN")
if not ALL_CLIENT_MONTHLY_GOAL_API_URL or not ALL_CLIENT_MONTHLY_GOAL_API_TOKEN:
    raise ValueError(
        "ALL_CLIENT_MONTHLY_GOAL_API_URL and ALL_CLIENT_MONTHLY_GOAL_API_TOKEN environment variables must be set."
    )


class AllClientMonthlyGoalQuerierInput(BaseModel):
    daterange: Optional[dict] = Field(None, description="Optional date range")


class AllClientMonthlyGoalQuerierTool(BaseTool):
    name: str = "AllClientMonthlyGoalQuerier"
    description: str = "Queries the monthly goal information for all clients."
    args_schema: Type[BaseModel] = AllClientMonthlyGoalQuerierInput

    def _run(self, daterange: Optional[dict] = None) -> List[Dict]:
        import asyncio

        loop = asyncio.get_event_loop()
        return loop.run_until_complete(self._arun(daterange))

    async def _arun(self, daterange: Optional[dict] = None) -> List[Dict]:
        start, end = self.__extract_daterange(daterange)
        logger.info(
            f"Querying all client monthly goal information for months: {start} to {end}"
        )
        df = await self.__fetch_csv(start, end)
        if df is None:
            return []

        return df.to_dict(orient="records")

    def __extract_daterange(self, daterange: Optional[dict] = None) -> tuple[str, str]:
        start_date_str = daterange.get("start") if daterange else None
        end_date_str = daterange.get("end") if daterange else None
        start_date = (
            datetime.strptime(start_date_str, "%Y-%m-%d").date()
            if start_date_str is not None
            else None
        )
        end_date = (
            datetime.strptime(end_date_str, "%Y-%m-%d").date()
            if end_date_str is not None
            else None
        )
        start_time = (
            datetime.combine(start_date, datetime.min.time())
            if start_date is not None
            else datetime.now()
        )
        end_time = (
            datetime.combine(end_date, datetime.max.time())
            if end_date is not None
            else datetime.now()
        )
        return start_time.strftime("%Y-%m"), end_time.strftime("%Y-%m")

    async def __fetch_csv(
        self, start_month: str, end_month: str
    ) -> Optional[pd.DataFrame]:
        url = f"{ALL_CLIENT_MONTHLY_GOAL_API_URL}/gpt_api/client_monthly_goals"
        headers = {"Authorization": f"Bearer {ALL_CLIENT_MONTHLY_GOAL_API_TOKEN}"}
        params = {"start_month": start_month, "end_month": end_month}

        async with httpx.AsyncClient(timeout=10.0) as client:
            response = await client.get(url, headers=headers, params=params)
            if response.status_code == 200:
                logger.info("Successfully fetched CSV data.")
                csv_data = StringIO(response.text)
                df = pd.read_csv(csv_data, on_bad_lines="skip")
                logger.info(f"CSV data shape: {df.shape}")
                return df
            else:
                logger.error(
                    f"Failed to fetch CSV data. Status code: {response.status_code}"
                )
                return None
