from typing import Dict, List, Type

from langchain_core.tools import BaseTool
from pydantic import BaseModel, Field

from db.qdrant import QdrantCollection
from services.vector_store_service import VectorStoreService


class GongTranscriptQuerierInput(BaseModel):
    text: str = Field(
        description="The input text to query the Gong call transcript database with."
    )
    startdate: str = Field(
        description="The start date of the date range to query the Gong call transcript database with."
    )
    enddate: str = Field(
        description="The end date of the date range to query the Gong call transcript database with."
    )


class GongTranscriptQuerierTool(BaseTool):
    name: str = "GongTranscriptQuerier"
    description: str = """
    Query Gong call transcripts using semantic search.
    Can filter by date range and search through call content, speaker information, and call metadata.
    Results include call details like title, duration, purpose, and direction (inbound/outbound).
    """
    args_schema: Type[BaseModel] = GongTranscriptQuerierInput

    def _run(self, text: str, startdate: str, enddate: str) -> List[Dict]:
        return self.__similarity_search_with_dates(text, startdate, enddate)

    def __similarity_search_with_dates(
        self, text: str, start_date: str, end_date: str, limit: int = 5
    ) -> List[Dict]:
        # Create date filter condition
        filter_condition = {
            "must": [
                {
                    "key": "metadata.start_time",
                    "range": {"gte": start_date, "lte": end_date},
                }
            ]
        }

        # Perform similarity search with filter
        docs = VectorStoreService(
            QdrantCollection.GONG_CALL_TRANSCRIPTS
        ).search_with_score(input=text, filter=filter_condition, k=limit)  # type: ignore

        # Format results
        results = []
        for doc, score in docs:
            metadata = doc.metadata

            result = {
                "content": doc.page_content,
                "relevance_score": score,
                "call_details": {
                    "id": metadata.get("call_id"),
                    "title": metadata.get("title"),
                    "start_time": metadata.get("start_time"),
                    "url": metadata.get("url"),
                },
                "chunk_info": {
                    "index": metadata.get("chunk_index"),
                    "total_chunks": metadata.get("total_chunks"),
                },
            }
            results.append(result)

        # Group results by call_id to avoid duplicate calls in results
        grouped_results = {}
        for result in results:
            call_id = result["call_details"]["id"]
            if call_id not in grouped_results:
                grouped_results[call_id] = result
            elif (
                result["relevance_score"] < grouped_results[call_id]["relevance_score"]
            ):
                # Keep the result with the better relevance score
                grouped_results[call_id] = result

        return list(grouped_results.values())
