from typing import List

from botocore.client import BaseClient as BotocoreBaseClient
from langchain.tools import BaseTool

from agents.base import AgentQuerierResult
from db.qdrant import QdrantCollection
from services.vector_store_service import VectorStoreService


def create_mmp_api_pulls_querier(bedrock_client: BotocoreBaseClient):
    return MmpApiPullsQuerierTool()


class MmpApiPullsQuerierTool(BaseTool):
    name: str = "MmpApiPullsQuerier"
    description: str = (
        "Query the MMP API Pulls - Dev Support Emailed Reports from Vecotor Store"
    )

    class Config:
        arbitrary_types_allowed = True

    def _run(self, query: str) -> List[AgentQuerierResult]:
        search_results = VectorStoreService(
            QdrantCollection.MMP_API_PULLS
        ).search_with_score(query, k=10)

        return [
            AgentQuerierResult(
                content=doc.page_content,
                score=score,
                metadata=doc.metadata,
                reference=None,
            )
            for doc, score in search_results
        ]
