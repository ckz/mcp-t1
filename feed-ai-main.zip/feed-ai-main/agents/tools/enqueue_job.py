import os
from typing import Optional, Type

import asyncpg
from langchain_core.tools import BaseTool
from pgqueuer.db import AsyncpgDriver
from pgqueuer.queries import Queries
from pydantic import BaseModel, Field

from agents.utils.human_in_the_loop import user_confirmation
from jobs import (
    CreateGlobalSuggestedPromptsJobPayload,
    CreateScheduledTaskForSpecificUserJobPayload,
    CreateUserSuggestedPromptsJobPayload,
    ExecuteScheduledTaskJobPayload,
    ExportSlackMessageViaEmailJobPayload,
    FixEmailDateJobPayload,
    SyncEmailDocumentsToDbJobPayload,
    SyncGithubIssuesToDbJobPayload,
    SyncGongTranscriptsToDbJobPayload,
    SyncSlackMessagesToDbJobPayload,
    SyncSlackMessagesV2ToDbJobPayload,
)
from jobs.base_job import JobPayload


class EnqueueJobToolInput(BaseModel):
    entrypoint: str = Field(..., description="Entrypoint name")
    payload: Optional[dict] = Field(None, description="Payload for the job")


class EnqueueJobTool(BaseTool):
    name: str = "EnqueueJob"
    description: str = "Enqueue a job to the job queue"
    args_schema: Type[BaseModel] = EnqueueJobToolInput

    def _run(self, entrypoint: str, payload: Optional[dict] = None) -> str:
        import asyncio

        loop = asyncio.get_event_loop()
        return loop.run_until_complete(self._arun(entrypoint, payload))

    async def _arun(self, entrypoint: str, payload: Optional[dict] = None) -> str:
        confirmed = await user_confirmation(f"""
        Do you want to enqueue the job with the following details?
        - Entrypoint: {entrypoint}
        - Payload: {payload}
        """)
        if confirmed:
            queries = await self.__get_pgqueuer_queries()
            payload_model = self.__get_job_payload(entrypoint, payload)
            if payload_model is not None:
                payload_bytes = payload_model.serialize()
            else:
                payload_bytes = None
            job_ids = await queries.enqueue(entrypoint, payload=payload_bytes)
            return f"""
            Enqueued job#{entrypoint} ids: {job_ids!r}
            - Entrypoint: {entrypoint}
            - Payload: {payload_model!r}
            """
        else:
            return "Action aborted."

    def __get_job_payload(
        self, entrypoint: str, payload: Optional[dict] = None
    ) -> Optional[JobPayload]:
        if entrypoint == "enqueue_create_user_suggested_prompts":
            return None

        if entrypoint == "export_slack_messages_via_email":
            if payload is None:
                raise ValueError(
                    "Payload is required for export_slack_messages_via_email entrypoint."
                )
            return ExportSlackMessageViaEmailJobPayload(**payload)

        if entrypoint == "sync_mmp_api_pulls":
            return None

        if entrypoint == "sync_slack_messages_to_db":
            if payload is None:
                raise ValueError(
                    "Payload is required for sync_slack_messages_to_db entrypoint."
                )
            return SyncSlackMessagesToDbJobPayload(**payload)

        if entrypoint == "sync_slack_messages_v2_to_db":
            if payload is None:
                raise ValueError(
                    "Payload is required for sync_slack_messages_v2_to_db entrypoint."
                )
            return SyncSlackMessagesV2ToDbJobPayload(**payload)

        if entrypoint == "sync_slack_channels_to_db":
            return None

        if entrypoint == "sync_gong_transcripts_to_db":
            if payload is None:
                raise ValueError(
                    "Payload is required for sync_gong_transcripts_to_db entrypoint."
                )
            return SyncGongTranscriptsToDbJobPayload(**payload)

        if entrypoint == "sync_github_issues_to_db":
            if payload is None:
                raise ValueError(
                    "Payload is required for sync_github_issues_to_db entrypoint."
                )
            return SyncGithubIssuesToDbJobPayload(**payload)

        if entrypoint == "sync_email_documents_to_db":
            if payload is None:
                raise ValueError(
                    "Payload is required for sync_email_documents_to_db entrypoint."
                )
            return SyncEmailDocumentsToDbJobPayload(**payload)

        if entrypoint == "execute_scheduled_task":
            if payload is None:
                raise ValueError(
                    "Payload is required for execute_scheduled_task entrypoint."
                )
            return ExecuteScheduledTaskJobPayload(**payload)

        if entrypoint == "create_user_suggested_prompts":
            if payload is None:
                raise ValueError(
                    "Payload is required for create_user_suggested_prompts entrypoint."
                )
            return CreateUserSuggestedPromptsJobPayload(**payload)

        if entrypoint == "create_global_suggested_prompts":
            if payload is None:
                raise ValueError(
                    "Payload is required for create_global_suggested_prompts entrypoint."
                )
            return CreateGlobalSuggestedPromptsJobPayload(**payload)

        if entrypoint == "create_scheduled_task_for_specific_user":
            if payload is None:
                raise ValueError(
                    "Payload is required for create_scheduled_task_for_specific_user entrypoint."
                )
            return CreateScheduledTaskForSpecificUserJobPayload(**payload)

        if entrypoint == "one_off__fix_email_date_job":
            if payload is None:
                raise ValueError(
                    "Payload is required for one_off__fix_email_date_job entrypoint."
                )
            return FixEmailDateJobPayload(**payload)

        raise ValueError(f"Unknown entrypoint: {entrypoint}")

    async def __get_pgqueuer_queries(self) -> Queries:
        database_url = os.environ["CHECKPOINTER_DATABASE_URL"]
        connection = await asyncpg.connect(dsn=database_url)
        driver = AsyncpgDriver(connection)
        return Queries(driver)
