from smolagents import Tool
from pydantic import BaseModel, Field

class Reference(BaseModel):
    url: str = Field(..., description="The URL of the reference.")
    title: str = Field(..., description="The title of the reference.")

class AddReferenceTool(Tool):
    name = "add_references"
    description = "Appends a references to the given output."
    inputs = {
        "output": {
            "type": "string",
            "description": "The original output from the agent."
        },
        "references": {
            "type": "object",
            "items": {
                "type": "object",
                "properties": {
                    "url": {
                        "type": "string",
                        "description": "The URL of the reference."
                    },
                    "title": {
                        "type": "string",
                        "description": "The title of the reference."
                    }
                }
            },
            "description": "A list of references to append."
        }
    }
    output_type = "string"

    def forward(self, output: str, references: list[dict]) -> str:
        references = [Reference(**reference) for reference in references]
        references_str = "\n\n".join([f"{reference.title}: {reference.url}" for reference in references])
        return f"{output}\n\nReferences:\n{references_str}" 
