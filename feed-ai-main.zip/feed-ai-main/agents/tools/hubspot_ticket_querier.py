import os
from datetime import date, datetime, timedelta
from enum import Enum
from typing import Dict, List, Optional

from botocore.client import BaseClient as BotocoreBaseClient
from langchain_core.tools import StructuredTool
from pydantic import BaseModel, Field
from qdrant_client import QdrantClient
from qdrant_client.models import (
    DatetimeRange,
    FieldCondition,
    Filter,
    MatchValue,
    SearchParams,
)

from agents.base import AgentQuerierResult
from db.qdrant import QdrantCollection
from services.bedrock_service import BedrockAIService
from services.vector_store_service import DEFAULT_SCORE_THRESHOLD


def create_hubspot_ticket_querier(bedrock_client: BotocoreBaseClient) -> StructuredTool:
    return StructuredTool.from_function(
        func=HubspotTicketQuerier().query,
        name="HubspotTicketQuerier",
        description="Query HubSpot tickets and notes to answer the user's question. Requires input and a daterange.",
        args_schema=HubspotTicketQuerierInput,
    )


class HubspotTicketPriority(str, Enum):
    P0 = "P0"
    P1 = "P1"
    P2 = "P2"
    P3 = "P3"


class HubspotTicketQuerierInput(BaseModel):
    start_time: datetime = Field(
        (datetime.now() - timedelta(days=30)),
        description="Required start time for the query",
    )
    end_time: datetime = Field(
        datetime.now(), description="Required end time for the query"
    )
    input: Optional[str] = Field(None, description="Optional input text for the query")
    priority: Optional[HubspotTicketPriority] = Field(
        None, description="Optional priority level for the query"
    )


class HubspotTicketQuerier:
    def __init__(self):
        self.hubspot_ticket = HubspotTicket()

    def query(
        self,
        start_time: datetime,
        end_time: datetime,
        input: Optional[str] = None,
        priority: Optional[HubspotTicketPriority] = None,
    ):
        """Query HubSpot tickets and notes to answer the user's question"""
        start_date = start_time.date()
        end_date = end_time.date()
        return self.hubspot_ticket.ask(
            input, start_date=start_date, end_date=end_date, priority=priority
        )


class HubspotTicket:
    def __init__(self):
        self.bedrock_service = BedrockAIService()
        self.qdrant_client = self.__qdrant_client()

    def ask(
        self,
        question: Optional[str],
        start_date: Optional[date] = None,
        end_date: Optional[date] = None,
        priority: Optional[HubspotTicketPriority] = None,
    ):
        search_result = self.query_hubspot_tickets(
            question=question,
            start_date=start_date,
            end_date=end_date,
            priority=priority,
        )
        return self.__format_search_result(search_result)

    def query_hubspot_tickets(
        self,
        question: Optional[str],
        top_k: int = 10,
        start_date: Optional[date] = None,
        end_date: Optional[date] = None,
        priority: Optional[str] = None,
    ):
        query_vector = (
            self.bedrock_service.get_embedding(question) if question else None
        )

        filter_conditions = []
        if start_date or end_date:
            start_time = (
                datetime.combine(start_date, datetime.min.time())
                if start_date
                else None
            )
            end_time = (
                datetime.combine(end_date, datetime.max.time()) if end_date else None
            )
            filter_conditions.append(
                FieldCondition(
                    key="ticket.hs_created_at",
                    range=DatetimeRange(
                        gte=start_time if start_time else None,
                        lte=end_time if end_time else None,
                    ),
                )
            )

        if priority is not None:
            filter_conditions.append(
                FieldCondition(
                    key="ticket.ticket_priority_advanced",
                    match=MatchValue(value=priority),
                )
            )

        if query_vector is None:
            scroll_result = self.qdrant_client.scroll(
                collection_name=QdrantCollection.HUBSPOT_TICKETS.value,
                scroll_filter=Filter(must=filter_conditions),
                limit=100,
                with_payload=True,
                with_vectors=False,
            )
            return scroll_result[0]
        else:
            search_result = self.qdrant_client.search(
                collection_name=QdrantCollection.HUBSPOT_TICKETS.value,
                query_vector=query_vector,
                query_filter=Filter(must=filter_conditions),
                limit=top_k,
                search_params=SearchParams(exact=True),
                score_threshold=DEFAULT_SCORE_THRESHOLD,
            )
            return search_result

    def __qdrant_client(self) -> QdrantClient:
        return QdrantClient(
            url=os.environ["QDRANT_URL"], api_key=os.environ["QDRANT_API_KEY"]
        )

    def __generate_reference_url(self, ticket_id: str) -> str:
        return f"https://app.hubspot.com/contacts/2992171/tickets/{ticket_id}"

    def __format_search_result(self, search_result) -> List[Dict]:
        results = []
        for result in search_result:
            ticket = result.payload["ticket"]
            notes = ticket["notes"]
            ticket_owner = ticket.get("owner")
            if ticket_owner:
                ticket_owner_name = (
                    f"{ticket_owner['first_name']} {ticket_owner['last_name']}"
                )
            else:
                ticket_owner_name = "Unknown Owner"

            text = f"""
    <HubSpot Ticket {ticket["hs_object_id"]}>
        <Subject>{ticket["subject"]}</Subject>
        <Content>
            {ticket["content"]}
        </Content>
        <Stage>{ticket["status"]}</Stage>
        <Priority>{ticket["ticket_priority_advanced"]}</Priority>
        <CreatedAt>{ticket["hs_created_at"]}</CreatedAt>
        <UpdatedAt>{ticket["hs_updated_at"]}</UpdatedAt>
        <Owner>{ticket_owner_name}</Owner>
        <Notes>
            """
            for note in notes:
                owner = note["owner"]
                if owner is None:
                    text += f"""
            \n<Note>**Unknown Owner**: {note["body"]}</Note>
                    """
                else:
                    text += f"""
            \n<Note>**{owner["first_name"]} {owner["last_name"]}**: {note["body"]}</Note>
                    """
            text += "\n</Notes>\n"
            text += f"\n</HubSpot Ticket {ticket['hs_object_id']}>\n"
            results.append(
                AgentQuerierResult(
                    content=text,
                    reference=self.__generate_reference_url(ticket["hs_object_id"]),
                    metadata=None,
                ).model_dump()
            )

        return results
