from datetime import datetime
from typing import List

from botocore.client import BaseClient as BotocoreBaseClient
from chainlit import PersistedUser
from langchain_core.tools import BaseTool, StructuredTool
from langgraph.store.base import BaseStore

from agents.online_search import create_online_search_agent
from mcp_services.client import get_mcp_tools
from models.user import User
from utils.feature_flag import FeatureFlag

from .all_client_monthly_goal_querier import AllClientMonthlyGoalQuerierTool
from .campaign_spends_querier import CampaignSpendsQuerierTool
from .client_billing_querier import ClientBillingQuerierTool
from .client_partner_search_tool import ClientPartnerSearchTool
from .display_image_tool import DisplayImageTool
from .draw_plot_chart_tool import DrawImagePlotChartTool
from .email_document_querier import EmailDocumentQuerierTool
from .gong_transcript_querier import GongTranscriptQuerierTool
from .hubspot_ticket_querier import create_hubspot_ticket_querier
from .memory_querier import MemoriesQuerierTool
from .mmp_api_pulls_querier import create_mmp_api_pulls_querier
from .personalize_slack_message_aggregator import PersonalizeSlackMessageAggregator
from .slack_channel_extractor import SlackChannelExtractorTool
from .slack_message_querier import create_slack_messages_querier
from .sync_status_querier import SyncStatusQuerierTool
from .vendor_billing_querier import VendorBillingQuerierTool


async def load_all_tools(
    user: PersistedUser, memory_store: BaseStore, bedrock_client: BotocoreBaseClient
) -> List[BaseTool]:
    memory_querier = MemoriesQuerierTool(user_id=user.id, memory_store=memory_store)
    hubspot_ticket_querier = create_hubspot_ticket_querier(bedrock_client)
    slack_channel_name_extractor = SlackChannelExtractorTool()
    slack_messages_querier = create_slack_messages_querier()
    email_document_querier = EmailDocumentQuerierTool()
    mmp_api_pulls_querier_tool = create_mmp_api_pulls_querier(bedrock_client)
    sync_status_querier = SyncStatusQuerierTool()
    client_billing_querier = ClientBillingQuerierTool()
    vendor_billing_querier = VendorBillingQuerierTool()
    all_client_monthly_goal_querier = AllClientMonthlyGoalQuerierTool()
    gong_transcript_querier = GongTranscriptQuerierTool()

    tools = [
        memory_querier,
        hubspot_ticket_querier,
        slack_channel_name_extractor,
        slack_messages_querier,
        email_document_querier,
        mmp_api_pulls_querier_tool,
        sync_status_querier,
        client_billing_querier,
        vendor_billing_querier,
        all_client_monthly_goal_querier,
        gong_transcript_querier,
    ]

    feature_flag = FeatureFlag()
    if feature_flag.is_enabled("search_tool", user.identifier):
        search_tool = StructuredTool.from_function(
            func=create_online_search_agent().run,
            name="OnlineSearchTool",
            description="Use this tool ONLY when you need to search for current, factual information not available in your knowledge base. For time-sensitive queries like prices or current events, I will automatically include today's date ({today}). Useful for recent events, news, facts, or when specific up-to-date information is required. Do not use for general knowledge or historical facts you already know.".format(
                today=datetime.now().strftime("%Y-%m-%d")
            ),
        )
        tools.append(search_tool)

    # Add campaign spends tool only in beta
    if feature_flag.is_enabled("campaign_spends_tool", user.identifier):
        client_partner_search_tool = ClientPartnerSearchTool(
            user_identifier=user.identifier
        )
        campaign_spends_querier = CampaignSpendsQuerierTool(
            user_identifier=user.identifier
        )
        tools.extend(
            [
                client_partner_search_tool,
                campaign_spends_querier,
                DrawImagePlotChartTool(),
            ]
        )

    if feature_flag.is_enabled("personalize_slack_message_aggregator", user.identifier):
        personalize_slack_message_aggregator = PersonalizeSlackMessageAggregator(
            user=User.from_persisted_user(user)
        )
        tools.append(personalize_slack_message_aggregator)

    if feature_flag.is_enabled("mcp_tools", user.identifier):
        mcp_tools = get_mcp_tools()
        tools.extend(mcp_tools)
        display_image_tool = DisplayImageTool()
        tools.append(display_image_tool)

    return tools
