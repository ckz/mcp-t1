from langchain_core.tools import BaseTool
from langchain_core.prompts import PromptTemplate
from pydantic import BaseModel, Field
from typing import Type, List

from agents.utils.llm_function_calling import StructuredOutputInstructor
from models.slack_channel import SlackChannelRepo
from db.database import get_async_session

class SlackChannelNameFormatter(BaseModel):
    channel_names: List[str] = Field(description="A list of Slack channel names.")

class SlackChannelExtractorInput(BaseModel):
    text: str = Field(description="The input text to extract the Slack channel name from.")

class SlackChannelExtractorTool(BaseTool):
    name: str = "SlackChannelExtractor"
    description: str = "Extracts and validates Slack channel names from input text by matching against a list of existing channels in the database."
    args_schema: Type[BaseModel] = SlackChannelExtractorInput

    def _run(self, text: str) -> List[str]:
        import asyncio
        loop = asyncio.get_event_loop()
        return loop.run_until_complete(self._arun(text))

    async def _arun(self, text: str) -> List[str]:
        channel_list = await self.__get_channel_list()
        channel_name = self.__parse_channel_name_from_text(text, channel_list)
        return channel_name

    async def __get_channel_list(self) -> list[str]:
        async for session in get_async_session():
            channels = await SlackChannelRepo(session).get_all()
            return [channel.channel_name for channel in channels]
        return []

    def __parse_channel_name_from_text(self, text: str, channel_list: list[str]) -> List[str]:
        prompt_template = """
Extract only the exact Slack channel names that are explicitly mentioned in the given text, matching against the provided list of channels.
Only return channel names that appear as distinct words/mentions in the text.
Return a list of channel names. If no exact matches are found, return an empty list.

Rules:
- Channel names must appear as distinct words in the text
- General phrases like "all channels" do not count as channel mentions

Channel List: {channel_list}
Text: {query}
        """
        prompt = PromptTemplate(template=prompt_template, input_variables=['channel_list', 'query']).format(channel_list=channel_list, query=text)
        formatter = StructuredOutputInstructor(SlackChannelNameFormatter).invoke_plus(prompt)
        return [channel_name for channel_name in formatter.channel_names if channel_name in channel_list]
