from typing import List, Dict, Optional, Type, Literal
from pydantic import BaseModel, Field, ConfigDict
from langchain.tools import BaseTool
from utils.logging_config import logger

from services.femini_service import FeminiService, FeminiAPIError

class CampaignSpendsQuerierInput(BaseModel):
    """Input schema for campaign spends querier"""
    level: Literal["client", "partner"] = Field(
        description="Aggregation level for the spend data (client or vendor/partner level)"
    )
    date_gteq: Optional[str] = Field(
        default=None,
        description="Filter by date greater than or equal to the specified date (YYYY-MM-DD), default is the first day of the current month"
    )
    date_lteq: Optional[str] = Field(
        default=None,
        description="Filter by date less than or equal to the specified date (YYYY-MM-DD), default is the current date"
    )
    legacy_client_id_in: Optional[List[int]] = Field(
        default=None,
        description="Array of client IDs to filter results"
    )
    legacy_partner_id_in: Optional[List[int]] = Field(
        default=None,
        description="Array of vendor/partner IDs to filter results"
    )

class CampaignSpendsQuerierTool(BaseTool):
    """Tool for querying campaign spend data"""
    name: str = "campaign_spends_querier"
    description: str = """
    Retrieves daily campaign spend data aggregated at client or vendor/partner level.
    Use this tool to analyze campaign performance and spending patterns.
    Note: 
    - Please ensure you have called the tool ClientPartnerSearch to get the client and partner IDs.
    - Please use legacy_client_id_in and legacy_partner_id_in to filter by specific client and partner combinations.
    
    Examples:
    - Get all client spends for current month
    - Get partner spends for specific date range
    - Filter spends by specific client IDs
    - Filter spends by specific partner IDs
    """
    args_schema: Type[BaseModel] = CampaignSpendsQuerierInput
    
    model_config = ConfigDict(arbitrary_types_allowed=True)
    service: Optional[FeminiService] = None
    
    def __init__(self, user_identifier: str, **kwargs):
        """
        Initialize the tool with FeminiService
        
        Args:
            user_identifier: User's email address. For Slack users, should include the SLACK_USER_PREFIX
            **kwargs: Additional arguments to pass to BaseTool
        """
        super().__init__(**kwargs)
        try:
            self.service = FeminiService(user_identifier)
        except ValueError as e:
            logger.error(f"Failed to initialize FeminiService: {str(e)}")
            raise

    def _run(
        self,
        level: Literal["client", "partner"],
        date_gteq: Optional[str] = None,
        date_lteq: Optional[str] = None,
        legacy_client_id_in: Optional[List[int]] = None,
        legacy_partner_id_in: Optional[List[int]] = None
    ) -> Dict:
        """
        Execute the campaign spends query
        
        Args:
            level: Aggregation level ("client" or "partner")
            date_gteq: Start date filter (YYYY-MM-DD)
            date_lteq: End date filter (YYYY-MM-DD)
            legacy_client_id_in: List of client IDs to filter
            legacy_partner_id_in: List of partner IDs to filter
            
        Returns:
            Dict: Campaign spend data
            
        Raises:
            Exception: If the query fails
        """
        try:
            logger.info(
                f"Querying campaign spends with level={level}, "
                f"date_gteq={date_gteq}, date_lteq={date_lteq}, "
                f"client_ids={legacy_client_id_in}, partner_ids={legacy_partner_id_in}"
            )
            
            if not self.service:
                raise ValueError("FeminiService not initialized")
            
            return self.service.get_campaign_spends(
                level=level,
                date_gteq=date_gteq,
                date_lteq=date_lteq,
                legacy_client_id_in=legacy_client_id_in,
                legacy_partner_id_in=legacy_partner_id_in
            )
            
        except FeminiAPIError as e:
            error_msg = f"Failed to fetch campaign spends: {str(e)}"
            logger.error(error_msg)
            raise Exception(error_msg)
        except Exception as e:
            error_msg = f"Unexpected error querying campaign spends: {str(e)}"
            logger.error(error_msg)
            raise Exception(error_msg)

    async def _arun(
        self,
        level: Literal["client", "partner"],
        date_gteq: Optional[str] = None,
        date_lteq: Optional[str] = None,
        legacy_client_id_in: Optional[List[int]] = None,
        legacy_partner_id_in: Optional[List[int]] = None
    ) -> Dict:
        """Async implementation of the tool"""
        return self._run(
            level=level,
            date_gteq=date_gteq,
            date_lteq=date_lteq,
            legacy_client_id_in=legacy_client_id_in,
            legacy_partner_id_in=legacy_partner_id_in
        )
