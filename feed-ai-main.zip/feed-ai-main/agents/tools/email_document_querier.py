import os
from datetime import date, datetime, timedelta, timezone
from typing import Type

from langchain_core.tools import BaseTool
from pydantic import BaseModel, ConfigDict, Field
from qdrant_client import models

from agents.base import AgentQuerierResult
from services.vector_store_service import (
    DEFAULT_SCORE_THRESHOLD,
    QdrantCollection,
    VectorStoreService,
)


class EmailDocumentQuerierInput(BaseModel):
    text: str = Field(
        description="The input text to query the email document database with."
    )
    limit: int = Field(
        10, description="Optional limit for the number of results to return"
    )
    start_date: date = Field(
        default_factory=lambda: (
            datetime.now(timezone.utc) - timedelta(days=30)
        ).date(),
        description="Start date for the query",
    )
    end_date: date = Field(
        default_factory=lambda: datetime.now(timezone.utc).date(),
        description="End date for the query",
    )


class EmailDocumentQuerierTool(BaseTool):
    name: str = "EmailDocumentQuerier"
    description: str = (
        "Using text embeddings to query a database of emails for similar content."
    )
    args_schema: Type[BaseModel] = EmailDocumentQuerierInput

    model_config = ConfigDict(arbitrary_types_allowed=True)

    def __init__(self):
        super().__init__()

    def _run(
        self, text: str, start_date: date, end_date: date, limit: int = 10
    ) -> list[AgentQuerierResult]:
        return self.__similarity_search(
            text, limit=limit, start_date=start_date, end_date=end_date
        )

    def __similarity_search(
        self, text: str, start_date: date, end_date: date, limit: int = 10
    ) -> list[AgentQuerierResult]:
        results = []
        query_filter = models.Filter(
            must=[
                models.FieldCondition(
                    key="metadata.date",
                    range=models.DatetimeRange(gte=start_date, lte=end_date),
                )
            ]
        )
        search_result = VectorStoreService(
            QdrantCollection.EMAIL_DOCUMENTS
        ).search_with_score(
            input=text,
            filter=query_filter,
            k=limit,
            score_threshold=DEFAULT_SCORE_THRESHOLD,
        )
        for document, score in search_result:
            metadata = document.metadata
            document_id = metadata.get("document_id")

            results.append(
                AgentQuerierResult(
                    score=score,
                    metadata={
                        "subject": metadata.get("subject"),
                        "from": metadata.get("from"),
                        "to": metadata.get("to"),
                        "date": metadata.get("date"),
                        "created_at": metadata.get("created_at"),
                        "updated_at": metadata.get("updated_at"),
                    },
                    content=document.page_content,
                    reference=self.__format_reference_url(document_id)
                    if document_id
                    else None,
                )
            )
        return results

    def __format_reference_url(self, document_id: str) -> str:
        base_url = os.getenv("FEMINI_BASE_URL")
        if not base_url:
            raise ValueError("FEMINI_BASE_URL environment variable not set.")
        return f"{base_url}/documents/{document_id}"
