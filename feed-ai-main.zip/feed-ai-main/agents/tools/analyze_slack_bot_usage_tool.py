import os
from langchain_core.tools import StructuredTool
from smolagents import LiteLLMModel, CodeAgent, tool
from sqlalchemy.engine import Engine
from services.bedrock_service import BedrockModel
from sqlalchemy import (
    create_engine,
    inspect,
    text,
)

def create_analyze_slack_bot_usage_tool() -> StructuredTool:
    return StructuredTool.from_function(
        func=create_analyze_slack_bot_usage_agent().run,
        name="AnalyzeSlackBotUsageTool",
        description="""Allows you to analyze the usage of the Slack bot.
        Use this tool to get comprehensive information about:
        - User interactions with the bot
        - Conversation threads
        - Interaction steps
        The tool will return detailed, formatted text output."""
    )

def create_analyze_slack_bot_usage_agent() -> CodeAgent:
    llm = LiteLLMModel(
        model_id=f"bedrock/{BedrockModel.PRO_MODEL_ID.value}",
    )

    sql_engine.description = __get_updated_tool_description()
    tools = [sql_engine]
    return CodeAgent(tools=tools, model=llm)

@tool
def sql_engine(query: str) -> str:
    """
    Allows you to perform SQL queries on the table. Returns a string representation of the result.

    Args:
        query: The query to perform. This should be correct SQL.
    """
    output = ""
    engine = get_engine()
    with engine.connect() as con:
        rows = con.execute(text(query))
        for row in rows:
            output += "\n" + str(row)
    return output

def __get_updated_tool_description() -> str:
    updated_description = """Allows you to perform SQL queries on the table. Beware that this tool's output is a string representation of the execution output.
It can use the following tables:"""

    inspector = inspect(get_engine())
    if inspector is None:
        raise Exception("Inspector is None")

    for table in ["users", "threads", "steps"]:
        columns_info = [(col["name"], col["type"]) for col in inspector.get_columns(table)]

        table_description = f"Table '{table}':\n"

        table_description += "Columns:\n" + "\n".join([f"  - {name}: {col_type}" for name, col_type in columns_info])
        updated_description += "\n\n" + table_description

    updated_description += """
\n\nDatabase Schema Description:

1. Users Table
   - Contains user information
   - Default: Only Slack users (identifier starts with 'slack_')
   - Filter Slack users with: users.identifier ILIKE 'slack_%'

2. Threads Table
   - Represents conversations between users and the bot
   - One thread can contain multiple interaction steps
   - Links to users via userId

3. Steps Table
   - Contains individual interactions (messages)
   - Types: 'user_message' (user input) or 'assistant_message' (bot response)
   - Links to threads via threadId

Example Query - Get All User-Bot Interactions:
```sql
SELECT
    u.identifier as user,
    t.name as thread_name,
    t.id as thread_id,
    s.output as message,
    s."type" as message_type,
    s."createdAt"
FROM threads AS t
LEFT JOIN users AS u ON t."userId" = u.id
LEFT JOIN steps AS s ON t.id = s."threadId"
    AND s."type" in ('user_message', 'assistant_message')
WHERE u.identifier ILIKE 'slack_%'
ORDER BY u.identifier, s."createdAt" ASC;
```
"""

    return updated_description

def __create_engine() -> Engine:
    database_url = os.environ["CHECKPOINTER_DATABASE_URL"]
    return create_engine(
        url=database_url,
        echo=True,
        pool_size=5,
        max_overflow=10,
        pool_timeout=30,
        pool_recycle=1800  # Recycle connections after 30 minutes
    )

# Create a single engine instance
_engine: Engine | None = None

def get_engine() -> Engine:
    global _engine
    if _engine is None:
        _engine = __create_engine()
    return _engine
