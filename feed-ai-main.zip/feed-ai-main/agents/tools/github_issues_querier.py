from datetime import datetime, timedelta
from typing import Optional

from langchain.docstore.document import Document
from langchain_core.tools import StructuredTool
from pydantic import BaseModel, Field
from qdrant_client.models import DatetimeRange, FieldCondition, Filter, MatchValue

from agents.base import AgentQuerierResult
from db.qdrant import QdrantCollection, create_qdrant_client
from jobs.sync_github_issues_to_db_job import GithubRepo
from services.vector_store_service import VectorStoreService


def create_github_issues_querier() -> StructuredTool:
    return StructuredTool.from_function(
        func=GithubIssuesQuerier().query,
        name="GithubIssuesQuerier",
        description="Query GitHub issues to answer the user's question. Requires input and a daterange.",
        args_schema=GithubIssuesQuerierInput,
    )


class GithubIssuesQuerierInput(BaseModel):
    input: Optional[str] = Field(None, description="Optional input text for the query")
    start_time: datetime = Field(
        (datetime.now() - timedelta(days=30)),
        description="Required start time for the query",
    )
    end_time: datetime = Field(
        datetime.now(), description="Required end time for the query"
    )
    repo: Optional[GithubRepo] = Field(
        None, description="Optional GitHub repository name for the query"
    )
    limit: int = Field(
        10, description="Optional limit for the number of results to return"
    )
    offset: int = Field(
        0, description="Optional offset for the number of results to skip"
    )


class GithubIssuesQuerier:
    def query(
        self,
        start_time: datetime,
        end_time: datetime,
        limit: int = 10,
        offset: int = 0,
        repo: Optional[GithubRepo] = None,
        input: Optional[str] = None,
    ):
        """Query GitHub issues to answer the user's question. Requires input and a date range."""
        return GithubIssuesAgent().ask(
            input=input,
            start_time=start_time,
            end_time=end_time,
            repo=repo,
            limit=limit,
            offset=offset,
        )


class GithubIssuesAgent:
    def __init__(self):
        self.qdrant_client = create_qdrant_client()

    def ask(
        self,
        input: Optional[str],
        start_time: datetime,
        end_time: datetime,
        repo: Optional[str],
        limit: int = 10,
        offset: int = 0,
    ):
        if input is None or input.strip() == "":
            return self.__scroll_github_issues(
                start_time=start_time,
                end_time=end_time,
                repo=repo,
                limit=limit,
                offset=offset,
            )

        results = self.__query_github_issues(
            question=input,
            start_time=start_time,
            end_time=end_time,
            repo=repo,
            limit=limit,
            offset=offset,
        )

        return [
            AgentQuerierResult(
                content=result.page_content,
                reference=result.metadata.get("url"),
                metadata={
                    "id": result.metadata.get("id"),
                    "number": result.metadata.get("number"),
                    "title": result.metadata.get("title"),
                    "state": result.metadata.get("state"),
                    "created_at": result.metadata.get("created_at"),
                    "updated_at": result.metadata.get("updated_at"),
                    "repo": result.metadata.get("repo"),
                },
                score=score,
            ).model_dump()
            for result, score in results
        ]

    def __scroll_github_issues(
        self,
        start_time: Optional[datetime] = None,
        end_time: Optional[datetime] = None,
        repo: Optional[str] = None,
        limit: int = 10,
        offset: int = 0,
    ):
        filter_conditions = []
        if start_time or end_time:
            filter_conditions.append(
                FieldCondition(
                    key="metadata.created_at",
                    range=DatetimeRange(gte=start_time, lte=end_time),
                )
            )
        if repo:
            filter_conditions.append(
                FieldCondition(key="metadata.repo", match=MatchValue(value=repo))
            )

        query_filter = Filter(must=filter_conditions)

        results = self.qdrant_client.scroll(
            collection_name=QdrantCollection.GITHUB_ISSUES.value,
            scroll_filter=query_filter,
            limit=limit,
            offset=offset,
            with_payload=True,
            with_vectors=False,
        )

        return [
            Document(
                page_content=point.payload.get("page_content") or "",
                metadata=point.payload.get("metadata"),
            )
            for point in results[0]
            if point.payload
        ]

    def __query_github_issues(
        self,
        question: str,
        start_time: Optional[datetime] = None,
        end_time: Optional[datetime] = None,
        repo: Optional[str] = None,
        limit: int = 5,
        offset: int = 0,
    ):
        filter_conditions = []
        if start_time or end_time:
            filter_conditions.append(
                FieldCondition(
                    key="metadata.created_at",
                    range=DatetimeRange(gte=start_time, lte=end_time),
                )
            )
        if repo:
            filter_conditions.append(
                FieldCondition(key="metadata.repo", match=MatchValue(value=repo))
            )

        return VectorStoreService(QdrantCollection.GITHUB_ISSUES).search_with_score(
            input=question,
            filter=Filter(must=filter_conditions),
            k=limit,
            offset=offset,
        )
