from typing import Optional, Type

from langchain_core.tools import BaseTool
from pydantic import BaseModel, Field

from agents.base import AgentQuerierResult
from db.database import get_async_session
from models.sync_status import SourceType, SyncStatusRepo
from utils.run_async import run_async


class SyncStatusQueryInput(BaseModel):
    source: SourceType = Field(
        description="The source type to query",
    )


class SyncStatusQuerierTool(BaseTool):
    name: str = "SyncStatusQuerier"
    description: str = "Query the sync status of a source type from the database. Include source, last_update_at, etc."
    args_schema: Type[BaseModel] = SyncStatusQueryInput

    model_config = {
        "json_schema_extra": {
            "properties": {
                "source": {
                    "type": "string",
                    "description": "The source type to query.",
                    "enum": [e.value for e in SourceType],
                }
            }
        }
    }

    def _run(self, source: SourceType) -> Optional[AgentQuerierResult]:
        return run_async(self._arun(source))

    async def _arun(self, source: SourceType) -> Optional[AgentQuerierResult]:
        async for session in get_async_session():
            repo = SyncStatusRepo(session)
            item = await repo.get_by_source(source)
            if not item:
                return None

            return AgentQuerierResult(
                content=item.last_updated_at.isoformat(),
                metadata={"source": item.source, "payload": item.payload},
                reference=None,
            )

        return None
