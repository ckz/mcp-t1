from typing import Literal, Optional, List, Tuple, Type
from langchain.tools import BaseTool
from pydantic import BaseModel, Field, ConfigDict
from langchain_core.prompts import PromptTemplate
from agents.utils.llm_function_calling import StructuredOutputInstructor
from services.femini_service import FeminiService, FeminiAPIError
from utils.logging_config import logger

class EntityResult(BaseModel):
    """Structure for individual search result"""
    id: int = Field(..., description="Entity identifier")
    name: str = Field(..., description="Entity name")
    type: Literal["client", "partner"] = Field(..., description="Type of entity (client/partner)")

class SearchResults(BaseModel):
    """Structure for complete search results"""
    results: List[EntityResult] = Field(..., description="List of search results")

class SearchParameters(BaseModel):
    """Structure for search parameters"""
    query: str = Field(..., description="Natural language query")
    partner_name_or_client_name_list: list[str] = Field(..., description="List of partner or client names to search")

class ClientPartnerSearchTool(BaseTool):
    """Tool for intelligent search and retrieval of client and partner information."""
    
    name: str = "ClientPartnerSearch"
    description: str = """Tool for searching and retrieving information about clients and partners. This tool should be called when you need to use client or partner information as parameters.

Takes a search query and a list of client or partner names to search against.
Returns structured search results containing matching entities and their details.

Args:
    query (str): The search query to filter results
    partner_name_or_client_name_list (list[str]): List of client/partner names to search

Returns:
    SearchResults containing matched entities and their information.
"""
    args_schema: Type[BaseModel] = SearchParameters

    model_config = ConfigDict(arbitrary_types_allowed=True)
    femini_service: Optional[FeminiService] = None

    def __init__(self, user_identifier: str):
        """Initialize the search tool with required services."""
        super().__init__()
        self.femini_service = FeminiService(user_identifier)

    def _run(
        self,
        query: str,
        partner_name_or_client_name_list: list[str]
    ) -> SearchResults:
        """Execute the search tool."""
        if self.femini_service is None:
            raise ValueError("FeminiService is not initialized")

        if not partner_name_or_client_name_list:
            return SearchResults(results=[])

        (client_results, partner_results) = self.__get_client_and_partner_results(partner_name_or_client_name_list)
        prompt_template = """
Based on the search query: {query}

Client Results:
{client_results}

Partner Results:
{partner_results}

Please analyze the above results and provide a clear list of matching clients and partners with their IDs and names in a concise format.
        """
        prompt = PromptTemplate(template=prompt_template, input_variables=['query', 'client_results', 'partner_results']).format(
            query=query,
            client_results=client_results,
            partner_results=partner_results
        )
        formatter = StructuredOutputInstructor(SearchResults).invoke_plus(prompt)
        return formatter


    async def _arun(self, query: str, partner_name_or_client_name_list: list[str]) -> SearchResults:
        """Async version of _run."""
        return self._run(query, partner_name_or_client_name_list)


    def __get_client_and_partner_results(
            self,
            partner_name_or_client_name_list: list[str]
    ) -> Tuple[list[EntityResult], list[EntityResult]]:
        """Get client and partner search results."""
        if self.femini_service is None:
            raise ValueError("FeminiService not initialized")

        client_results = []
        partner_results = []
        for name in partner_name_or_client_name_list:
            try:
                client_search_results = self.femini_service.search_clients(name)
                for client in client_search_results["results"]:
                    client_results.append(
                        EntityResult(id=client['legacy_id'], name=client['name'], type="client")
                    )
            except FeminiAPIError as e:
                logger.error(f"Error searching for client: {e}")

            try:
                partner_search_results = self.femini_service.search_partners(name_cont=name)
                for partner in partner_search_results["results"]:
                    partner_results.append(
                        EntityResult(id=partner['legacy_id'], name=partner['name'], type="partner")
                    )
            except FeminiAPIError as e:
                logger.error(f"Error searching for partner: {e}")

        return (client_results, partner_results)
