import os
from langchain.tools import BaseTool
import pandas as pd
import httpx
from io import StringIO
from typing import List, Dict, Optional, Type
from pydantic import BaseModel, Field
from datetime import datetime
from utils.logging_config import logger

VENDOR_BILLING_API_URL = os.getenv("VENDOR_BILLING_API_URL")
VENDOR_BILLING_API_TOKEN = os.getenv("VENDOR_BILLING_API_TOKEN")
if not VENDOR_BILLING_API_URL or not VENDOR_BILLING_API_TOKEN:
    raise ValueError("VENDOR_BILLING_API_URL and VENDOR_BILLING_API_TOKEN environment variables must be set.")

class VendorBillingQuerierInput(BaseModel):
    month: str = Field(
        default=datetime.now().strftime("%Y-%m"),
        description="The month for which to query billing information in 'YYYY-MM' format."
    )

class VendorBillingQuerierTool(BaseTool):
    name: str = "VendorBillingQuerier"
    description: str = "Queries the billing information for vendors/partners."
    args_schema: Type[BaseModel] = VendorBillingQuerierInput

    def _run(self, month: str) -> List[Dict]:
        import asyncio
        loop = asyncio.get_event_loop()
        return loop.run_until_complete(self._arun(month))

    async def _arun(self, month: str) -> List[Dict]:
        logger.info(f"Querying vendor billing information for month: {month}")
        df = await self.__fetch_csv(month)
        if df is None:
            return []

        return df.to_dict(orient="records")

    async def __fetch_csv(self, month: str) -> Optional[pd.DataFrame]:
        url = f"{VENDOR_BILLING_API_URL}/vendor_monthly_billings"
        headers = {
            "Authorization": f"Bearer {VENDOR_BILLING_API_TOKEN}"
        }

        params = {"month": month}

        async with httpx.AsyncClient() as client:
            response = await client.get(url, headers=headers, params=params)
            if response.status_code == 200:
                logger.info("Successfully fetched CSV data.")
                csv_data = StringIO(response.text)  # Convert text response to a file-like object
                df = pd.read_csv(csv_data, on_bad_lines='skip')
                logger.info(f"CSV data shape: {df.shape}")
                return df
            else:
                logger.error(f"Failed to fetch CSV data. Status code: {response.status_code}")
                return None

