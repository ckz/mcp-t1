import uuid
from typing import Optional, Annotated
from pydantic import BaseModel, Field
from langchain_core.tools import InjectedToolArg, BaseTool
from langgraph.store.base import BaseStore

class SharedMemory(BaseModel):
    id: Optional[uuid.UUID] = Field(None, description="The unique identifier for the memory.")
    content: str = Field(description="The content of the memory.")
    context: str = Field(description="The context of the memory.")
    shared_by: str = Field(description="The user info of the person who shared the memory.")

async def upsert_memory(
    memory: SharedMemory,
    *,
    # Hide these arguments from the model.
    user_id: Annotated[str, InjectedToolArg],
    store: Annotated[BaseStore, InjectedToolArg],
):
    mem_id = memory.id or uuid.uuid4()
    await store.aput(
        ("memories", "shared"),
        key=str(mem_id),
        value={
            "content": memory.content,
            "context": memory.context,
            "shared_by": memory.shared_by,
            "shared_by_id": user_id
        },
    )
    return f"Stored shared-memory {mem_id}"
