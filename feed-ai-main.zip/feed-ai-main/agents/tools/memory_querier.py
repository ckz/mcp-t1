from typing import Type

from langchain_core.tools import BaseTool
from langgraph.store.base import BaseStore
from pydantic import BaseModel, Field

class MemoriesQuerierToolInput(BaseModel):
    text: str = Field(description="The text to search for in the memories.")

class MemoriesQuerierTool(BaseTool):
    """
    Search and retrieve user-memories and shared-memories using semantic text similarity
    """
    name: str = "MemoriesQuerier"
    description: str = "Search and retrieve user-memories and shared-memories using semantic text similarity"
    args_schema: Type[BaseModel] = MemoriesQuerierToolInput
    user_id: str = Field(description="The user ID to search for user-memories.")
    memory_store: BaseStore = Field(description="The store to search for memories.")

    class Config:
        arbitrary_types_allowed = True

    def _run(
        self,
        text: str,
    ) -> dict[str, list[str]]:
        import asyncio
        loop = asyncio.get_event_loop()
        return loop.run_until_complete(self._arun(text))

    async def _arun(
        self,
        text: str
    ) -> dict[str, list[str]]:
        user_memories = await self.__query_user_memories(text)
        shared_memories = await self.__query_shared_memories(text)
        return {
            "user_memories": user_memories,
            "shared_memories": shared_memories,
        }

    async def __query_user_memories(self, text: str) -> list[str]:
            memories = await self.memory_store.asearch(
                ("memories", self.user_id),
                query=text,
                limit=10,
            )
            return [f"[{mem.key}]: {mem.value} (similarity: {mem.score})" for mem in memories]

    async def __query_shared_memories(self, text: str) -> list[str]:
        memories = await self.memory_store.asearch(
            ("memories", "shared"),
            query=text,
            limit=10,
        )
        return [f"[{mem.key}]: {mem.value} (similarity: {mem.score})" for mem in memories]
