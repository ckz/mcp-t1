import os
import uuid
from datetime import datetime, timedelta, timezone
from typing import Optional

from langchain.docstore.document import Document
from langchain_core.tools import StructuredTool
from langchain_qdrant import QdrantVectorStore
from pydantic import BaseModel, Field
from qdrant_client import QdrantClient
from qdrant_client.models import (
    DatetimeRange,
    Direction,
    FieldCondition,
    Filter,
    MatchValue,
    OrderBy,
)

from agents.base import AgentQuerierResult
from db.qdrant import QdrantCollection
from services.bedrock_service import BedrockAIService
from services.vector_store_service import DEFAULT_SCORE_THRESHOLD, VectorStoreService
from utils.datetime import normalize_time


def create_slack_messages_querier() -> StructuredTool:
    return StructuredTool.from_function(
        func=SlackMessagesQuerier().query,
        name="SlackMessagesQuerier",
        description="Query Slack messages and threads to answer the user's question. Requires UTC times for start_time and end_time parameters.",
        args_schema=SlackMessagesQuerierInput,
    )


class SlackMessagesQuerierInput(BaseModel):
    input: Optional[str] = Field(None, description="Optional input text for the query")
    start_time: datetime = Field(
        default_factory=lambda: datetime.now(timezone.utc) - timedelta(days=30),
        description="Start time for the query in UTC. The AI should convert user's local time to UTC before querying.",
    )
    end_time: datetime = Field(
        default_factory=lambda: datetime.now(timezone.utc),
        description="End time for the query in UTC. The AI should convert user's local time to UTC before querying.",
    )
    channel: Optional[str] = Field(
        None, description="Optional Slack channel name for the query"
    )


class SlackMessagesQuerier:
    def query(
        self,
        start_time: datetime,
        end_time: datetime,
        channel: Optional[str] = None,
        input: Optional[str] = None,
        score_threshold: Optional[float] = DEFAULT_SCORE_THRESHOLD,
    ):
        """Query Slack messages and threads to answer the user's question. Requires input and a date range."""
        start_time = normalize_time(start_time)
        end_time = normalize_time(end_time)
        return SlackMessageAgent().ask(
            input=input,
            start_time=start_time,
            end_time=end_time,
            channel_name=channel,
            score_threshold=score_threshold,
        )


class SlackMessageAgent:
    COLLECTION_NAME = QdrantCollection.SLACK_API_MESSAGES_V2

    def __init__(self):
        self.qdrant_client = self.__qdrant_client()
        self.vector_store = self.__vector_store()

    def ask(
        self,
        input: Optional[str],
        start_time: datetime,
        end_time: datetime,
        channel_name: Optional[str],
        limit: int = 5,
        score_threshold: Optional[float] = None,
    ):
        if input is None or input.strip() == "":
            return self.__scroll_slack_messages(
                start_time=start_time,
                end_time=end_time,
                channel_name=channel_name,
                limit=50,
            )

        # Get initial results
        results = self.__query_slack_messages(
            question=input,
            start_time=start_time,
            end_time=end_time,
            channel_name=channel_name,
            limit=limit,
            score_threshold=score_threshold,
        )
        querier_results = []

        # For each result, get related messages using scroll
        for result, score in results:
            channel_id = result.metadata.get("channel_id") or ""
            timestamp = result.metadata.get("timestamp")
            message_id = result.metadata.get("id") or ""

            related_messages = [
                AgentQuerierResult(
                    content=message.page_content,
                    reference=message.metadata.get("permalink"),
                    metadata={
                        "id": message.metadata.get("id"),
                        "message_ts": message.metadata.get("message_ts"),
                        "timestamp": message.metadata.get("timestamp"),
                    },
                ).model_dump()
                for message in self.__get_related_slack_messages(
                    point_id=str(uuid.uuid5(uuid.NAMESPACE_DNS, message_id)),
                    channel_id=channel_id,
                    timestamp=timestamp,
                    limit=1,  # Number of messages to fetch before and after
                )
            ]
            querier_results.append(
                AgentQuerierResult(
                    content=result.page_content,
                    reference=result.metadata.get("permalink"),
                    metadata={
                        "id": message_id,
                        "channel_id": channel_id,
                        "channel_name": result.metadata.get("channel_name"),
                        "message_ts": result.metadata.get("message_ts"),
                        "timestamp": timestamp,
                        "related_messages": related_messages,
                    },
                    score=score,
                ).model_dump()
            )
        return querier_results

    def __scroll_slack_messages(
        self,
        start_time: Optional[datetime] = None,
        end_time: Optional[datetime] = None,
        channel_name: Optional[str] = None,
        limit: int = 5,
    ):
        filter_conditions = []
        if start_time or end_time:
            filter_conditions.append(
                FieldCondition(
                    key="metadata.timestamp",
                    range=DatetimeRange(
                        gte=start_time if start_time else None,
                        lte=end_time if end_time else None,
                    ),
                )
            )
        if channel_name:
            filter_conditions.append(
                FieldCondition(
                    key="metadata.channel_name", match=MatchValue(value=channel_name)
                )
            )

        query_filter = Filter(must=filter_conditions)

        results = self.qdrant_client.scroll(
            collection_name=self.COLLECTION_NAME.value,
            scroll_filter=query_filter,
            limit=limit,
            order_by=OrderBy(key="metadata.timestamp", direction=Direction.DESC),
            with_payload=True,
            with_vectors=False,
        )
        return [
            Document(
                page_content=point.payload.get("page_content") or "",
                metadata=point.payload.get("metadata"),
            )
            for point in results[0]
            if point.payload
        ]

    def __query_slack_messages(
        self,
        question: str,
        start_time: Optional[datetime] = None,
        end_time: Optional[datetime] = None,
        channel_name: Optional[str] = None,
        limit: int = 5,
        score_threshold: Optional[float] = None,
    ):
        filter_conditions = []
        if start_time or end_time:
            filter_conditions.append(
                FieldCondition(
                    key="metadata.timestamp",
                    range=DatetimeRange(
                        gte=start_time if start_time else None,
                        lte=end_time if end_time else None,
                    ),
                )
            )
        if channel_name:
            filter_conditions.append(
                FieldCondition(
                    key="metadata.channel_name", match=MatchValue(value=channel_name)
                )
            )

        return VectorStoreService(self.COLLECTION_NAME).search_with_score(
            input=question,
            filter=Filter(must=filter_conditions),
            k=limit,
            score_threshold=score_threshold,
        )

    def __get_related_slack_messages(
        self,
        point_id: str,
        channel_id: str,
        timestamp: Optional[datetime],
        limit: int = 5,
    ):
        if timestamp is None:
            return []

        # Get messages before the current message
        scroll_up_result = self.qdrant_client.scroll(
            collection_name=self.COLLECTION_NAME.value,
            limit=limit,
            scroll_filter=Filter(
                must=[
                    FieldCondition(
                        key="metadata.channel_id", match=MatchValue(value=channel_id)
                    ),
                    FieldCondition(
                        key="metadata.timestamp", range=DatetimeRange(lte=timestamp)
                    ),
                ]
            ),
            order_by=OrderBy(key="metadata.timestamp", direction=Direction.DESC),
            with_payload=True,
            with_vectors=False,
        )

        # Get messages after the current message
        scroll_down_result = self.qdrant_client.scroll(
            collection_name=self.COLLECTION_NAME.value,
            limit=limit,
            scroll_filter=Filter(
                must=[
                    FieldCondition(
                        key="metadata.channel_id", match=MatchValue(value=channel_id)
                    ),
                    FieldCondition(
                        key="metadata.timestamp", range=DatetimeRange(gte=timestamp)
                    ),
                ]
            ),
            order_by=OrderBy(key="metadata.timestamp", direction=Direction.ASC),
            with_payload=True,
            with_vectors=False,
        )

        # Combine and deduplicate results
        seen = set()
        related_messages = []

        # Process messages before current message
        for point in scroll_up_result[0]:
            if str(point.id) != point_id and point.id not in seen and point.payload:
                related_messages.append(
                    Document(
                        page_content=point.payload.get("page_content") or "",
                        metadata=point.payload.get("metadata"),
                    )
                )
                seen.add(point.id)

        # Process messages after current message
        for point in scroll_down_result[0]:
            if point.id != point_id and point.id not in seen and point.payload:
                related_messages.append(
                    Document(
                        page_content=point.payload.get("page_content") or "",
                        metadata=point.payload.get("metadata"),
                    )
                )
                seen.add(point.id)

        # Sort by timestamp
        related_messages.sort(key=lambda x: x.metadata.get("timestamp"))

        return related_messages

    def __qdrant_client(self) -> QdrantClient:
        return QdrantClient(
            url=os.environ["QDRANT_URL"], api_key=os.environ["QDRANT_API_KEY"]
        )

    def __vector_store(self):
        embeddings = BedrockAIService().embeddings_v2()
        return QdrantVectorStore(
            client=self.qdrant_client,
            collection_name=self.COLLECTION_NAME.value,
            embedding=embeddings,
        )
