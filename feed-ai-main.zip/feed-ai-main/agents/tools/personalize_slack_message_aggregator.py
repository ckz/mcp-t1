import json
from datetime import datetime, timedelta, timezone
from typing import List

from langchain_core.prompts import PromptTemplate
from langchain_core.tools import BaseTool
from pydantic import BaseModel, Field

from agents.tools.slack_message_querier import SlackMessagesQuerier
from agents.utils.llm_function_calling import StructuredOutputInstructor
from db.database import get_async_session
from models.user import User, UserRepo
from services.bedrock_service import OpenrouterModel
from utils.logging_config import logger
from utils.run_async import run_async


class PersonalizeSlackMessageAggregatorInput(BaseModel):
    start_time: datetime = Field(
        default_factory=lambda: datetime.now(timezone.utc) - timedelta(days=7),
        description="The start time for the message aggregation",
    )
    end_time: datetime = Field(
        default_factory=lambda: datetime.now(timezone.utc),
        description="The end time for the message aggregation",
    )


class PersonalizeQuestions(BaseModel):
    description: str = Field(..., description="Description of the overall questions")
    questions: List[str] = Field(..., description="List of personalized questions")


class PersonalizeSlackMessageAggregator(BaseTool):
    name: str = "PersonalizeSlackMessageAggregator"
    description: str = "Analyzes Slack messages from the past week to generate personalized question suggestions for users based on their conversation patterns and interests. This tool helps identify topics that would be most relevant and engaging for each specific user."
    args_schema: type[BaseModel] = PersonalizeSlackMessageAggregatorInput

    user: User

    class Config:
        arbitrary_types_allowed = True

    def _run(self, start_time: datetime, end_time: datetime) -> PersonalizeQuestions:
        return run_async(self._arun(start_time, end_time))

    async def _arun(
        self, start_time: datetime, end_time: datetime
    ) -> PersonalizeQuestions:
        return await self.__analyze(start_time, end_time)

    async def __analyze(
        self, start_time: datetime, end_time: datetime
    ) -> PersonalizeQuestions:
        user_information = await self.user.user_info_for_llm()
        user_messages = await self.__get_user_messages(start_time, end_time)
        user_questions = self.__extract_questions_from_user_messages(user_messages)
        all_users_messages = await self.__get_all_user_messages(start_time, end_time)
        all_users_questions = self.__extract_questions_from_user_messages(
            all_users_messages
        )
        slack_messages = self.__get_slack_messages(start_time, end_time)
        # Analyze the questions and generate personalized suggestions
        prompt_template = """
        You are a personalization specialist for FeedAI, a smart assistant that helps users with their questions and tasks. Your goal is to suggest personalized questions the user could ask FeedAI based on their past interactions and interests.

        THE CAPABILITIES OF FEEDAI:
        <feedai>
        1. Data Analysis & Querying
        - Search through Hubspot tickets and notes
        - Query Slack messages and threads across channels
        - Access and analyze email documents
        - Review Gong call transcripts
        - Query MMP API Pulls and Dev Support reports
        2. Financial Information
        - Access client billing information
        - Review vendor/partner billing details
        - Track campaign spending data
        - Monitor client monthly goals
        - Analyze campaign performance metrics
        3. System Status & Monitoring
        - Check sync status for various data sources (Slack, Hubspot, MMP API, Gong, Email)
        - Track system updates and performance
        4. Search & Information Retrieval
        - Search through user and shared memories
        - Extract and validate Slack channel names
        - Search for client and partner information
        - Access historical conversations and context
        5. Data Visualization
        - Create and display Plotly charts
        - Visualize data with accompanying explanations
        </feedai>

        USER INFORMATION:
        <user_information>
        {user_information}
        </user_information>

        USER'S PAST QUESTIONS TO FEEDAI:
        <user_messages>
        {user_messages}
        </user_messages>

        ALL USERS' QUESTIONS TO FEEDAI:
        <all_users_messages>
        {all_users_messages}
        </all_users_messages>

        USER'S SLACK CONVERSATIONS:
        <slack_messages>
        {slack_messages}
        </slack_messages>

        ANALYSIS INSTRUCTIONS:
        1. Identify the user's recurring interests, technical domains, and specific knowledge areas
        2. Note their communication style and types of questions they typically ask FeedAI
        3. Recognize any challenges, problems, or information needs they've expressed
        4. Consider their professional context and potential upcoming needs

        DELIVERABLE:
        Generate 4-5 personalized question suggestions that the user could ask FeedAI that:
        - Build directly on topics they've previously shown interest in
        - Help them explore logical next steps in their work or professional development
        - Address potential knowledge gaps or areas where FeedAI could provide valuable insights
        - Have practical relevance to their daily work and professional context
        - Match their communication style while keeping a professional tone

        Each suggestion should be a specific question the user could directly ask FeedAI for help with.

        Response format: JSON with 'description' field summarizing your analysis and 'questions' array containing the suggested questions the user could ask FeedAI.
        """
        prompt = PromptTemplate(
            template=prompt_template,
            input_variables=["user_information", "user_messages", "slack_messages"],
        ).format(
            user_information=user_information,
            user_messages=user_questions,
            all_users_messages=all_users_questions,
            slack_messages=slack_messages,
        )
        logger.info("Personalize Slack Message Aggregator:")
        logger.info(prompt)
        return StructuredOutputInstructor(PersonalizeQuestions).invoke(
            model=OpenrouterModel.GEMINI_2_0, prompt=prompt
        )

    async def __get_user_messages(
        self, start_time: datetime, end_time: datetime
    ) -> list[dict]:
        async for session in get_async_session():
            questions = await UserRepo(session).get_users_questions(
                start_time, end_time, self.user.identifier
            )
            return [
                {
                    "thread_name": question["thread_name"],
                    "user_message": question["user_message"],
                }
                for question in questions
            ]
        return []

    async def __get_all_user_messages(
        self, start_time: datetime, end_time: datetime
    ) -> list[dict]:
        async for session in get_async_session():
            questions = await UserRepo(session).get_all_users_questions(
                start_time, end_time
            )
            return [
                {
                    "email": question["email"],
                    "thread_name": question["thread_name"],
                    "user_message": question["user_message"],
                }
                for question in questions
            ]
        return []

    def __get_slack_messages(self, start_time: datetime, end_time: datetime):
        name = self.user.get_real_name()
        if not name:
            return None

        return SlackMessagesQuerier().query(
            start_time=start_time, end_time=end_time, input=name, score_threshold=0.3
        )

    def __extract_questions_from_user_messages(
        self, messages: list
    ) -> PersonalizeQuestions:
        return StructuredOutputInstructor(PersonalizeQuestions).invoke(
            model=OpenrouterModel.GEMINI_2_0, prompt=json.dumps(messages)
        )
