from typing import Literal
from typing_extensions import TypedDict
from botocore.client import BaseClient as BotocoreBaseClient
from langgraph.checkpoint.postgres.aio import AsyncPostgresSaver
from langchain_core.language_models import BaseChatModel

from langgraph.graph import MessagesState, StateGraph, START, END
from langgraph.types import Command

from .utils.agent_wrapper import AgentWrapper
from .conversation_knowledge_base import create_conversation_knowledge_base_agent
from .billing_information import create_billing_information_agent
from .sync_status_agent import create_sync_status_agent

def create_feedmob_agent(llm: BaseChatModel, bedrock_client: BotocoreBaseClient, checkpointer: AsyncPostgresSaver) -> AgentWrapper:
    members = ["conversation_knowledge_base", "billing_information", "sync_status"]
# Our team supervisor is an LLM node. It just picks the next agent to process
# and decides when the work is completed
    options = members + ["FINISH"]

    system_prompt = (
        "You are a supervisor tasked with managing a conversation between the"
        f" following workers: {members}. Given the following user request,"
        " respond with the worker to act next. Each worker will perform a"
        " task and respond with their results and status. If a worker didn't"
        "get the result, pick the next one to execute. When finished,"
        " respond with FINISH."
    )


    class Router(TypedDict):
        """Worker to route to next. If no workers needed, route to FINISH."""

        next: Literal[*options]

    def supervisor_node(state: MessagesState) -> Command[Literal[*members, "__end__"]]:
        messages = [
            {"role": "system", "content": system_prompt},
        ] + state["messages"]
        response = llm.with_structured_output(Router).invoke(messages)
        goto = response["next"]
        if goto == "FINISH":
            goto = END

        return Command(goto=goto)

    conversation_knowledge_base = create_conversation_knowledge_base_agent(llm, bedrock_client, checkpointer).agent
    billing_information = create_billing_information_agent(llm, bedrock_client, checkpointer).agent
    sync_status = create_sync_status_agent(llm, checkpointer).agent

    builder = StateGraph(MessagesState)
    builder.add_edge(START, "supervisor_node")
    builder.add_node("supervisor_node", supervisor_node)
    builder.add_node("conversation_knowledge_base", conversation_knowledge_base)
    builder.add_node("billing_information", billing_information)
    builder.add_node("sync_status", sync_status)
    return AgentWrapper(builder.compile(checkpointer=checkpointer))
