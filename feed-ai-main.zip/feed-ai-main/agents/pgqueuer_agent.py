from datetime import datetime

from langchain_core.language_models import BaseChatModel
from langchain_core.tools import StructuredTool
from langgraph.checkpoint.base import BaseCheckpointSaver
from langgraph.prebuilt import create_react_agent

from agents.pgqueuer_queue_dash import create_pgqueuer_queue_dash
from agents.tools.enqueue_job import EnqueueJobTool
from agents.utils.agent_wrapper import AgentWrapper


def create_pgqueuer_agent(
    llm: BaseChatModel, checkpointer: BaseCheckpointSaver
) -> AgentWrapper:
    pgqueuer_queue_dash_tool = StructuredTool.from_function(
        func=create_pgqueuer_queue_dash().run,
        name="PgQueuerQueueDashTool",
        description="""Allows you to get detailed queue information from the pgqueuer database.
        Use this tool to get comprehensive information about:
        - Queue status and metrics
        - Scheduled jobs and their details
        - Historical statistics and trends
        - Performance analytics
        The tool will return detailed, formatted text output.""",
    )

    tools = [pgqueuer_queue_dash_tool, EnqueueJobTool()]
    agent = create_react_agent(
        llm,
        tools=tools,
        checkpointer=checkpointer,
        prompt=f"The current date is {datetime.now().strftime('%Y-%m-%d')}.",
    )
    return AgentWrapper(agent, is_streaming=True)
