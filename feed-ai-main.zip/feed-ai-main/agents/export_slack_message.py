from datetime import datetime
from typing import Any

from botocore.client import BaseClient as BotocoreBaseClient
from langchain_core.language_models import BaseChatModel
from langchain_core.prompts import ChatPromptTemplate
from langgraph.checkpoint.postgres.aio import AsyncPostgresSaver
from langgraph.prebuilt import create_react_agent

from .tools.export_slack_message import ExportSlackMessageTool
from .utils.agent_wrapper import AgentWrapper
from .utils.user_specific_mcp_tools import load_user_mcp_tools


def create_export_slack_messages_agent(
    llm: BaseChatModel,
    bedrock_client: BotocoreBaseClient,
    checkpointer: AsyncPostgresSaver,
) -> AgentWrapper:
    tools = []
    tools.append(ExportSlackMessageTool())
    tools.extend(load_user_mcp_tools())

    agent = create_react_agent(
        llm, tools=tools, checkpointer=checkpointer, prompt=__system_prompt()
    )
    return AgentWrapper(agent)


def __system_prompt() -> Any:
    current_date = datetime.now().strftime("%Y-%m-%d")
    prompt = ChatPromptTemplate.from_messages(
        [
            (
                "system",
                f"""
🤖 FeedMob Assistant to Export Slack Messages
Current Date: {current_date}

You are a specialized AI agent designed to export Slack messages.
""",
            ),
            ("placeholder", "{messages}"),
        ]
    )
    return prompt
