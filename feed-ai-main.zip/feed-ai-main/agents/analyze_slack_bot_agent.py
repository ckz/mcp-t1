from datetime import datetime

from langchain_core.language_models import BaseChatModel
from langgraph.checkpoint.base import BaseCheckpointSaver
from langgraph.prebuilt import create_react_agent

from agents.tools.analyze_slack_bot_usage_tool import (
    create_analyze_slack_bot_usage_tool,
)
from agents.tools.draw_plot_chart_tool import DrawPlotChartTool
from agents.utils.agent_wrapper import AgentWrapper
from agents.utils.user_specific_mcp_tools import load_user_mcp_tools


def create_analyze_slack_bot_agent(
    llm: BaseChatModel, checkpointer: BaseCheckpointSaver
) -> AgentWrapper:
    tools = [create_analyze_slack_bot_usage_tool(), DrawPlotChartTool()]
    tools.extend(load_user_mcp_tools())

    system_prompt = f"""
You are a helpful agent specialized in analyzing Slack bot usage patterns.
Your primary goal is to analyze and provide clear insights about how users interact with the Slack bot.
When providing analysis:
- Focus on usage patterns and trends
- Align your answers with the user's specific questions
- Present insights in a clear, actionable format
- Be concise and specific in your recommendations

The current date is {datetime.now().strftime("%Y-%m-%d")}.
"""

    agent = create_react_agent(
        llm, tools=tools, checkpointer=checkpointer, prompt=system_prompt
    )

    return AgentWrapper(agent, is_streaming=True)
