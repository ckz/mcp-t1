import datetime
import os
import uuid
from typing import Any, Optional

import boto3
from botocore.client import BaseClient as BotocoreBaseClient
from langchain_core.callbacks import BaseCallbackHandler
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.runnables import RunnableConfig
from langchain_core.tools import BaseTool, StructuredTool
from langgraph.prebuilt import create_react_agent
from langgraph.store.postgres import AsyncPostgresStore

from agents.tools import (
    AllClientMonthlyGoalQuerierTool,
    CampaignSpendsQuerierTool,
    ClientBillingQuerierTool,
    ClientPartnerSearchTool,
    EmailDocumentQuerierTool,
    GongTranscriptQuerierTool,
    MemoriesQuerierTool,
    PersonalizeSlackMessageAggregator,
    SlackChannelExtractorTool,
    SyncStatusQuerierTool,
    VendorBillingQuerierTool,
    create_hubspot_ticket_querier,
    create_mmp_api_pulls_querier,
    create_online_search_agent,
    create_slack_messages_querier,
)
from db.checkpointer import global_checkpointer
from db.memory_store import global_memory_store
from models.user import User
from services.bedrock_service import BedrockAIService, BedrockModel
from utils.feature_flag import FeatureFlag
from utils.logging_config import logger


class ScheduledTaskAgent:
    """A scheduled task agent that can be invoked llm to perform a task."""

    def __init__(
        self,
        user: User,
        thread_id: Optional[str],
        task_name: str,
        task_instructions: str,
    ):
        self.user = user
        self.thread_id = thread_id if thread_id else str(uuid.uuid4())
        self.task_name = task_name
        self.task_instructions = task_instructions
        self.bedrock_client = self.__bedrock_client()
        self.llm = BedrockAIService().llm_converse(
            model=BedrockModel.PRO_MODEL_ID.value
        )

    async def invoke(self) -> str:
        async with global_checkpointer.get() as cp, global_memory_store.get() as store:
            tools = self.get_tools(store)
            agent = create_react_agent(
                model=self.llm,
                tools=tools,
                checkpointer=cp,
                prompt=await self.__system_prompt(),
            )
            task_message = self.task_instructions
            logger.info(f"Task message: {task_message}")
            response = await agent.ainvoke(
                input={"messages": [{"role": "user", "content": task_message}]},
                config=RunnableConfig(
                    callbacks=[BaseCallbackHandler()],
                    configurable={"thread_id": self.thread_id},
                ),
            )
            return response["messages"][-1].content

    def get_tools(self, memory_store: AsyncPostgresStore) -> list[BaseTool]:
        memory_querier = MemoriesQuerierTool(
            user_id=str(self.user.id), memory_store=memory_store
        )
        hubspot_ticket_querier = create_hubspot_ticket_querier(self.bedrock_client)
        slack_channel_name_extractor = SlackChannelExtractorTool()
        slack_messages_querier = create_slack_messages_querier()
        email_document_querier = EmailDocumentQuerierTool()
        mmp_api_pulls_querier_tool = create_mmp_api_pulls_querier(self.bedrock_client)
        sync_status_querier = SyncStatusQuerierTool()
        client_billing_querier = ClientBillingQuerierTool()
        vendor_billing_querier = VendorBillingQuerierTool()
        all_client_monthly_goal_querier = AllClientMonthlyGoalQuerierTool()
        gong_transcript_querier = GongTranscriptQuerierTool()
        personalize_slack_message_aggregator = PersonalizeSlackMessageAggregator(
            user=self.user
        )
        tools = [
            memory_querier,
            hubspot_ticket_querier,
            slack_channel_name_extractor,
            slack_messages_querier,
            email_document_querier,
            mmp_api_pulls_querier_tool,
            sync_status_querier,
            client_billing_querier,
            vendor_billing_querier,
            all_client_monthly_goal_querier,
            gong_transcript_querier,
            personalize_slack_message_aggregator,
        ]
        feature_flag = FeatureFlag()
        if feature_flag.is_enabled("search_tool", self.user.identifier):
            search_tool = StructuredTool.from_function(
                func=create_online_search_agent().run,
                name="OnlineSearchTool",
                description="Use this tool ONLY when you need to search for current, factual information not available in your knowledge base. For time-sensitive queries like prices or current events, I will automatically include today's date ({today}). Useful for recent events, news, facts, or when specific up-to-date information is required. Do not use for general knowledge or historical facts you already know.".format(
                    today=datetime.datetime.now().strftime("%Y-%m-%d")
                ),
            )
            tools.append(search_tool)

        # Add campaign spends tool only in beta
        if feature_flag.is_enabled("campaign_spends_tool", self.user.identifier):
            client_partner_search_tool = ClientPartnerSearchTool(
                user_identifier=self.user.identifier
            )
            campaign_spends_querier = CampaignSpendsQuerierTool(
                user_identifier=self.user.identifier
            )
            tools.extend(
                [
                    client_partner_search_tool,
                    campaign_spends_querier,
                    # DrawImagePlotChartTool()
                ]
            )
        return tools

    async def __system_prompt(self) -> Any:
        user_info = await self.user.user_info_for_llm()
        user_timezone = await self.user.get_slack_tz_info()
        current_time = await self.user.user_local_time_now()

        prompt = ChatPromptTemplate.from_messages(
            [
                (
                    "system",
                    f"""
        🤖 Feed AI Assistant
        User Current Time: {current_time.isoformat()}
        {user_info}

        You are a specialized Slack chatbot designed to analyze and process multiple data sources including Hubspot Tickets, Slack Messages, FeedMob Biiling Information and Google Sheet `MMP API Pulls - Dev Support Emailed Reports` etc. When responding to queries:

        Time Handling Requirements:
        • Always interpret times mentioned by users in their local timezone ({user_timezone})
        • Convert all times to UTC when using tools that require datetime inputs
        • For relative time expressions (e.g., "yesterday", "this morning"), use the user's current time as reference
        • If time is not specified for a date, assume the beginning of that day in user's timezone
        • User's current time ({current_time.isoformat()}) should be used as reference for all relative time calculations

        When responding to queries:
        • Lead with a direct answer to the question
        • Follow with any necessary supporting details or context
        • End your response with a "*References:*" section
        • Each reference should use the exact link provided in tool results
        • Keep quotes concise and directly relevant

        Tool Usage Guidelines:
        • ALWAYS use MemoriesQuerier first to gather relevant context and historical information
        • When using SlackChannelExtractor, you must:
        1. Get the list of relevant channels
        2. For each channel in the list, use SlackMessagesQuerier to search for messages
        3. Combine and analyze results from all channels before responding
        • Filter out irrelevant information from tool results before formulating your response:
        1. Only include information that directly relates to the query
        2. Discard any off-topic or tangential content
        3. Focus on the most relevant and accurate data points

        Output Format:
        • Use Slack markdown formatting (e.g., *bold*, _italic_, `code`, ```codeblock```)
        • Format lists with • or - for better Slack readability
        • Use >quote for block quotes
        • Format lists with • or - for better Slack readability
        • Break sections with --- for visual clarity

        Response Structure Example:
        The team meeting is scheduled for this afternoon and will cover Q4 performance review.

        *References:*
        - _[1]_ <https://peso.slack.com/archives/CHANNEL/MESSAGE_ID|"Team meeting scheduled for 2pm">
        - _[2]_ <https://peso.slack.com/archives/CHANNEL/MESSAGE_ID|"John will present the Q4 results">

        Core Requirements:
        • Process only provided data from authorized sources
        • Maintain professional tone
        • Include relevant cross-references when multiple sources are related
        • Respond "No, I cannot help with that" if unable to assist
        • Always include reference links from `reference` in the response
        • Remove References section if none exist

        Created by FeedMob | Enhancing Cross-Platform Communication Efficiency
        """,
                ),
                ("placeholder", "{messages}"),
            ]
        )

        return prompt

    def __bedrock_client(self) -> BotocoreBaseClient:
        return boto3.client(
            service_name="bedrock-runtime",
            region_name=os.environ["AWS_REGION_NAME"],
        )
