from datetime import datetime
from typing import Any

from botocore.client import BaseClient as BotocoreBaseClient
from langchain_core.language_models import BaseChatModel
from langchain_core.prompts import ChatPromptTemplate
from langgraph.checkpoint.postgres.aio import AsyncPostgresSaver
from langgraph.prebuilt import create_react_agent

from agents.utils.user_specific_mcp_tools import load_user_mcp_tools

from .tools.slack_channel_extractor import SlackChannelExtractorTool
from .tools.slack_message_querier import create_slack_messages_querier
from .utils.agent_wrapper import AgentWrapper


def create_slack_messages_agent(
    llm: BaseChatModel,
    bedrock_client: BotocoreBaseClient,
    checkpointer: AsyncPostgresSaver,
) -> AgentWrapper:
    slack_channel_name_extractor = SlackChannelExtractorTool()
    slack_messages_querier = create_slack_messages_querier()
    tools = [slack_channel_name_extractor, slack_messages_querier]
    tools.extend(load_user_mcp_tools())

    agent = create_react_agent(
        llm,
        tools=tools,
        checkpointer=checkpointer,
        prompt=__system_prompt(),
        debug=False,
    )
    return AgentWrapper(agent)


def __system_prompt() -> Any:
    current_date = datetime.now().strftime("%Y-%m-%d")
    prompt = ChatPromptTemplate.from_messages(
        [
            (
                "system",
                f"""
🤖 FeedMob Slack Assistant
Current Date: {current_date}

You are a specialized AI agent designed to analyze Slack communications. When responding to queries:

Format Guidelines:
• First provide your answer clearly and concisely
• End your response with a "References:" section
• Each reference should include id, quote, and link
• Keep quotes concise and directly relevant
• Remove References section if none exist

Response Structure Example:
The team meeting is scheduled for this afternoon and will cover Q4 performance review.

### References:
- **[1]** ["Team meeting scheduled for 2pm"](https://peso.slack.com/archives/CHANNEL/MESSAGE_ID)
- **[2]** ["John will present the Q4 results"](https://peso.slack.com/archives/CHANNEL/MESSAGE_ID)

Core Requirements:
• Only process provided Slack messages
• Maintain professional tone
• Respond "No, I cannot help with that" if unable to assist
• Always include reference links from `reference` in the response

Created by FeedMob | Enhancing Slack Communication Efficiency
""",
            ),
            ("placeholder", "{messages}"),
        ]
    )
    return prompt
