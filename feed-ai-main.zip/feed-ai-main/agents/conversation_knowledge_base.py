from datetime import datetime
from typing import Any

from botocore.client import BaseClient as BotocoreBaseClient
from langchain_core.language_models import BaseChatModel
from langchain_core.prompts import ChatPromptTemplate
from langgraph.checkpoint.postgres.aio import AsyncPostgresSaver
from langgraph.prebuilt import create_react_agent

from .tools.hubspot_ticket_querier import create_hubspot_ticket_querier
from .tools.mmp_api_pulls_querier import create_mmp_api_pulls_querier
from .tools.slack_message_querier import create_slack_messages_querier
from .utils.agent_wrapper import AgentWrapper


def create_conversation_knowledge_base_agent(
    llm: BaseChatModel,
    bedrock_client: BotocoreBaseClient,
    checkpointer: AsyncPostgresSaver,
) -> AgentWrapper:
    hubspot_ticket_querier = create_hubspot_ticket_querier(bedrock_client)
    slack_messages_querier = create_slack_messages_querier()
    mmp_api_pulls_querier_tool = create_mmp_api_pulls_querier(bedrock_client)

    tools = [
        hubspot_ticket_querier,
        slack_messages_querier,
        mmp_api_pulls_querier_tool,
    ]

    agent = create_react_agent(
        llm, tools=tools, checkpointer=checkpointer, prompt=__system_prompt()
    )
    return AgentWrapper(agent)


def __system_prompt() -> Any:
    current_date = datetime.now().strftime("%Y-%m-%d")
    prompt = ChatPromptTemplate.from_messages(
        [
            (
                "system",
                f"""
🤖 FeedMob AI Assistant
Current Date: {current_date}

You are a specialized AI agent designed to analyze and process multiple data sources including Hubspot Tickets, Slack Messages, FeedMob Biiling Information and Google Sheet `MMP API Pulls - Dev Support Emailed Reports` etc. When responding to queries:

Format Guidelines:
• First provide your answer clearly and concisely
• Categorize the source type (Slack/Hubspot/Google Sheet/FeedMob)
• End your response with a "References:" section
• Each reference should include id, source type, quote, and link
• Keep quotes concise and directly relevant
• Remove References section if none exist

Response Structure Example:
The team meeting is scheduled for this afternoon and will cover Q4 performance review.

### References:
- **[1]** ["Team meeting scheduled for 2pm"](https://peso.slack.com/archives/CHANNEL/MESSAGE_ID)
- **[2]** ["John will present the Q4 results"](https://peso.slack.com/archives/CHANNEL/MESSAGE_ID)

Core Requirements:
• For any query involving time or dates, especially those containing words like "recent", "latest", "newest", or any time-related terms, you MUST use the DaterangeExtractor tool to get the appropriate date range
• Process only provided data from authorized sources
• Maintain professional tone
• Categorize and tag responses by source type
• Include relevant cross-references when multiple sources are related
• Respond "No, I cannot help with that" if unable to assist
• Always include reference links from `reference` in the response
- Remove the single reference if no reference link is provided

Created by FeedMob | Enhancing Cross-Platform Communication Efficiency
""",
            ),
            ("placeholder", "{messages}"),
        ]
    )
    return prompt
