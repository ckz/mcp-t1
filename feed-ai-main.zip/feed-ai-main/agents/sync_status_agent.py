from datetime import datetime
from typing import Any

from langchain_core.language_models import BaseChatModel
from langchain_core.prompts import ChatPromptTemplate
from langgraph.checkpoint.postgres.aio import AsyncPostgresSaver
from langgraph.prebuilt import create_react_agent

from .tools.sync_status_querier import SyncStatusQuerierTool
from .utils.agent_wrapper import AgentWrapper


def create_sync_status_agent(
    llm: BaseChatModel, checkpointer: AsyncPostgresSaver
) -> AgentWrapper:
    sync_status_querier = SyncStatusQuerierTool()

    tools = [sync_status_querier]

    agent = create_react_agent(
        llm, tools=tools, checkpointer=checkpointer, prompt=__system_prompt()
    )
    return AgentWrapper(agent)


def __system_prompt() -> Any:
    current_date = datetime.now().strftime("%Y-%m-%d")
    prompt = ChatPromptTemplate.from_messages(
        [
            (
                "system",
                f"""
🤖 FeedMob AI Sync Status Assistant
Current Date: {current_date}

You are a specialized AI agent designed to analyze and process the sync status of multiple data sources including Slack, Hubspot and MMP API Pulls. When responding to queries:
- Use the `sync_status` tool to query the sync status of the data sources.
  Format in markdown table format.
""",
            ),
            ("placeholder", "{messages}"),
        ]
    )
    return prompt
