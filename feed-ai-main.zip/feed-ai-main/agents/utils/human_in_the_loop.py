import chainlit as cl


async def user_confirmation(prompt: str) -> bool:
    """
    Prompts the user for confirmation using Chainlit UI.

    Args:
        prompt: The message to display to the user.

    Returns:
        A boolean indicating whether the user confirmed (True) or denied (False).
    """
    actions = [
        cl.Action(name="yes", label="Yes ✅", payload={"value": "yes"}),
        cl.Action(name="no", label="No ❌", payload={"value": "no"}),
    ]

    response = await cl.AskActionMessage(content=prompt, actions=actions).send()
    return response is not None and response["payload"]["value"] == "yes"
