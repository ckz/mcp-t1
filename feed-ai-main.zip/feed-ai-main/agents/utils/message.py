import chainlit as cl
from chainlit.element import ElementBased

async def send_tool_call_messaage(content: str, elements: list[ElementBased]):
    # FIXME: to check if in the ChainlitContext, if not need to figure a way to send the message
    await cl.Message(
        content=content,
        elements=elements,
        metadata={"is_tool_call": True}
    ).send()
