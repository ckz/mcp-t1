import chainlit as cl
from langchain.agents.agent import AgentExecutor
from langchain_core.messages import AIMessage, HumanMessage, ToolMessage
from langchain_core.runnables import RunnableConfig
from langgraph.graph.graph import CompiledGraph

from utils.error_handling import catch_exceptions
from utils.feature_flag import FeatureFlag

from .cost_calculator import calculate_cost


class BaseAgentWrapper:
    async def ainvoke(self, message: HumanMessage):
        pass


class SlackAgentWrapper(BaseAgentWrapper):
    def __init__(self, agent: CompiledGraph):
        from services.slack_assistant_service import (
            SlackAssistantBetaService,
            SlackAssistantService,
        )
        from utils.app_stage import AppStage, get_app_stage

        self.agent = agent
        self.slack_service = (
            SlackAssistantService()
            if AppStage.STABLE == get_app_stage()
            else SlackAssistantBetaService()
        )

    async def ainvoke(self, message: HumanMessage):
        input = {"messages": [message]}
        config = RunnableConfig(
            callbacks=[
                cl.AsyncLangchainCallbackHandler(),
            ],
            configurable={"thread_id": self.__get_current_chainlit_thread_id()},
            recursion_limit=100,
        )
        await self.__stream(input, config)

    async def __stream(self, input, config):
        slack_event = cl.user_session.get("slack_event") or {}
        slack_channel_id = slack_event.get("channel", "")
        slack_thread_ts = slack_event.get("thread_ts", None) or slack_event.get(
            "ts", ""
        )

        res = cl.Message(content="")
        async for msg, metadata in self.agent.astream(
            input,
            stream_mode="messages",
            config=config,
            debug=False,
        ):
            if isinstance(metadata, dict) and metadata.get("langgraph_node") == "tools":
                if len(res.content) > 0:
                    async with catch_exceptions():
                        await self.slack_service.post_message(
                            channel_id=slack_channel_id,
                            thread_id=slack_thread_ts,
                            text=res.content,
                            blocks=[
                                {
                                    "type": "section",
                                    "text": {
                                        "type": "mrkdwn",
                                        "text": f"> {res.content}",
                                    },
                                    "expand": True,
                                },
                                {"type": "divider"},
                            ],
                        )
                    prev_res = res
                    res = cl.Message(content="")
                    await prev_res.remove()

                if isinstance(msg, ToolMessage):
                    async with catch_exceptions():
                        await self.slack_service.set_thread_status(
                            channel_id=slack_channel_id,
                            thread_ts=slack_thread_ts,
                            status=f"Using tool `{msg.name}` and Thinking...",
                        )

            if (
                isinstance(msg, AIMessage)
                and (content := msg.content)
                and isinstance(content, str)
            ):
                await res.stream_token(content)
        await res.send()

    def __get_current_chainlit_thread_id(self) -> str:
        return cl.context.session.thread_id

    def __get_current_user_identifier(self) -> str:
        if cl.context.session.user:
            return cl.context.session.user.identifier
        return ""


class AgentWrapper(BaseAgentWrapper):
    def __init__(self, agent: CompiledGraph, is_streaming: bool = True):
        self.agent = agent
        self.is_streaming = is_streaming

    ## Solution 1
    async def ainvoke(self, message: HumanMessage):
        input = {"messages": [message]}
        config = RunnableConfig(
            callbacks=[cl.AsyncLangchainCallbackHandler()],
            configurable={"thread_id": self.__get_current_chainlit_thread_id()},
            recursion_limit=100,
        )
        if self.is_streaming:
            await self.__stream(input, config)
        else:
            await self.__invoke(input, config)

    async def __invoke(self, input, config):
        res = cl.Message(content="")
        response = await self.agent.ainvoke(input, config=config, debug=False)
        ai_response = response["messages"][-1]
        token_usage = ai_response.response_metadata["token_usage"]
        model = ai_response.response_metadata["model"]
        cost = calculate_cost(token_usage=token_usage, model=model)
        feature_flag = FeatureFlag()
        if cost and feature_flag.is_enabled(
            "cost_usage", self.__get_current_user_identifier()
        ):
            res.metadata = {"cost": cost.model_dump()}

        if final_answer := response.get("final_answer"):
            async with cl.Step(name="Generate Final Answer", type="tool") as step:
                step.input = input
                await res.stream_token(final_answer.content)
                step.output = final_answer.thinking
        else:
            await res.stream_token(ai_response.content)
        await res.send()

    async def __stream(self, input, config):
        res = cl.Message(content="")
        async for msg, metadata in self.agent.astream(
            input, stream_mode="messages", config=config, debug=False
        ):
            if (
                isinstance(metadata, dict)
                and metadata.get("langgraph_node") == "agent"
                and isinstance(msg, AIMessage)
                and (content := msg.content)
                and isinstance(content, str)
            ):
                await res.stream_token(content)
        await res.send()

    def __get_current_chainlit_thread_id(self) -> str:
        return cl.context.session.thread_id

    def __get_current_user_identifier(self) -> str:
        if cl.context.session.user:
            return cl.context.session.user.identifier
        return ""


class LangchainAgentWrapper(BaseAgentWrapper):
    def __init__(self, agent: AgentExecutor):
        self.agent = agent

    async def ainvoke(self, message: HumanMessage):
        res = cl.Message(content="")
        response = await self.agent.acall(
            message.content, callbacks=[cl.LangchainCallbackHandler()]
        )
        await res.stream_token(response["output"])
        await res.send()
