from typing import Optional
from litellm.cost_calculator import cost_per_token
from litellm.types.utils import Usage
from pydantic import BaseModel

from utils.logging_config import logger

class UsageCost(BaseModel):
    prompt_tokens: int
    completion_tokens: int
    total_tokens: int
    prompt_tokens_cost_usd_dollar: float
    completion_tokens_cost_usd_dollar: float
    total_cost_usd_dollar: float

def calculate_cost(token_usage: Optional[Usage], model: str) -> Optional[UsageCost]:
    if token_usage is None:
        return None

    prompt_tokens_cost_usd_dollar, completion_tokens_cost_usd_dollar = cost_per_token(
        model=model,
        prompt_tokens=token_usage.prompt_tokens,
        completion_tokens=token_usage.completion_tokens
    )
    cost = UsageCost(
        prompt_tokens=token_usage.prompt_tokens,
        completion_tokens=token_usage.completion_tokens,
        total_tokens=token_usage.total_tokens,
        prompt_tokens_cost_usd_dollar=prompt_tokens_cost_usd_dollar,
        completion_tokens_cost_usd_dollar=completion_tokens_cost_usd_dollar,
        total_cost_usd_dollar=prompt_tokens_cost_usd_dollar + completion_tokens_cost_usd_dollar
    )
    logger.info(f"Cost: {cost!r}")
    return cost
