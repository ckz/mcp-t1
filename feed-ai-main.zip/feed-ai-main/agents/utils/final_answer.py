from datetime import datetime, timezone

from langchain_core.prompts import PromptTemplate
from litellm import completion
from pydantic import BaseModel, Field

from utils.logging_config import logger


class FinalAnswer(BaseModel):
    content: str = Field(description="Final Answer")
    thinking: str = Field(description="Thinking")


FEED_AI_WEB_PROMPT_TEMPLATE = """
You are a helpful AI assistant tasked with providing a clear, concise final answer based on tool calling results.
Current Time: {current_time}

Messages Context:
{messages}

Instructions:
1. Carefully analyze the user's question and context.
2. Filter out any irrelevant information that doesn't address the user's specific question.
3. Synthesize the relevant information from the context to create a comprehensive answer.
4. Make sure your answer directly addresses the user's original question.
5. Present information in a clear, organized manner.
6. If the context provided conflicting information, acknowledge this and provide the most reliable answer based on available data.
7. If the context didn't fully answer the question, acknowledge the limitations.
8. Be helpful, accurate, and concise.

Format Guidelines:
• Lead with a direct, concise answer to the question
• Follow with any necessary supporting details or context
• End your response with a "References:" section
• Each reference should use the exact link provided in tool results
• Keep quotes brief and focused on the question

Response Structure Example:
The team meeting is scheduled for this afternoon and will cover Q4 performance review.

### References:
- **[1]** ["Team meeting scheduled for 2pm"](https://peso.slack.com/archives/CHANNEL/MESSAGE_ID)
- **[2]** ["John will present the Q4 results"](https://peso.slack.com/archives/CHANNEL/MESSAGE_ID)

Core Requirements:
• Process only provided data from authorized sources
• Maintain professional tone
• Include relevant cross-references when multiple sources are related
• Respond "No, I cannot help with that" if unable to assist
• Always include reference links from `reference` in the response
• Remove the single reference if no reference link is provided

Your response should be conversational and friendly. Format your answer as needed for readability.

Provide your final answer:
"""


def get_final_answer(messages, prompt_template) -> FinalAnswer:
    prompt = PromptTemplate(
        template=prompt_template,
        input_variables=["messages", "current_time"],
    ).format(messages=messages, current_time=datetime.now(timezone.utc).isoformat())
    logger.info(f"Prompt: {prompt}")

    resp = completion(
        model="bedrock/us.anthropic.claude-3-7-sonnet-20250219-v1:0",
        messages=[{"role": "user", "content": prompt}],
        thinking={"type": "enabled", "budget_tokens": 2048},
    )
    logger.info(f"Response: {resp}")

    message = resp.choices[0].message
    return FinalAnswer(content=message.content, thinking=message.reasoning_content)
