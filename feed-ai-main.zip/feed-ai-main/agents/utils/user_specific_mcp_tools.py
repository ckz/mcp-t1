from typing import Any

import chainlit as cl
from langchain_core.tools import StructuredTool, ToolException
from mcp.types import (
    CallToolResult,
    EmbeddedResource,
    ImageContent,
    TextContent,
)

NonTextContent = ImageContent | EmbeddedResource


def load_user_mcp_tools() -> list[StructuredTool]:
    """
    Load all user-specific MCP tools
    """
    mcp_tools = cl.user_session.get("mcp_tools", {}) or {}
    all_tools = [
        __convert_user_mcp_tool_to_langchain_tool(tool)
        for connection_tools in mcp_tools.values()
        for tool in connection_tools
    ]
    return all_tools


def __convert_call_tool_result(
    call_tool_result: CallToolResult,
) -> tuple[str | list[str], list[NonTextContent] | None]:
    text_contents: list[TextContent] = []
    non_text_contents = []
    for content in call_tool_result.content:
        if isinstance(content, TextContent):
            text_contents.append(content)
        else:
            non_text_contents.append(content)

    tool_content: str | list[str] = [content.text for content in text_contents]
    if len(text_contents) == 1:
        tool_content = tool_content[0]

    if call_tool_result.isError:
        raise ToolException(tool_content)

    return tool_content, non_text_contents or None


def __convert_user_mcp_tool_to_langchain_tool(tool: dict) -> StructuredTool:
    async def call_tool(
        **arguments: dict[str, Any],
    ) -> tuple[str | list[str], list[NonTextContent] | None]:
        tool_name = tool["name"]
        # Identify which mcp is used
        mcp_tools = cl.user_session.get("mcp_tools", {}) or {}
        mcp_name = None

        for connection_name, tools in mcp_tools.items():
            if any(tool.get("name") == tool_name for tool in tools):
                mcp_name = connection_name
                break

        tool_call_result = None
        if not mcp_name:
            tool_call_result = CallToolResult(
                isError=True,
                content=[
                    TextContent(
                        type="text",
                        text=f"Tool {tool_name} not found in any MCP connection",
                    )
                ],
            )
        else:
            mcp_session, _ = cl.context.session.mcp_sessions.get(mcp_name)  # type: ignore

            if not mcp_session:
                tool_call_result = CallToolResult(
                    isError=True,
                    content=[
                        TextContent(
                            type="text",
                            text=f"MCP {mcp_name} not found in any MCP connection",
                        )
                    ],
                )
            else:
                tool_call_result = await mcp_session.call_tool(
                    name=tool_name, arguments=arguments
                )

        return __convert_call_tool_result(tool_call_result)

    return StructuredTool(
        name=tool["name"],
        description=tool["description"] or "",
        args_schema=tool["input_schema"],
        coroutine=call_tool,
        response_format="content_and_artifact",
    )
