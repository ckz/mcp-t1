from typing import Generic, Type, TypeVar

import instructor
import litellm
from litellm import BaseModel, completion
from tenacity import retry, stop_after_attempt, wait_exponential

from services.bedrock_service import BedrockAIService, BedrockModel

litellm.drop_params = True
litellm.modify_params = True
litellm.telemetry = False

T = TypeVar("T", bound=BaseModel)


class StructuredOutputInstructor(Generic[T]):
    def __init__(self, response_model: Type[T]):
        self.client = instructor.from_litellm(completion)
        self.response_model = response_model

    @retry(
        stop=stop_after_attempt(3), wait=wait_exponential(multiplier=1, min=4, max=10)
    )
    def invoke(
        self,
        model: str,
        prompt: str,
    ) -> T:
        response = self.client.chat.completions.create(
            model=model,
            response_model=self.response_model,
            messages=[{"role": "user", "content": prompt}],
            fallbacks=BedrockAIService().fallback_model_mappings(model),
        )
        if isinstance(response, self.response_model):
            return response

        raise ValueError(f"Unexpected response type: {type(response)}")

    def invoke_plus(self, prompt: str) -> T:
        model_id = f"bedrock/{BedrockModel.PLUS_MODEL_ID.value}"
        return self.invoke(model_id, prompt)

    def invoke_pro(self, prompt: str) -> T:
        model_id = f"bedrock/{BedrockModel.PRO_MODEL_ID.value}"
        return self.invoke(model_id, prompt)
