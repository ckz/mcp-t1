from langgraph.prebuilt import create_react_agent

from agents.utils.user_specific_mcp_tools import load_user_mcp_tools

from .tools.hubspot_ticket_querier import create_hubspot_ticket_querier
from .utils.agent_wrapper import AgentWrapper


def create_hubspot_ticket_agent(llm, bedrock_client, checkpointer) -> AgentWrapper:
    hubspot_ticket_querier = create_hubspot_ticket_querier(bedrock_client)
    tools = [hubspot_ticket_querier]
    tools.extend(load_user_mcp_tools())

    agent = create_react_agent(llm, tools=tools, checkpointer=checkpointer)
    return AgentWrapper(agent)
