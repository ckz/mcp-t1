from datetime import datetime

from langchain_core.language_models import BaseChatModel
from langgraph.checkpoint.base import BaseCheckpointSaver
from langgraph.prebuilt import create_react_agent

from agents.tools.github_issues_querier import create_github_issues_querier
from agents.utils.agent_wrapper import AgentWrapper
from agents.utils.user_specific_mcp_tools import load_user_mcp_tools


def create_github_issues_agent(
    llm: BaseChatModel, checkpointer: BaseCheckpointSaver
) -> AgentWrapper:
    tools = [create_github_issues_querier()]
    tools.extend(load_user_mcp_tools())

    system_prompt = f"""You are a helpful assistant that answers questions about GitHub issues.
When providing answers, incorporate reference links using markdown format: [text](url)
Always use the 'reference' URL from the data to create the links.
Example format: '[Issue #123](https://github.com/org/repo/issues/123)'

Remember to:
- Use markdown link syntax: [text](url)
- Weave links naturally into your responses
- Use the reference URLs provided in the data
- Consider the semantic search score to filter out irrelevant information:

The current date is {datetime.now().strftime("%Y-%m-%d")}.
"""

    agent = create_react_agent(
        llm, tools=tools, checkpointer=checkpointer, prompt=system_prompt
    )

    return AgentWrapper(agent=agent, is_streaming=True)
