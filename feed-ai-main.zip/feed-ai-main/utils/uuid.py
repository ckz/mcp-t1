import uuid

def generate_uuid(text: str) -> uuid.UUID:
    return uuid.uuid5(uuid.NAMESPACE_DNS, text)

def generate_uuid_str(text: str) -> str:
    return str(generate_uuid(text))
