import uuid
from services.constants import SLACK_USER_PREFIX

def generate_thread_id(thread_ts: str) -> str:
    return str(uuid.uuid5(uuid.NAMESPACE_DNS, thread_ts))

def get_user_email(email_with_prefix: str) -> str:
    # remove SLACK_USER_PREFIX prefix from identifier
    if email_with_prefix.startswith(SLACK_USER_PREFIX):
        return email_with_prefix[len(SLACK_USER_PREFIX):]
    return email_with_prefix

def is_slack_user(email_with_prefix: str) -> bool:
    return email_with_prefix.startswith(SLACK_USER_PREFIX)
