import json
from pydantic import BaseModel
from typing import Type, TypeVar, Generic, Optional

T = TypeVar('T', dict, BaseModel)
S = TypeVar('S', bytes, str)  # For output type (bytes or JSON string)

class Serializer(Generic[T, S]):
    def serialize(self, data: T) -> S:
        raise NotImplementedError

    def deserialize(self, data: S, returned_type: Optional[Type[T]] = None) -> T:
        raise NotImplementedError

class Object2BytesSerializer(Serializer[BaseModel, bytes]):
    def serialize(self, data: BaseModel) -> bytes:
        return json.dumps(data.model_dump_json()).encode("utf-8")

    def deserialize(self, data: bytes, returned_type: Optional[Type[BaseModel]] = None) -> BaseModel:
        if returned_type is None:
            raise ValueError("returned_type is required for Object2BytesSerializer")
        decoded_dict = json.loads(data.decode("utf-8"))
        return returned_type.model_validate_json(decoded_dict)

class Dict2BytesSerializer(Serializer[dict, bytes]):
    def serialize(self, data: dict) -> bytes:
        return json.dumps(data).encode("utf-8")

    def deserialize(self, data: bytes, returned_type: Optional[Type[dict]] = None) -> dict:
        return json.loads(data.decode("utf-8"))
