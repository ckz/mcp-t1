import copy

from langchain.text_splitter import (
    MarkdownTextSplitter,
    RecursiveCharacterTextSplitter,
    TextSplitter,
)
from langchain_core.documents import Document
from langchain_core.prompts import PromptTemplate
from pydantic import BaseModel, Field

from agents.utils.llm_function_calling import StructuredOutputInstructor
from services.bedrock_service import BedrockModel
from utils.uuid import generate_uuid_str


def split_text_document(
    doc: Document, chunk_size: int = 4096, chunk_overlap: int = 256
) -> list[Document]:
    splitter = RecursiveCharacterTextSplitter(
        chunk_size=chunk_size,
        chunk_overlap=chunk_overlap,
        strip_whitespace=True,
        separators=["\n\n", "\n", r"(?<=[.?!])\s+"],
        keep_separator=False,
        is_separator_regex=True,
    )
    return split_document(
        splitter=splitter,
        doc=doc,
    )


def split_markdown_document(
    doc: Document, chunk_size: int = 4096, chunk_overlap: int = 256
) -> list[Document]:
    return split_document(
        splitter=MarkdownTextSplitter(
            chunk_size=chunk_size, chunk_overlap=chunk_overlap, strip_whitespace=True
        ),
        doc=doc,
    )


def split_document(splitter: TextSplitter, doc: Document) -> list[Document]:
    content = doc.page_content
    chunks = splitter.create_documents([content])
    doc.metadata["has_chunks"] = False
    if len(chunks) <= 1:
        return [doc]

    chunk_docs = []
    previous_chunk_id = doc.id
    for idx, chunk in enumerate(chunks):
        chunk.metadata = copy.deepcopy(doc.metadata)
        chunk.metadata["is_chunk"] = True
        chunk.metadata["chunk_index"] = idx
        chunk.metadata["parent_id"] = doc.id
        chunk.metadata["previous_chunk_id"] = previous_chunk_id
        chunk.id = generate_uuid_str(f"{doc.id}-{idx}")
        previous_chunk_id = chunk.id
        chunk_docs.append(chunk)

    doc.metadata["chunk_count"] = len(chunks)
    doc.metadata["is_chunk"] = False
    doc.metadata["has_chunks"] = True
    doc.page_content = __summarize_content(content)

    return [doc] + chunk_docs


class SummaryResult(BaseModel):
    summary: str = Field(..., description="The summarized text.")


def __summarize_content(content: str) -> str:
    if len(content) <= 0:
        return ""

    prompt_template = """
Please provide a concise summary of the following text (maximum 4096 tokens), focusing on:
1. Main topic or central idea
2. Key points and arguments
3. Important conclusions or findings
4. Relevant details or examples

Keep the summary clear and well-organized, ensuring it stays within the token limit.

Text: {content}
"""
    prompt = PromptTemplate(
        template=prompt_template, input_variables=["content"]
    ).format(content=content)
    result = StructuredOutputInstructor(SummaryResult).invoke(
        f"bedrock/{BedrockModel.NOVA_LITE_MODEL_ID.value}", prompt
    )
    return result.summary
