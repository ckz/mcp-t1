import json
from featuremanagement import FeatureManager, TargetingContext
from utils.app_stage import get_app_stage

class FeatureFlag:

    _instance = None  # Class variable to hold the single instance

    def __new__(cls, *args, **kwargs):
        if not cls._instance:
            cls._instance = super().__new__(cls)
        return cls._instance

    def __init__(self):
        if not hasattr(self, 'feature_manager'):
            with open("utils/feature_flags.json", "r", encoding="utf-8") as f:
                feature_flags = json.load(f)
            self.feature_manager =  FeatureManager(feature_flags)


    """
    FeatureFlag Example:
    ```json
    {
        "id": "example_feature",
        "enabled": true,
        "conditions": {
            "client_filters": [
            {
                "name": "Microsoft.Targeting",
                "parameters": {
                "Audience": {
                    "Users": [],
                    "Groups": [
                    {
                        "Name": "beta",
                        "RolloutPercentage": 100
                    }
                    ],
                    "DefaultRolloutPercentage": 0
                }
                }
            }
            ]
        }
    }
    ```
    """
    def is_enabled(self, feature_name: str, user_identifier: str) -> bool:
        return self.feature_manager.is_enabled(
            feature_name,
            TargetingContext(user_id=user_identifier, groups=[get_app_stage().value])
        )
