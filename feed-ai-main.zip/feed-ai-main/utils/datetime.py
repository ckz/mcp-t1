from datetime import datetime, timezone

def normalize_time(dt: datetime, tz: timezone = timezone.utc) -> datetime:
    """
    Convert a datetime object to a UTC datetime object.

    Args:
        dt (datetime): The datetime object to convert.
        tz (timezone): The timezone to convert the datetime object to.

    Returns:
        datetime: The converted datetime object.
    """
    if dt and dt.tzinfo:
        dt = dt.astimezone(tz).replace(tzinfo=None)
    return dt
