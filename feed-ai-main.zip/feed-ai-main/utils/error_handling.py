from contextlib import asynccontextmanager

import sentry_sdk as sentry

from utils.logging_config import logger


@asynccontextmanager
async def catch_exceptions():
    try:
        yield
    except Exception as e:
        logger.exception(f"An error occurred: {e}")
        sentry.capture_exception(e)
