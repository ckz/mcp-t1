import os
from enum import Enum

class AppStage(str, Enum):
    STABLE = "stable"
    BETA = "beta"

def get_app_stage() -> AppStage:
    app_stage = os.environ.get("APP_STAGE") or "stable"
    return AppStage(app_stage)

def enable_db_migration() -> bool:
    return os.environ.get("ENABLE_DB_MIGRATION") == "true"
