from croniter import croniter

def normalize_cron_expression(expression: str) -> str:
    """Expands a cron expression into its component parts as a space-separated string.

    Args:
        expression (str): A cron expression or shorthand to expand.

    Returns:
        str: Expanded cron fields as a space-separated string.

    Example:
        >>> expand_cron_expressions("@hourly")
        '0 * * * *'
    """
    return " ".join(croniter(expression).expressions)
