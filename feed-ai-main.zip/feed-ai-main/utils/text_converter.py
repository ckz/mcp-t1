import re
import markdown
from bs4 import BeautifulSoup

def markdown_to_text(markdown_content: str) -> str:
    # Convert markdown to HTML
    html = markdown.markdown(markdown_content)
    return html_to_text(html)

def html_to_text(html_content: str) -> str:
    """
    Convert HTML content to plain text.

    Args:
        html_content: HTML content to convert.

    Returns:
        Plain text extracted from HTML.
    """
    if not html_content:
        return ""

    soup = BeautifulSoup(html_content, "html.parser")
    text = soup.get_text()
    # Normalize whitespace
    text = re.sub(r'\s+', ' ', text)
    return text.strip()

def clean_unicode_escapes(text: str) -> str:
    """
    Remove unicode escape sequences from text.

    Args:
        text: Text to clean.

    Returns:
        Text with unicode escape sequences removed.
    """
    return text.encode('utf-8').decode('unicode-escape')
