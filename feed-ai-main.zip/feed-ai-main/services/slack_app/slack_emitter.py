from typing import Dict, List, Optional, Union

import httpx
from slack_bolt.async_app import AsyncApp

from langchain.text_splitter import CharacterTextSplitter

from chainlit.context import HTTPSession, context
from chainlit.data import get_data_layer
from chainlit.element import ElementDict
from chainlit.emitter import BaseChainlitEmitter
from chainlit.message import StepDict

class SlackEmitter(BaseChainlitEmitter):
    def __init__(
        self,
        session: HTTPSession,
        app: AsyncApp,
        channel_id: str,
        say,
        thread_ts: Optional[str] = None,
    ):
        super().__init__(session)
        self.app = app
        self.channel_id = channel_id
        self.say = say
        self.thread_ts = thread_ts

    async def send_element(self, element_dict: ElementDict):
        if element_dict.get("display") != "inline":
            return

        persisted_file = self.session.files.get(element_dict.get("chainlitKey") or "")
        file: Optional[Union[bytes, str]] = None

        if persisted_file:
            file = str(persisted_file["path"])
        elif file_url := element_dict.get("url"):
            async with httpx.AsyncClient() as client:
                response = await client.get(file_url)
                if response.status_code == 200:
                    file = response.content

        if not file:
            return

        await self.app.client.files_upload_v2(
            channel=self.channel_id,
            thread_ts=self.thread_ts,
            file=file,
            title=element_dict.get("name"),
        )

    async def send_step(self, step_dict: StepDict):
        step_type = step_dict.get("type")
        is_assistant_message = step_type == "assistant_message"
        is_empty_output = not step_dict.get("output")
        is_tool_call = step_dict.get("metadata", {}).get("is_tool_call")

        if is_empty_output or not is_assistant_message:
            return

        chunks = CharacterTextSplitter(
            separator="\n\n",
            chunk_size=2048, # The size limation of slack message is 3000 characters
            chunk_overlap=0
        ).split_text(step_dict["output"])
        chunks_len = len(chunks)
        for idx, chunk in enumerate(chunks):
            enable_actions_for_this_chunk = idx == (chunks_len - 1) and not is_tool_call
            await self.__send_slack_message(
                chunk=chunk, step_dict=step_dict, enable_actions_for_this_chunk=enable_actions_for_this_chunk
            )

    async def __send_slack_message(self, chunk: str, step_dict: StepDict, enable_actions_for_this_chunk: bool = False):
        blocks: List[Dict] = [
            {
                "type": "section",
                "text": {"type": "mrkdwn", "text": chunk},
                "expand": True,
            },
        ]
        if enable_actions_for_this_chunk:
            current_run = context.current_run
            scorable_id = current_run.id if current_run else step_dict.get("id")
            blocks.append({
                "type": "actions",
                "elements": [
                    {
                        "action_id": "memories",
                        "type": "button",
                        "text": {
                            "type": "plain_text",
                            "emoji": True,
                            "text": ":brain: Personal Memory",
                        },
                        "value": scorable_id,
                    },
                    {
                        "action_id": "shared_memories",
                        "type": "button",
                        "text": {
                            "type": "plain_text",
                            "emoji": True,
                            "text": ":brain: Shared Memory",
                        },
                        "value": scorable_id,
                    }
                ]
            })

        enable_feedback = get_data_layer()
        if enable_feedback and enable_actions_for_this_chunk:
            current_run = context.current_run
            scorable_id = current_run.id if current_run else step_dict.get("id")
            blocks.append(
                {
                    "type": "actions",
                    "elements": [
                        {
                            "action_id": "thumbdown",
                            "type": "button",
                            "text": {
                                "type": "plain_text",
                                "emoji": True,
                                "text": ":thumbsdown: Feedback",
                            },
                            "value": scorable_id,
                        },
                        {
                            "action_id": "thumbup",
                            "type": "button",
                            "text": {
                                "type": "plain_text",
                                "emoji": True,
                                "text": ":thumbsup: Feedback",
                            },
                            "value": scorable_id,
                        },
                    ],
                }
            )

        if enable_actions_for_this_chunk:
            metadata = step_dict.get("metadata", {})
            total_cost = metadata.get("cost", {}).get("total_cost_usd_dollar")
            total_tokens = metadata.get("cost", {}).get("total_tokens")
            if total_cost and total_tokens:
                blocks.append(
                    {
                        "type": "context",
                        "elements": [
                            {
                                "type": "mrkdwn",
                                "text": f":heavy_dollar_sign: *Cost:* ${float(total_cost):.5f} • {total_tokens} tokens"
                            }
                        ]
                    }
                )

        await self.say(
            text=chunk, blocks=blocks, thread_ts=self.thread_ts
        )

    async def update_step(self, step_dict: StepDict):
        is_assistant_message = step_dict["type"] == "assistant_message"

        if not is_assistant_message:
            return

        await self.send_step(step_dict)

