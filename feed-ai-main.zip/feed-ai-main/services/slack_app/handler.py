from slack_bolt.adapter.fastapi.async_handler import AsyncSlackRequestHandler
from services.slack_app.app import slack_app

slack_app_handler = AsyncSlackRequestHandler(slack_app)
