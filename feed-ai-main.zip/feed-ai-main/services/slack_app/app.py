import asyncio
import os
import random
import re
import uuid
from contextlib import asynccontextmanager
from functools import partial
from typing import Dict, List, Optional, Union

import httpx
import sentry_sdk as sentry
from chainlit.config import config
from chainlit.context import ChainlitContext, HTTPSession, context_var
from chainlit.data import get_data_layer
from chainlit.element import Element
from chainlit.message import Message
from chainlit.telemetry import trace
from chainlit.types import Feedback
from chainlit.user import PersistedUser, User
from chainlit.user_session import user_session
from slack_bolt.async_app import AsyncApp
from slack_sdk.errors import SlackApiError

from db.database import get_async_session
from db.memory_store import global_memory_store
from jobs import CreateScheduledTaskJobPayload, enqueue_job
from models.slack_channel import SlackChannelRepo
from services.constants import SLACK_USER_PREFIX
from services.memory_service import MemoryService
from services.slack_app.slack_emitter import SlackEmitter
from services.slack_assistant_service import SlackAssistantService
from services.suggested_prompts_service import SuggestedPromptsService
from utils.app_stage import AppStage, get_app_stage
from utils.logging_config import logger

slack_app = AsyncApp(
    token=os.environ.get("SLACK_BOT_TOKEN")
    if get_app_stage() == AppStage.STABLE
    else os.environ.get("BETA_SLACK_BOT_TOKEN"),
    signing_secret=os.environ.get("SLACK_SIGNING_SECRET")
    if get_app_stage() == AppStage.STABLE
    else os.environ.get("BETA_SLACK_SIGNING_SECRET"),
)
assistant_service = SlackAssistantService(slack_app)


@trace
def init_slack_context(
    session: HTTPSession,
    slack_channel_id: str,
    event,
    say,
    thread_ts: Optional[str] = None,
) -> ChainlitContext:
    emitter = SlackEmitter(
        session=session,
        app=slack_app,
        channel_id=slack_channel_id,
        say=say,
        thread_ts=thread_ts,
    )
    context = ChainlitContext(session=session, emitter=emitter)
    context_var.set(context)
    user_session.set("slack_event", event)
    user_session.set(
        "fetch_slack_message_history",
        partial(
            fetch_message_history, channel_id=slack_channel_id, thread_ts=thread_ts
        ),
    )
    return context


users_by_slack_id: Dict[str, Union[User, PersistedUser]] = {}


def clean_content(message: str):
    cleaned_text = re.sub(r"<@[\w]+>", "", message).strip()
    return cleaned_text


async def get_user(slack_user_id: str):
    if slack_user_id in users_by_slack_id:
        return users_by_slack_id[slack_user_id]

    slack_user = await slack_app.client.users_info(user=slack_user_id)
    slack_user_profile = slack_user["user"]["profile"]

    user_identifier = slack_user_profile.get("email") or slack_user_id
    user = User(
        identifier=SLACK_USER_PREFIX + user_identifier, metadata=slack_user_profile
    )

    users_by_slack_id[slack_user_id] = user

    if data_layer := get_data_layer():
        try:
            persisted_user = await data_layer.create_user(user)
            if persisted_user:
                users_by_slack_id[slack_user_id] = persisted_user
        except Exception as e:
            logger.error(f"Error creating user: {e}")
            sentry.capture_exception(e)

    return users_by_slack_id[slack_user_id]


async def get_channel_name(channel_id: str) -> Optional[str]:
    try:
        response = await slack_app.client.conversations_info(channel=channel_id)
        if response["ok"]:
            channel_info = response["channel"]
            return channel_info["name"]
        else:
            logger.error(f"Failed to fetch channel info: {response['error']}")
    except Exception as e:
        logger.error(f"Error fetching channel info: {e}")
    return None


async def fetch_message_history(
    channel_id: str, thread_ts: Optional[str] = None, limit=30
):
    if not thread_ts:
        result = await slack_app.client.conversations_history(
            channel=channel_id, limit=limit
        )
    else:
        result = await slack_app.client.conversations_replies(
            channel=channel_id, ts=thread_ts, limit=limit
        )
    if result["ok"]:
        messages = result["messages"]
        return messages
    else:
        raise Exception(f"Failed to fetch messages: {result['error']}")


async def download_slack_file(url, token):
    headers = {"Authorization": f"Bearer {token}"}
    async with httpx.AsyncClient(follow_redirects=True) as client:
        response = await client.get(url, headers=headers)
        if response.status_code == 200:
            return response.content
        else:
            return None


async def download_slack_files(session: HTTPSession, files, token):
    download_coros = [
        download_slack_file(file.get("url_private"), token) for file in files
    ]
    file_bytes_list = await asyncio.gather(*download_coros)
    file_refs = []
    for idx, file_bytes in enumerate(file_bytes_list):
        if file_bytes:
            name = files[idx].get("name")
            mime_type = files[idx].get("mimetype")
            file_ref = await session.persist_file(
                name=name, mime=mime_type, content=file_bytes
            )
            file_refs.append(file_ref)

    files_dicts = [
        session.files[file["id"]] for file in file_refs if file["id"] in session.files
    ]

    file_elements = [Element.from_dict(file_dict) for file_dict in files_dicts]

    return file_elements


async def process_slack_message(
    event,
    say,
    thread_id: str,
    thread_name: Optional[str] = None,
    bind_thread_to_user=False,
    thread_ts: Optional[str] = None,
    tags: Optional[List[str]] = None,
):
    logger.info(f"Processing Slack message(event): {event}")

    user = await get_user(event["user"])

    channel_id = event["channel"]

    text = event.get("text")
    slack_files = event.get("files", [])

    session_id = str(uuid.uuid4())
    session = HTTPSession(
        id=session_id,
        thread_id=thread_id,
        user=user,
        client_type="slack",
    )

    ctx = init_slack_context(
        session=session,
        slack_channel_id=channel_id,
        event=event,
        say=say,
        thread_ts=thread_ts,
    )

    file_elements = await download_slack_files(
        session, slack_files, slack_app.client.token
    )

    if on_chat_start := config.code.on_chat_start:
        await on_chat_start()

    msg = Message(
        content=clean_content(text),
        elements=file_elements,
        type="user_message",
        author=user.metadata.get("real_name"),
    )

    if on_message := config.code.on_message:
        await __handle_slack_message(
            event=event,
            channel_id=channel_id,
            message=msg,
            say=say,
            process_callback=on_message,
        )

    if on_chat_end := config.code.on_chat_end:
        await on_chat_end()

    if data_layer := get_data_layer():
        user_id = None
        if isinstance(user, PersistedUser):
            user_id = user.id if bind_thread_to_user else None

        thread_tags = [
            "FeedAI",
            get_app_stage(),
            thread_ts,
        ]
        if tags:
            thread_tags.extend(tags)

        try:
            await data_layer.update_thread(
                thread_id=thread_id,
                name=thread_name or msg.content,
                metadata=ctx.session.to_persistable(),
                user_id=user_id,
                tags=thread_tags,
            )
        except Exception as e:
            logger.error(f"Error updating thread: {e}")
            sentry.capture_exception(e)

    await ctx.session.delete()


async def __handle_slack_message(event, channel_id, message, say, process_callback):
    reaction_emoji = "wait"
    message_ts = event.get("ts")
    will_react = message_ts and event.get("type") in ["message", "app_mention"]
    if will_react:
        await __add_emoji_reaction(channel_id, message_ts, reaction_emoji)

    try:
        await process_callback(message)
    except Exception as e:
        logger.error(f"Error processing message: {e}")
        sentry.capture_exception(e)
        await __add_emoji_reaction(channel_id, message_ts, "x")
        say(
            ":x: An error occurred while processing your message. Please try again later."
        )

    if will_react:
        await __remove_emoji_reaction(channel_id, message_ts, reaction_emoji)


async def __add_emoji_reaction(channel_id, message_ts, reaction_emoji):
    try:
        await slack_app.client.reactions_add(
            channel=channel_id, name=reaction_emoji, timestamp=message_ts
        )
    except SlackApiError as e:
        logger.error(f"Error adding emoji reaction: {e}")


async def __remove_emoji_reaction(channel_id, message_ts, reaction_emoji):
    try:
        await slack_app.client.reactions_remove(
            channel=channel_id, name=reaction_emoji, timestamp=message_ts
        )
    except SlackApiError as e:
        logger.error(f"Error removing emoji reaction: {e}")


@slack_app.event("app_home_opened")
async def handle_app_home_opened(event, say):
    pass


@slack_app.event("assistant_thread_started")
async def handle_assistant_thread_started(event, say):
    try:
        await say("How can I help you?")

        assistant_thread = event.get("assistant_thread", {})
        slack_user_id = assistant_thread["user_id"]
        thread_ts = assistant_thread.get("thread_ts")
        channel_id = assistant_thread.get("channel_id")
        thread_context_channel_id = assistant_thread.get("context", {}).get(
            "channel_id"
        )
        prompts = await SuggestedPromptsService().get_slack_prompts(slack_user_id)

        if thread_context_channel_id:
            async for session in get_async_session():
                channel_model = await SlackChannelRepo(session).get_by_channel_id(
                    thread_context_channel_id
                )

                if channel_model is not None:
                    channel_name = channel_model.channel_name
                    summarize_channel = {
                        "title": f"Summarize channel {channel_name}",
                        "message": f"Please summarize the key discussions from the {channel_name} channel.",
                    }
                    prompts.append(summarize_channel)

        await assistant_service.set_thread_suggested_prompts(
            channel_id=channel_id,
            thread_ts=thread_ts,
            prompts=random.sample(prompts, 4),
            title="Try these prompts:",
        )
    except Exception as e:
        logger.exception(f"Failed to handle an assistant_thread_started event: {e}", e)
        await say(f":warning: Something went wrong! ({e})")


@slack_app.event("assistant_thread_context_changed")
async def handle_assistant_thread_context_changed(event, say):
    pass


@slack_app.event("app_mention")
async def handle_app_mentions(event, say):
    thread_ts = event.get("thread_ts", event["ts"])
    thread_id = str(uuid.uuid5(uuid.NAMESPACE_DNS, thread_ts))

    await process_slack_message(
        event, say, thread_id=thread_id, thread_ts=thread_ts, tags=["app_mention"]
    )


@slack_app.event("message")
async def handle_message(message, say):
    logger.info(f"Received message event: {message}")

    subtype = message.get("subtype")
    if subtype == "message_deleted":
        logger.info(f"Skipping message_deleted event: {message}")
        return
    if subtype == "message_changed":
        if "message" in message and "user" in message["message"]:
            user_id = message["message"]["user"]
            text = message["message"].get("text", "")
            thread_ts = message.get("message", {}).get("thread_ts")
            message["user"] = user_id
            message["text"] = (
                f'[EDIT] User modified their previous message to: "{text}"'
            )
            message["thread_ts"] = thread_ts
            await say(
                f"User <@{user_id}> edited their message to: {text}",
                channel=message["channel"],
                thread_ts=thread_ts,
            )
        else:
            logger.warning(f"Could not find user in message_changed event: {message}")
            return  # Skip processing if we can't identify the user

    thread_ts = message.get("thread_ts", message["ts"])
    thread_id = str(uuid.uuid5(uuid.NAMESPACE_DNS, thread_ts))
    channel_id = message["channel"]

    async with catch_exceptions():
        await assistant_service.set_thread_title(
            channel_id=channel_id, thread_ts=thread_ts, title=message["text"]
        )
        await assistant_service.set_thread_status(
            channel_id=channel_id,
            thread_ts=thread_ts,
            status="Thiking...",
        )

    await process_slack_message(
        event=message,
        say=say,
        thread_id=thread_id,
        bind_thread_to_user=True,
        thread_ts=thread_ts,
        tags=["message"],
    )


@slack_app.block_action("thumbdown")
async def thumb_down(ack, context, body):
    await ack()
    step_id = body["actions"][0]["value"]

    if data_layer := get_data_layer():
        feedback = Feedback(forId=step_id, value=0)
        await data_layer.upsert_feedback(feedback)

    text = body["message"]["text"]
    blocks = body["message"]["blocks"]
    updated_blocks = __update_action_blocks(
        blocks=blocks,
        action_ids=["thumbup", "thumbdown"],
        text=":thumbsdown: Feedback received.",
    )
    await context.client.chat_update(
        channel=body["channel"]["id"],
        ts=body["container"]["message_ts"],
        text=text,
        blocks=updated_blocks,
    )


@slack_app.block_action("thumbup")
async def thumb_up(ack, context, body):
    await ack()
    step_id = body["actions"][0]["value"]

    if data_layer := get_data_layer():
        feedback = Feedback(forId=step_id, value=1)
        await data_layer.upsert_feedback(feedback)

    text = body["message"]["text"]
    blocks = body["message"]["blocks"]
    updated_blocks = __update_action_blocks(
        blocks=blocks,
        action_ids=["thumbup", "thumbdown"],
        text=":thumbsup: Feedback received.",
    )
    await context.client.chat_update(
        channel=body["channel"]["id"],
        ts=body["container"]["message_ts"],
        text=text,
        blocks=updated_blocks,
    )


@slack_app.block_action("memories")
async def memorize(ack, context, body):
    await ack()

    step_id = body["actions"][0]["value"]
    user = await get_user(body["user"]["id"])
    logger.info(f"Memorizing step {step_id} for user {user.identifier} ({user.id})")
    async with global_memory_store.get() as store:
        async for session in get_async_session():
            await MemoryService(session, store).memorize(
                user_id=user.id, step_id=step_id
            )

    text = body["message"]["text"]
    blocks = body["message"]["blocks"]
    updated_blocks = __update_action_blocks(
        blocks=blocks,
        action_ids=["memories", "shared_memories"],
        text=":brain: Personal Memories updated.",
    )
    await context.client.chat_update(
        channel=body["channel"]["id"],
        ts=body["container"]["message_ts"],
        text=text,
        blocks=updated_blocks,
    )


@slack_app.block_action("shared_memories")
async def share_memory(ack, context, body):
    await ack()

    step_id = body["actions"][0]["value"]
    user = await get_user(body["user"]["id"])
    user_real_name = user.metadata.get("real_name")
    user_real_email = user.metadata.get("email")
    logger.info(f"Sharing memories from user {user.identifier} ({user.id})")
    async with global_memory_store.get() as store:
        async for session in get_async_session():
            await MemoryService(session, store).share_memory(
                shared_by_id=user.id,
                shared_by=f"{user_real_name} <{user_real_email}>",
                memory_id=step_id,
            )

    text = body["message"]["text"]
    blocks = body["message"]["blocks"]
    updated_blocks = __update_action_blocks(
        blocks=blocks,
        action_ids=["memories", "shared_memories"],
        text=":brain: Shared Memories updated.",
    )
    await context.client.chat_update(
        channel=body["channel"]["id"],
        ts=body["container"]["message_ts"],
        text=text,
        blocks=updated_blocks,
    )


@slack_app.shortcut("create_scheduled_task")
async def handle_create_task_shortcut(ack, shortcut, client):
    await ack()
    await client.views_open(
        trigger_id=shortcut["trigger_id"],
        view={
            "type": "modal",
            "callback_id": "scheduled_task_modal",
            "title": {"type": "plain_text", "text": "Create Recurring Task"},
            "submit": {"type": "plain_text", "text": "Create"},
            "blocks": [
                {
                    "type": "input",
                    "block_id": "task_instructions",
                    "element": {
                        "type": "plain_text_input",
                        "action_id": "instructions",
                        "multiline": True,
                        "placeholder": {
                            "type": "plain_text",
                            "text": "Enter task instructions",
                        },
                    },
                    "label": {"type": "plain_text", "text": "Instructions"},
                },
                {
                    "type": "input",
                    "block_id": "task_schedule",
                    "element": {
                        "type": "plain_text_input",
                        "action_id": "schedule",
                        "placeholder": {
                            "type": "plain_text",
                            "text": "e.g., every Monday at 10am",
                        },
                    },
                    "label": {"type": "plain_text", "text": "Schedule"},
                },
            ],
        },
    )


@slack_app.view("scheduled_task_modal")
async def handle_scheduled_task_submission(ack, body, client, view):
    await ack()
    instructions = view["state"]["values"]["task_instructions"]["instructions"]["value"]
    schedule = view["state"]["values"]["task_schedule"]["schedule"]["value"]
    user_id = body["user"]["id"]

    response = await client.chat_postMessage(
        channel=user_id,
        text=f":construction: Your recurring task will be created shortly.\n*Instructions*: {instructions}\n*Schedule*: {schedule}",
    )

    payload = CreateScheduledTaskJobPayload(
        slack_user_id=user_id,
        slack_thread_ts=response["ts"],
        task_instructions=instructions,
        task_schedule=schedule,
        app_stage=get_app_stage(),
    )
    logger.info(
        f"Creating recurring task for user {user_id} with instructions '{instructions}' and schedule '{schedule}'"
    )
    await enqueue_job("create_scheduled_task", payload)


def __update_action_blocks(blocks, action_ids: list[str], text: str):
    updated_blocks = []
    for block in blocks:
        if (
            block["type"] == "actions"
            and len(block["elements"]) >= 1
            and block["elements"][0]["action_id"] in action_ids
        ):
            updated_blocks.append(
                {
                    "type": "section",
                    "text": {"type": "mrkdwn", "text": text},
                }
            )
        else:
            updated_blocks.append(block)

    return updated_blocks


@asynccontextmanager
async def catch_exceptions():
    try:
        yield
    except Exception as e:
        logger.exception(f"An error occurred: {e}")
        sentry.capture_exception(e)
