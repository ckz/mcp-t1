import os
import re
from enum import Enum
from functools import lru_cache

import boto3
import litellm
from langchain_community.chat_models import ChatLiteLLM

from .litellm_emmbedings import LitellmEmbeddings

litellm.drop_params = True
litellm.modify_params = True
litellm.telemetry = False
# litellm._turn_on_debug()


class OpenrouterModel(str, Enum):
    GEMINI_2_0 = "openrouter/google/gemini-2.0-flash-001"
    DEEPSEEK_R1 = "openrouter/deepseek/deepseek-r1"
    CALUDE_3_7_SONNET_THINKING = "openrouter/anthropic/claude-3.7-sonnet:thinking"


class BedrockModel(str, Enum):
    EMBEDDING_MODEL_ID = "amazon.titan-embed-text-v1"
    EMBEDDING_MODEL_ID_V2 = "amazon.titan-embed-text-v2:0"
    PLUS_MODEL_ID = (
        "us.anthropic.claude-3-5-haiku-20241022-v1:0"  # cross-region inference enabled
    )
    PRO_MODEL_ID = (
        "us.anthropic.claude-3-7-sonnet-20250219-v1:0"  # cross-region inference enabled
    )
    REASONING_MODEL_ID = (
        "us.anthropic.claude-3-7-sonnet-20250219-v1:0"  # cross-region inference enabled
    )
    NOVA_LITE_MODEL_ID = "us.amazon.nova-lite-v1:0"  # cross-region inference enabled


class BedrockAIService:
    AWS_REGION_NAME = os.environ["AWS_REGION_NAME"]

    def embeddings(self):
        return LitellmEmbeddings(model_id=BedrockModel.EMBEDDING_MODEL_ID.value)

    def get_embedding(self, text: str):
        return self.embeddings().embed_query(text)

    def embeddings_v2(self):
        return LitellmEmbeddings(
            model_id=BedrockModel.EMBEDDING_MODEL_ID_V2.value, dimensions=1024
        )

    def get_embedding_v2(self, text: str):
        return self.embeddings_v2().embed_query(text)

    def llm_converse(self, model: str, temperature: int = 0, max_tokens: int = 4096):
        model_id = f"bedrock/converse/{model}"
        return ChatLiteLLM(
            model=model_id,
            temperature=temperature,
            max_tokens=max_tokens,
            model_kwargs={
                # "thinking": {"type": "enabled", "budget_tokens": 1024},
                "fallbacks": self.fallback_model_mappings(model_id),
            },
        )

    def fallback_model_mappings(self, model: str):
        mappings = {
            "bedrock/converse/us.anthropic.claude-3-7-sonnet-20250219-v1:0": [
                "openrouter/anthropic/claude-3.7-sonnet",
                "bedrock/converse/us.anthropic.claude-3-5-haiku-20241022-v1:0",
                "openrouter/anthropic/claude-3.5-haiku",
                "openrouter/google/gemini-2.0-flash-001",
            ],
            "bedrock/converse/us.anthropic.claude-3-5-haiku-20241022-v1:0": [
                "openrouter/anthropic/claude-3.5-haiku",
                "bedrock/converse/us.anthropic.claude-3-7-sonnet-20250219-v1:0",
                "openrouter/anthropic/claude-3.7-sonnet",
                "openrouter/google/gemini-2.0-flash-001",
            ],
            "bedrock/converse/us.amazon.nova-lite-v1:0": [
                "openrouter/amazon/nova-lite-v1",
                "openrouter/google/gemini-2.0-flash-001",
            ],
            "bedrock/us.anthropic.claude-3-7-sonnet-20250219-v1:0": [
                "openrouter/anthropic/claude-3.7-sonnet",
                "openrouter/google/gemini-2.0-flash-001",
            ],
            "bedrock/us.anthropic.claude-3-5-haiku-20241022-v1:0": [
                "openrouter/anthropic/claude-3.5-haiku",
                "openrouter/google/gemini-2.0-flash-001",
            ],
            "bedrock/us.amazon.nova-lite-v1:0": [
                "openrouter/amazon/nova-lite-v1",
                "openrouter/google/gemini-2.0-flash-001",
            ],
        }
        return mappings.get(model, [])


class BedrockRuntimeService:
    AWS_REGION_NAME = os.environ["AWS_REGION_NAME"]

    PATTERN = re.compile(r"v\d+(?!.*\d[kK]$)")
    EXCLUDE_MODELS = [
        "anthropic.claude-3-opus-20240229-v1:0",
        "cohere.command-text-v14",
        "cohere.command-light-text-v14",
        "cohere.command-r-v1:0",
        "cohere.command-r-plus-v1:0",
        "cohere.embed-english-v3",
        "cohere.embed-multilingual-v3",
        "ai21.j2-ultra-v1",
        "ai21.j2-mid-v1",
        "meta.llama2-13b-v1",
        "meta.llama2-70b-v1",
        "meta.llama2-13b-chat-v1",
        "meta.llama2-70b-chat-v1",
        "amazon.titan-image-generator-v2:0",
    ]
    INCLUDE_MODELS = [
        BedrockModel.PLUS_MODEL_ID,
        BedrockModel.PRO_MODEL_ID,
    ]

    def __init__(self):
        self.bedrock = boto3.client("bedrock", region_name=self.AWS_REGION_NAME)

    @lru_cache
    def list_models(self):
        response = self.bedrock.list_foundation_models(
            byInferenceType="ON_DEMAND",
        )

        # List only model IDs with on-demand throughput
        model_ids = [
            item["modelId"]
            for item in response["modelSummaries"]
            if self.PATTERN.search(item["modelId"])
            and item["modelId"] not in self.EXCLUDE_MODELS
        ]

        model_ids.extend(self.INCLUDE_MODELS)

        return model_ids
