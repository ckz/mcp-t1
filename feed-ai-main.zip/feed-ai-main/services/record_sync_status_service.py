from sqlalchemy.ext.asyncio import AsyncSession
from typing import Dict
from datetime import datetime, timezone

from utils.logging_config import logger
from models.sync_status import SourceType, SyncStatus, SyncStatusRepo

class RecordSyncStatusService:
    def __init__(self, db_session: AsyncSession):
        self.db_session = db_session

    async def record_sync_status(self, source: SourceType, payload: Dict):
        repo = SyncStatusRepo(self.db_session)
        sync_status = await repo.get_by_source(source)
        if sync_status:
            sync_status.last_updated_at = datetime.now(timezone.utc)
            sync_status.payload = payload
        else:
            sync_status = SyncStatus(
                source=source,
                last_updated_at=datetime.now(timezone.utc),
                payload=payload
            )
        await repo.upsert(sync_status)
        logger.info(f"Sync status recorded for source: {source}")
