import csv
import tempfile
from datafusion import SessionContext
from pyarrow import schema, field, timestamp
from pydantic import BaseModel
from qdrant_client import QdrantClient, models
from datetime import datetime
from db.qdrant import QdrantCollection

class SlackMessageOutputFile(BaseModel):
    start_time: datetime
    end_time: datetime
    workspace: str
    path: str

    def filename(self) -> str:
        start_time_str = self.start_time.strftime("%Y-%m-%d")
        end_time_str = self.end_time.strftime("%Y-%m-%d")
        return f"{self.workspace}__{start_time_str}_{end_time_str}.md"

    def mime(self) -> str:
        return "text/markdown"

class ExportSlackMessageService:
    def __init__(self, qdrant_client: QdrantClient):
        self.qdrant_client = qdrant_client

    def export(self, start_time: datetime, end_time: datetime) -> list[SlackMessageOutputFile]:
        """
        Export messages to markdown files.
        Returns:
            List of paths to the markdown files.
        """
        csv_file_path = ExportSlackMessageToCSV(
            qdrant_client=self.qdrant_client
        ).export(start_time, end_time)
        markdown_files = ExportSlackMessageToMarkdown(
            csv_file_path=csv_file_path
        ).export(start_time, end_time)
        return markdown_files

class ExportSlackMessageToCSV:
    DEFAULT_LIMIT_PER_QUERY = 100

    def __init__(self, qdrant_client: QdrantClient):
        self.qdrant_client = qdrant_client

    def export(self, start_time: datetime, end_time: datetime) -> str:
        offset = None  # Start with no offset
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False) as temp_file:
            writer = csv.writer(temp_file)
            writer.writerow(["ID", "Timestamp", "Workspace", "Channel", "Permalink", "Message Content"])
            # Fetch and save the data
            while True:
                #
                # Extract points and next offset
                points, next_offset = self.__get_slack_messages(start_time, end_time, offset)

                if not points:
                    break  # Exit loop if no more points

                # Save the points to the CSV file
                self.__save_to_csv(writer, points)

                # Update the offset for the next batch
                offset = next_offset

                # Stop if next_offset is not provided
                if not next_offset:
                    break
            return temp_file.name

    def __get_slack_messages(self, start_time: datetime, end_time: datetime, offset=None):
        """
        Function to get slack messages from Qdrant.
        """
        response = self.qdrant_client.scroll(
            collection_name=QdrantCollection.SLACK_API_MESSAGES_V2.value,
            scroll_filter=models.Filter(
                must=[
                    models.FieldCondition(
                        key="metadata.timestamp",
                        range=models.DatetimeRange(
                            gte=start_time,
                            lte=end_time
                        )
                    ),
                ]
            ),
            offset=offset,
            limit=self.DEFAULT_LIMIT_PER_QUERY,
            with_payload=True,
            with_vectors=False
        )
        return response

    def __save_to_csv(self, writer, points):
        """
        Function to save messages to a CSV file.
        """
        for point in points:
            metadata = point.payload.get("metadata", {})
            page_content = point.payload.get("page_content", "")
            writer.writerow([
                metadata.get("id", "Unknown"),
                metadata.get("timestamp", None),
                metadata.get("workspace", "Feedmob"),
                metadata.get("channel_name", "Unknown"),
                metadata.get("permalink", None),
                page_content
            ])

class ExportSlackMessageToMarkdown:
    def __init__(self, csv_file_path: str):
        self.csv_file_path = csv_file_path

    def export(self, start_time, end_time) -> list[SlackMessageOutputFile]:
        """
        Export messages to markdown files.
        Returns:
            List of paths to the markdown files.
        """
        def write_messages_to_file(file, messages_df):
            """Write messages to the given file."""
            for row in messages_df.collect():
                ids, timestamps, permalinks, messages = row
                for i in range(len(ids)):  # Assuming all arrays in row have the same length
                    markdown_content = (
                        f"**ID**: {ids[i]}\n"
                        f"**Timestamp**: {timestamps[i]}\n"
                        f"**Permlink**: {permalinks[i]}\n\n"
                        f"{messages[i]}\n\n"
                        "---\n\n"
                    )
                    file.write(markdown_content)

        def process_channel(workspace, channel, output_file):
            """Process a single channel and write its messages to the output file."""
            output_file.write(f"# {channel}\n\n")
            messages_df = self.__get_messages_by_workspace_and_channel(workspace, channel)
            write_messages_to_file(output_file, messages_df)

        def process_workspace(workspace) -> str:
            """
            Process a single workspace and write its channels' messages to a markdown file.
            Returns:
                The path of the markdown file.
            """
            channels = self.__get_channels_by_workspace(workspace)
            with tempfile.NamedTemporaryFile(mode='w', prefix=f"{workspace}__", suffix='.md', delete=False) as output_file:
                for channel in channels:
                    process_channel(workspace, channel, output_file)
                return output_file.name

        workspaces = self.__get_distinct_workspaces()
        output_files = [
            SlackMessageOutputFile(
                start_time=start_time,
                end_time=end_time,
                workspace=workspace,
                path=process_workspace(workspace)
            )
            for workspace in workspaces
        ]
        return output_files

    def __get_distinct_workspaces(self):
        """
        Fetch distinct workspaces from the CSV file.
        Returns:
            List of distinct workspaces.
        """
        ctx = self.__initialize_session_and_schema()
        query = 'SELECT DISTINCT "Workspace" FROM slack_messages'
        results = self.__execute_query(ctx, query)

        # Extract distinct workspaces from results
        workspaces = []
        for batch in results:
            for i in range(len(batch)):
                workspaces.append(batch.column(0)[i].as_py())
        return workspaces


    def __get_channels_by_workspace(self, workspace_name):
        """
        Fetch distinct channels for a specific workspace.
        Args:
            workspace_name (str): The workspace to filter on.
        Returns:
            List of distinct channels.
        """
        ctx = self.__initialize_session_and_schema()
        query = f"""
        SELECT DISTINCT "Channel"
        FROM slack_messages
        WHERE "Workspace" = '{workspace_name}'
        """
        results = self.__execute_query(ctx, query)
        # Extract distinct channels from results
        channels = []
        for batch in results:
            for i in range(len(batch)):
                channels.append(batch.column(0)[i].as_py())
        return channels


    def __get_messages_by_workspace_and_channel(self, workspace_name, channel_name):
        """
        Fetch messages for a specific workspace and channel, sorted by timestamp.
        Args:
            workspace_name (str): The workspace to filter on.
            channel_name (str): The channel to filter on.
        Returns:
            DataFrame: Filtered and sorted data.
        """
        ctx = self.__initialize_session_and_schema()
        query = f"""
        SELECT "ID", "Timestamp", "Permalink", "Message Content"
        FROM slack_messages
        WHERE "Workspace" = '{workspace_name}' AND "Channel" = '{channel_name}'
        ORDER BY "Timestamp"
        """
        return ctx.sql(query)

    def __initialize_session_and_schema(self):
        """
        Initialize DataFusion session and register CSV with a predefined schema.
        Returns:
            SessionContext: Configured DataFusion session.
        """
        ctx = SessionContext()
        csv_schema = schema([
            field("ID", "string"),
            field("Timestamp", timestamp("us")),  # Microsecond-precision timestamp
            field("Workspace", "string"),
            field("Channel", "string"),
            field("Permalink", "string"),
            field("Message Content", "string"),
        ])
        ctx.register_csv("slack_messages", self.csv_file_path, schema=csv_schema, has_header=True)
        return ctx

    def __execute_query(self, ctx, query):
        """
        Execute a SQL query using DataFusion and return results.
        Args:
            ctx (SessionContext): Configured DataFusion session.
            query (str): SQL query to execute.
        Returns:
            List of results.
        """
        df = ctx.sql(query)
        results = df.collect()
        return results
