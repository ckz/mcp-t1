from langchain_core.embeddings import Embeddings
from pydantic import BaseModel
from litellm import embedding
from typing import Optional


class LitellmEmbeddings(BaseModel, Embeddings):
    model_id: str
    """Id of the model to call, e.g., amazon.titan-embed-text-v1, this is
    equivalent to the modelId property in the list-foundation-models api"""

    dimensions: Optional[int] = None
    """Number of dimensions to return in the embedding."""

    def embed_documents(self, texts: list[str]) -> list[list[float]]:
        """Embed search docs.

        Args:
            texts: List of text to embed.

        Returns:
            List of embeddings.
        """
        results = []
        for text in texts:
            response = self.embed_query(text)
            results.append(response)
        return results

    def embed_query(self, text: str) -> list[float]:
        """Embed query text.

        Args:
            text: Text to embed.

        Returns:
            Embedding.
        """
        response = embedding(model=self.model_id, input=text, dimensions=self.dimensions)
        if (data := response.data) and len(data) > 0:
            return response.data[0]['embedding']
        return []


