import os
from slack_bolt.async_app import AsyncApp
from slack_sdk.errors import SlackApiError
from slack_sdk.web.async_slack_response import AsyncSlackResponse
from utils.logging_config import logger
from services.constants import SLACK_USER_PREFIX
from typing import Optional, List, Dict
from tenacity import retry, stop_after_attempt, wait_exponential

class SlackAssistantService:
    def __init__(self, slack_app: Optional[AsyncApp] = None):
        self.slack_app = AsyncApp(
            token=os.environ.get("SLACK_BOT_TOKEN"),
            signing_secret=os.environ.get("SLACK_SIGNING_SECRET"),
        ) if slack_app is None else slack_app

    async def get_user_info_by_email(self, email: str) -> Optional[Dict]:
        slack_user_id = await self.get_slack_user_id_by_email(email)
        if not slack_user_id:
            return None
        return await self.get_user_info(slack_user_id)

    async def get_user_info(self, user_id: str) -> Optional[Dict]:
        """
        Get the user information of a Slack user.
        """
        try:
            response = await self.slack_app.client.users_info(user=user_id)
            if response["ok"]:
                return response["user"]
        except SlackApiError as e:
            logger.error(f"Error getting user info: {e}")
        return None

    async def get_user_email(self, slack_user_id: str) -> Optional[str]:
        """
        Get the email address of a Slack user in our system.
        """
        slack_user_email = await self.get_slack_user_email(slack_user_id)
        if slack_user_email is None:
            return None
        return SLACK_USER_PREFIX + slack_user_email

    async def get_slack_user_email(self, user_id: str) -> Optional[str]:
        """
        Get the email address of a Slack user.
        """
        try:
            response = await self.slack_app.client.users_info(user=user_id)
            if response["ok"]:
                return response["user"]["profile"]["email"]
        except SlackApiError as e:
            logger.error(f"Error getting user email: {e}")
        return None

    async def get_slack_user_id_by_email(self, email: str) -> Optional[str]:
        """
        Get the user ID of a Slack user by email.
        """
        try:
            response = await self.slack_app.client.users_lookupByEmail(email=email)
            if response["ok"]:
                return response["user"]["id"]
        except SlackApiError as e:
            logger.error(f"Error getting user ID: {e}")
        return None

    async def set_thread_suggested_prompts(self, channel_id: str, thread_ts: str, title: Optional[str], prompts: List[Dict[str, str]] ):
        """Set the suggested prompts for an AI assistant thread.
        Example:
        ```json
        {
            "channel_id": "D2345SFDG",
            "thread_ts": "1724264405.531769",
            "title": "Welcome. What can I do for you?",
            "prompts": [
                    {
                        "title": "Generate ideas",
                        "message": "Pretend you are a marketing associate and you need new ideas for an enterprise productivity feature. Generate 10 ideas for a new feature launch.",
                    },
                    {
                        "title": "Explain what SLACK stands for",
                        "message": "What does SLACK stand for?",
                    },
                    {
                        "title": "Describe how AI works",
                        "message": "How does artificial intelligence work?",
                    },
            ]
        }
        ```
        """
        try:
            await self.slack_app.client.assistant_threads_setSuggestedPrompts(
                channel_id=channel_id,
                thread_ts=thread_ts,
                title=title,
                prompts=prompts
            )
            logger.info(f"Thread#{channel_id + thread_ts} suggested prompts set successfully!")
        except SlackApiError as e:
            logger.error(f"Error setting thread suggested prompts: {e.response['error']}")
            raise

    async def set_thread_status(self, channel_id: str, thread_ts: str, status: str):
        """Set the status for an AI assistant thread."""
        try:
            await self.slack_app.client.assistant_threads_setStatus(
                channel_id=channel_id,
                thread_ts=thread_ts,
                status=status
            )
            logger.info(f"Thread#{channel_id + thread_ts} status set successfully!")
        except SlackApiError as e:
            logger.error(f"Error setting thread status: {e.response['error']}")
            raise

    async def set_thread_title(self, channel_id: str, thread_ts: str, title: str):
        """Set the title for an AI assistant thread."""
        try:
            await self.slack_app.client.assistant_threads_setTitle(
                channel_id=channel_id,
                thread_ts=thread_ts,
                title=title
            )
            logger.info(f"Thread#{channel_id + thread_ts} title set successfully!")
        except SlackApiError as e:
            logger.error(f"Error setting thread title: {e.response['error']}")

    async def send_message_by_email(self, email: str, text: str, thread_id: Optional[str] = None):
        """Send a message to a user by email."""
        try:
            # Lookup user by email
            user_id = await self.get_slack_user_id_by_email(email=email)
            if not user_id:
                raise ValueError(f"User with email {email} not found")

            text_with_mention = f"<@{user_id}>\n\n{text}"

            # Send a message
            blocks = [
                {
                    "type": "divider"
                },
                {
                    "type": "section",
                    "text": {
                        "type": "mrkdwn",
                        "text": text_with_mention
                    },
                    "expand": True,
                },
                {
                    "type": "divider"
                }
            ]
            await self.post_message(channel_id=user_id, text=text_with_mention, blocks=blocks, thread_id=thread_id)
        except SlackApiError as e:
            logger.error(f"Error sending message: {e.response['error']}")
            raise

    @retry(stop=stop_after_attempt(3), wait=wait_exponential(multiplier=1, min=4, max=10))
    async def post_message(self, channel_id: str, thread_id: Optional[str] = None, text: Optional[str] = None, blocks = None) -> AsyncSlackResponse:
        return await self.slack_app.client.chat_postMessage(channel=channel_id, thread_ts=thread_id, text=text, blocks=blocks)

class SlackAssistantBetaService(SlackAssistantService):
    def __init__(self, slack_app: Optional[AsyncApp] = None):
        self.slack_app = AsyncApp(
            token=os.environ.get("BETA_SLACK_BOT_TOKEN"),
            signing_secret=os.environ.get("BETA_SLACK_SIGNING_SECRET"),
        ) if slack_app is None else slack_app
