import os
from typing import Optional
from pydantic import BaseModel
from slack_sdk import WebClient
from slack_sdk.errors import SlackApiError
from utils.logging_config import logger

class SlackOauthAccessInfo(BaseModel):
    app_id: str
    authed_user_id: str
    scope: str
    token_type: str
    access_token: str
    bot_user_id: str
    team_id: str
    team_name: str

class SlackAuthService:
    def __init__(self):
        self.slack_client = WebClient()

    def get_oauth_acess(self, code) -> Optional[SlackOauthAccessInfo]:
        if not code:
            logger.error("Slack OAuth code is not provided")
            return None

        client_id = os.getenv('SLACK_CLIENT_ID')
        client_secret = os.getenv('SLACK_CLIENT_SECRET')
        redirect_uri = os.getenv('SLACK_REDIRECT_URI')
        if not client_id or not client_secret or not redirect_uri:
            logger.error("Slack OAuth environment variables are not set")
            raise ValueError("Slack OAuth environment variables are not set")

        try:
            result = self.slack_client.oauth_v2_access(
                client_id=client_id,
                client_secret=client_secret,
                redirect_uri=redirect_uri,
                code=code
            )
        except SlackApiError as e:
            logger.error(f"Error fetching Slack OAuth access: {e.response['error']}")
            return None

        if not result['ok']:
            logger.error(f"Error fetching Slack OAuth access: {result['error']}")
            return None

        return SlackOauthAccessInfo(
            app_id=result['app_id'],
            authed_user_id=result['authed_user']['id'],
            scope=result['scope'],
            token_type=result['token_type'],
            access_token=result['access_token'],
            bot_user_id=result['bot_user_id'],
            team_id=result['team']['id'],
            team_name=result['team']['name']
        )
