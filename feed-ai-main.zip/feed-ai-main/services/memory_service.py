from langchain_core.messages import AnyMessage, AIMessage, HumanMessage
from langgraph.store.base import BaseStore
from langchain_core.prompts import PromptTemplate
from sqlalchemy.ext.asyncio import AsyncSession

from agents.tools.shared_memory import SharedMemory, upsert_memory as upsert_shared_memory
from agents.tools.user_memory import UserMemory, upsert_memory as upsert_user_memory
from agents.utils.llm_function_calling import StructuredOutputInstructor
from models.step import StepRepo, Step, StepType

class MemoryService:
    def __init__(self, db_session: AsyncSession, memory_store: BaseStore) -> None:
        self.db_session = db_session
        self.memory_store = memory_store

    async def memorize(self, user_id: str, step_id: str) -> None:
        messages = await self.__get_messages(step_id)
        prompt = self.__user_memory_system_prompt().format(memory_id=step_id, messages=messages)
        memory = StructuredOutputInstructor(UserMemory).invoke_pro(prompt)
        await upsert_user_memory(memory, user_id=user_id, store=self.memory_store)

    async def share_memory(self, shared_by_id: str, shared_by: str, memory_id: str) -> None:
        messages = await self.__get_messages(memory_id)
        prompt = self.__shared_memory_system_prompt().format(memory_id=memory_id, shared_by=shared_by, messages=messages)
        memory = StructuredOutputInstructor(SharedMemory).invoke_pro(prompt)
        await upsert_shared_memory(memory, user_id=shared_by_id, store=self.memory_store)

    async def __get_messages(self, step_id: str) -> list[AnyMessage]:
        steps = await self.__get_steps(step_id)
        messages = []
        for step in steps:
            if step.step_type == StepType.ASSISTANT_MESSAGE:
                messages.append(AIMessage(step.output))
            elif step.step_type == StepType.RUN and step.name == 'on_message':
                messages.append(HumanMessage(step.input))
        return messages

    async def __get_steps(self, step_id: str) -> list[Step]:
        repo = StepRepo(self.db_session)
        return await repo.get_steps_by_id(step_id)

    def __user_memory_system_prompt(self) -> PromptTemplate:
        return PromptTemplate(
            template=(
                "You are a memory processing assistant. Create a memory summary focusing primarily on the human's input."
                "\nMemory ID: {memory_id}"
                "\nFocus on:"
                "\n- Main topics and key points from the human's message"
                "\n- Specific questions or requests made by the human"
                "\n- Important context or requirements mentioned"
                "\n- Only include AI response details if they're essential for understanding the human's intent"
                "\nKeep the summary concise and optimized for future reference."
                "\n\nMessages: {messages}"
            ),
            input_variables=["memory_id", "messages"]
        )

    def __shared_memory_system_prompt(self) -> PromptTemplate:
        return PromptTemplate(
            template=(
                "You are a memory processing assistant handling shared company-wide memories. Create a memory summary focusing primarily on the human's input."
                "\nMemory ID: {memory_id}"
                "\nShared by: {shared_by}"
                "\nFocus on:"
                "\n- Main topics and key points from the human's message"
                "\n- Specific questions or requests made by the human"
                "\n- Important context or requirements mentioned"
                "\n- Only include AI response details if they're essential for understanding the human's intent"
                "\nKeep the summary concise and optimized for future reference."
                "\n\nMessages: {messages}"
            ),
            input_variables=["memory_id", "shared_by", "messages"]
        )

