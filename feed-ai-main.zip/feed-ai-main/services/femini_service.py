import os
from datetime import date
from typing import List, Dict, Optional, Union, Literal
from urllib.parse import urlencode
import requests
import re
from tenacity import retry, stop_after_attempt, wait_exponential, retry_if_exception_type
from utils.logging_config import logger
import sentry_sdk as sentry
from services.constants import SLACK_USER_PREFIX

class FeminiAPIError(Exception):
    """Custom exception for Femini API errors"""
    def __init__(self, message: str, status_code: Optional[int] = None, response: Optional[Dict] = None):
        super().__init__(message)
        self.status_code = status_code
        self.response = response

class FeminiService:
    """Service class for interacting with the Femini API"""

    def __init__(self, user_identifier: Optional[str] = None):
        """
        Initialize the Femini API service

        Args:
            user_identifier: User's email address. For Slack users, this should include the USER_PREFIX

        Raises:
            ValueError: If required environment variables are not set or if user information is invalid
        """
        self.base_url = os.environ.get('FEMINI_BASE_URL')
        self.api_key = os.environ.get('FEMINI_API_KEY')

        if not self.base_url:
            raise ValueError("FEMINI_BASE_URL environment variable is not set")
        if not self.api_key:
            raise ValueError("FEMINI_API_KEY environment variable is not set")

        self.session = requests.Session()
        self.session.headers.update({
            'Authorization': f'Bearer {self.api_key}',
            'Content-Type': 'application/json',
            'Accept': 'application/json',
        })
        if user_identifier:
            self.__add_user_identifier_to_header(user_identifier)

    def __add_user_identifier_to_header(self, user_identifier: str):
        # Validate email format (with or without prefix)
        email_regex = r"[^@]+@[^@]+\.[^@]+"
        if user_identifier.startswith(SLACK_USER_PREFIX):
            # Slack user
            self.platform = "slack"
            self.user_email = user_identifier[len(SLACK_USER_PREFIX):]
            if not re.match(email_regex, self.user_email):
                logger.error(f"Invalid email format after removing prefix: {self.user_email}")
                raise ValueError("Invalid email format in user identifier")
        else:
            # Web user
            self.platform = "web"
            self.user_email = user_identifier
            if not re.match(email_regex, self.user_email):
                logger.error(f"Invalid email format: {self.user_email}")
                raise ValueError("Invalid email format in user identifier")

        self.session.headers.update({
            'X-User-Email': self.user_email,
            'X-Platform': self.platform
        })

    @retry(
        retry=retry_if_exception_type((requests.exceptions.RequestException, FeminiAPIError)),
        wait=wait_exponential(multiplier=1, min=4, max=60),
        stop=stop_after_attempt(3),
        reraise=True
    )
    def _make_api_request(self, method: str, endpoint: str, **kwargs) -> Dict:
        """
        Make an API request with retry logic

        Args:
            method: HTTP method (e.g., 'get', 'post')
            endpoint: API endpoint path
            **kwargs: Additional arguments to pass to the request

        Returns:
            Dict: API response data

        Raises:
            FeminiAPIError: If the API request fails after all retries
        """
        try:
            url = f"{self.base_url}/{endpoint.lstrip('/')}"
            response = getattr(self.session, method.lower())(url, **kwargs)
            response.raise_for_status()
            return response.json()

        except requests.exceptions.HTTPError as e:
            status_code = e.response.status_code if e.response else None
            error_response = None

            try:
                error_response = e.response.json() if e.response else None
            except (ValueError, AttributeError):
                pass

            error_msg = f"Femini API request failed: {str(e)}"
            logger.error(f"{error_msg} (Status: {status_code}, Response: {error_response})")
            sentry.capture_exception(e)

            raise FeminiAPIError(
                error_msg,
                status_code=status_code,
                response=error_response
            )

        except requests.exceptions.RequestException as e:
            error_msg = f"Femini API request failed: {str(e)}"
            logger.error(f"{error_msg} (Status: None, Response: None)")
            sentry.capture_exception(e)

            raise FeminiAPIError(error_msg)

    def list_documents(
        self,
        page: Optional[int] = 1,
        limit: Optional[int] = 10,
        sort_by: Optional[str] = "date_desc",
        search: Optional[str] = None,
        date_gteq: Optional[Union[str, date]] = None,
        date_lteq: Optional[Union[str, date]] = None,
        doc_type: Optional[str] = None
    ) -> Dict:
        """
        Retrieve a paginated list of documents with optional filtering

        Args:
            page (Optional[int]): Page number for pagination (default: 1)
            limit (Optional[int]): Number of documents per page (default: 10)
            sort_by (Optional[str]): Sort order for documents (default: "date_desc")
            search (Optional[str]): Search term to filter documents
            date_gteq (Optional[Union[str, date]]): Start date filter (YYYY-MM-DD)
            date_lteq (Optional[Union[str, date]]): End date filter (YYYY-MM-DD)
            doc_type (Optional[str]): Filter by document type (e.g., "email")

        Returns:
            Dict: Dictionary containing:
                - documents: List of document objects
                - pagination: Pagination information including:
                    - prev_url: URL for the previous page
                    - next_url: URL for the next page
                    - count: Total number of documents
                    - page: Current page number
                    - next: Next page number if available

        Raises:
            FeminiAPIError: If the API request fails after all retries
        """
        # Convert date objects to strings if necessary
        if isinstance(date_gteq, date):
            date_gteq = date_gteq.isoformat()
        if isinstance(date_lteq, date):
            date_lteq = date_lteq.isoformat()

        # Build query parameters
        params = {
            'query[sort_by]': sort_by,
            'query[limit]': limit,
            'page': page
        }

        if search:
            params['query[search]'] = search
        if date_gteq:
            params['query[date_gteq]'] = date_gteq
        if date_lteq:
            params['query[date_lteq]'] = date_lteq
        if doc_type:
            params['query[doc_type]'] = doc_type

        return self._make_api_request('get', 'documents.json', params=params)

    def get_campaign_spends(
        self,
        level: Literal["client", "partner"],
        date_gteq: Optional[Union[str, date]] = None,
        date_lteq: Optional[Union[str, date]] = None,
        legacy_client_id_in: Optional[List[int]] = None,
        legacy_partner_id_in: Optional[List[int]] = None
    ) -> Dict:
        """
        Retrieve campaign spend data with optional filtering and aggregation

        Args:
            level (Literal["client", "partner"]): Aggregation level for the spend data
            date_gteq (Optional[Union[str, date]]): Start date filter (YYYY-MM-DD)
            date_lteq (Optional[Union[str, date]]): End date filter (YYYY-MM-DD)
            legacy_client_id_in (Optional[List[int]]): List of client IDs to filter
            legacy_partner_id_in (Optional[List[int]]): List of partner IDs to filter

        Returns:
            Dict: Dictionary containing:
                - data: Campaign spend data from the API
                - source_url: URL to view the data in the web interface

        Raises:
            FeminiAPIError: If the API request fails after all retries

        Example URL format:
            https://assistant.feedmob.ai/campaign_spends?query[date_gteq]=2025-02-06&query[date_lteq]=2025-02-12&query[legacy_client_id_in][]=169&query[legacy_partner_id_in][]=454
        """
        # Set default dates if not provided
        if not date_gteq:
            date_gteq = date.today().replace(day=1).isoformat()
        if not date_lteq:
            date_lteq = date.today().isoformat()

        # Convert date objects to strings if necessary
        if isinstance(date_gteq, date):
            date_gteq = date_gteq.isoformat()
        if isinstance(date_lteq, date):
            date_lteq = date_lteq.isoformat()

        params = {
            "level": level,
            "date_gteq": date_gteq,
            "date_lteq": date_lteq,
        }
        if legacy_client_id_in:
            params["legacy_client_id_in[]"] = legacy_client_id_in

        if legacy_partner_id_in:
            params["legacy_partner_id_in[]"] = legacy_partner_id_in

        result = {
            'data': self._make_api_request('get', 'campaign_spends.json', params=params),
            'source_url': self.__build_campaign_spends_url(date_gteq, date_lteq, legacy_client_id_in, legacy_partner_id_in)
        }
        return result

    def __build_campaign_spends_url(
        self,
        date_gteq: Optional[Union[str, date]] = None,
        date_lteq: Optional[Union[str, date]] = None,
        legacy_client_id_in: Optional[List[int]] = None,
        legacy_partner_id_in: Optional[List[int]] = None
    ) -> str:
        """
        Build the URL for campaign spends endpoint with Rails-style query parameters.

        Args:
            date_gteq (Optional[Union[str, date]]): Start date filter in YYYY-MM-DD format
            date_lteq (Optional[Union[str, date]]): End date filter in YYYY-MM-DD format
            legacy_client_id_in (Optional[List[int]]): List of client IDs to filter by
            legacy_partner_id_in (Optional[List[int]]): List of partner IDs to filter by

        Returns:
            str: Formatted URL with Rails-style query parameters, e.g.:
                https://assistant.feedmob.ai/campaign_spends?query[date_gteq]=2025-02-06&query[date_lteq]=2025-02-12&query[legacy_client_id_in][]=169&query[legacy_partner_id_in][]=454

        Note:
            All parameters are wrapped in the 'query' namespace:
            - Date parameters use format: query[key]=value
            - Array parameters use format: query[key][]=value1&query[key][]=value2
        """
        base_url = f"{self.base_url}/campaign_spends"
        params = {
            "query[date_gteq]": date_gteq,
            "query[date_lteq]": date_lteq,
        }
        if legacy_client_id_in:
            params["query[legacy_client_id_in][]"] = legacy_client_id_in

        if legacy_partner_id_in:
            params["query[legacy_partner_id_in][]"] = legacy_partner_id_in

        query_string = urlencode(params, doseq=True)
        return f"{base_url}?{query_string}"

    def search_clients(self, name_cont: str) -> Dict:
        """
        Search for clients by their name using partial matching

        Args:
            name_cont: Partial name to search for clients

        Returns:
            Dict: List of matching clients

        Raises:
            FeminiAPIError: If the API request fails after all retries
        """
        params = {
            'query': {
                'name_cont': name_cont
            }
        }

        return self._make_api_request('get', 'clients.json', json=params)

    def search_partners(self, name_cont: str) -> Dict:
        """
        Search for partners by their name using partial matching

        Args:
            name_cont: Partial name to search for partners

        Returns:
            Dict: List of matching partners

        Raises:
            FeminiAPIError: If the API request fails after all retries
        """
        params = {
            'query': {
                'name_cont': name_cont
            }
        }

        return self._make_api_request('get', 'partners.json', json=params)
