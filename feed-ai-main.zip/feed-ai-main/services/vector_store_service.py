from typing import List, Tuple

from langchain_core.documents import Document
from langchain_qdrant import QdrantVectorStore
from qdrant_client.http.models import Optional
from qdrant_client.models import FieldCondition, Filter, MatchAny, SearchParams
from tenacity import retry, stop_after_attempt, wait_exponential

from db.qdrant import VECTOR_SIZE_1536, QdrantCollection, create_qdrant_client
from services.bedrock_service import BedrockAIService
from utils.logging_config import logger

DEFAULT_SCORE_THRESHOLD = 0.05


class VectorStoreService:
    def __init__(self, collection_name: QdrantCollection):
        self.collection_name = collection_name
        self.qdrant_client = create_qdrant_client()
        self.vector_store = self.__vector_store()

    def search_with_score(
        self,
        input: str,
        filter: Optional[Filter] = None,
        k: int = 10,
        offset: int = 0,
        score_threshold: Optional[float] = DEFAULT_SCORE_THRESHOLD,
    ) -> List[Tuple[Document, float]]:
        return self.vector_store.similarity_search_with_score(
            query=input,
            k=k,
            offset=offset,
            filter=filter,
            score_threshold=score_threshold,
            search_params=SearchParams(
                exact=True,  # Turn on exact search https://qdrant.tech/documentation/beginner-tutorials/retrieval-quality/
            ),
        )

    @retry(
        stop=stop_after_attempt(3), wait=wait_exponential(multiplier=1, min=4, max=10)
    )
    async def add_to_vector_store(self, docs: list[Document]):
        try:
            self.delete_chunks_from_vector_store(docs)
            await self.vector_store.aadd_documents(docs)
            logger.info(
                f"Added {len(docs)} to the vector store#{self.collection_name}."
            )
        except Exception as e:
            logger.error(
                f"Error adding document to vector store#{self.collection_name}: {e}"
            )
            raise

    def delete_chunks_from_vector_store(self, docs: list[Document]):
        # Extract document IDs from the list of documents
        doc_ids = [d.id for d in docs if d.id is not None]

        # If there are no document IDs, exit early
        if not doc_ids:
            return

        # Construct a filter condition to match documents whose "metadata.parent_id"
        # field matches any of the document IDs
        filter_condition = Filter(
            must=[FieldCondition(key="metadata.parent_id", match=MatchAny(any=doc_ids))]
        )

        # Call the delete method on the vector store client using the filter condition.
        self.vector_store.client.delete(
            collection_name=self.vector_store.collection_name,
            points_selector=filter_condition,
        )

    def __vector_store(self):
        return QdrantVectorStore(
            client=self.qdrant_client,
            collection_name=self.collection_name.value,
            embedding=self.__get_embeddings(),
        )

    def __get_embeddings(self):
        if self.collection_name in VECTOR_SIZE_1536:
            embeddings = BedrockAIService().embeddings()
        else:
            embeddings = BedrockAIService().embeddings_v2()
        return embeddings
