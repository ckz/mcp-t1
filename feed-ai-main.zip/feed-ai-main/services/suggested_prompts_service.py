import random
from typing import Dict, List, Optional

from db.database import get_async_session
from models.suggested_prompt import SuggestedPromptRepo
from models.user import User, UserRepo
from services.slack_assistant_service import (
    SlackAssistantBetaService,
    SlackAssistantService,
)
from utils.app_stage import AppStage, get_app_stage
from utils.feature_flag import FeatureFlag


class SuggestedPromptsService:
    MAX_PROMPTS: int = 4
    DEFAULT_PROMPTS: List[Dict[str, str]] = [
        {
            "title": "Sync Status Overview",
            "message": "Show me the current sync status",
        },
        {
            "title": "High Priority Hubspot Tickets",
            "message": "Show me the high priority Hubspot tickets from the last 7 days",
        },
        {
            "title": "Yesterday's Slack Summary",
            "message": "Show me yesterday's key Slack messages",
        },
    ]

    async def get_slack_prompts(self, slack_user_id: str) -> List[Dict[str, str]]:
        prompts = self.__get_hard_coded_prompts()
        user = await self.__get_user_by_slack_user_id(slack_user_id)
        if user:
            user_prompts = await self.__get_suggested_prompts_for_the_user(user)
            prompts.extend(user_prompts)
        global_prompts = await self.__get_global_suggested_prompts()
        prompts.extend(global_prompts)

        if len(prompts) <= self.MAX_PROMPTS:
            prompts.extend(self.DEFAULT_PROMPTS)

        return self.__generate_unique_and_random_prompts(prompts)

    def __get_hard_coded_prompts(self) -> List[Dict[str, str]]:
        prompts = []
        feature_flag = FeatureFlag()
        if feature_flag.is_enabled("campaign_spends_tool", "all users"):
            spend_prompts = [
                {
                    "title": "Campaign Spends Overview",
                    "message": "Show me the campaign spends for the current month",
                },
                {
                    "title": "Uber Technologies and Jampp Campaign Spends",
                    "message": "Show me the 7-day spend trend for the Uber Technologies with Jampp campaign",
                },
            ]
            prompts.extend(spend_prompts)

        if feature_flag.is_enabled("personalize_slack_message_aggregator", "all users"):
            prompts.append(
                {
                    "title": "Personalize Questions Generator",
                    "message": "please generate the personalize questions for me from the last 7 days' messages",
                }
            )
        return prompts

    async def __get_global_suggested_prompts(self) -> List[Dict[str, str]]:
        questions = []
        async for session in get_async_session():
            prompt = await SuggestedPromptRepo(session).get_global_prompts()
            if prompt:
                questions.extend(prompt.prompts)

        return [{"title": question, "message": question} for question in questions]

    async def __get_suggested_prompts_for_the_user(
        self, user: User
    ) -> List[Dict[str, str]]:
        questions = []
        async for session in get_async_session():
            prompt = await SuggestedPromptRepo(session).get_prompts_for_user(user.id)
            if prompt:
                questions.extend(prompt.prompts)

        return [{"title": question, "message": question} for question in questions]

    async def __get_user_by_slack_user_id(self, slack_user_id: str) -> Optional[User]:
        slack_service = (
            SlackAssistantService()
            if AppStage.STABLE == get_app_stage()
            else SlackAssistantBetaService()
        )
        email = await slack_service.get_user_email(slack_user_id)
        if email is None:
            return None
        async for session in get_async_session():
            return await UserRepo(session).get_user_by_identifier(email)
        return None

    def __generate_unique_and_random_prompts(
        self, prompts: List[Dict[str, str]]
    ) -> List[Dict[str, str]]:
        unique_prompts = {}
        for prompt in prompts:
            unique_prompts[prompt["title"]] = prompt
        unique_prompts_list = list(unique_prompts.values())

        # Randomly select up to MAX_PROMPTS prompts
        if len(unique_prompts_list) <= self.MAX_PROMPTS:
            return unique_prompts_list
        else:
            return random.sample(unique_prompts_list, self.MAX_PROMPTS)
