import re
from uuid import UUID

from sqlalchemy.ext.asyncio.session import AsyncSession
from utils.logging_config import logger

from slack_sdk import WebClient
from slack_sdk.errors import SlackApiError
from functools import lru_cache
from typing import Dict
import sentry_sdk as sentry
from tenacity import retry, stop_after_attempt, wait_exponential, retry_if_exception_type

from models.slack_credential import SlackCredentialRepo

class SlackServiceError(Exception):
    """Base exception class for SlackService errors."""
    pass

class FetchSlackMessagesError(SlackServiceError):
    """Exception raised when fetching Slack messages fails."""
    pass

class FetchSlackThreadsError(SlackServiceError):
    """Exception raised when fetching Slack threads fails."""
    pass


class SlackService:
    EXCLUDE_CHANNELS = ['star-team', 'mighty-team', 'monitor_internal_api_v2']

    def __init__(self, access_token: str):
        self.slack_client = WebClient(token=access_token)

    @retry(
        retry=retry_if_exception_type(SlackApiError),
        wait=wait_exponential(multiplier=1, min=4, max=60),
        stop=stop_after_attempt(3),
        reraise=True
    )
    def _make_slack_call(self, method, **kwargs):
        """Generic method to make Slack API calls with retry logic"""
        if hasattr(self.slack_client, method):
            return getattr(self.slack_client, method)(**kwargs)
        raise AttributeError(f"WebClient has no method '{method}'")


    def get_slack_channels(self):
        result = self.slack_client.users_conversations(
            types="public_channel,private_channel",
            limit=300
        )
        channels = []
        for channel in result['channels']:
            if channel['name'] in self.EXCLUDE_CHANNELS:
                continue
            channels.append({
                'id': channel['id'],
                'name': channel['name']
            })
        return channels

    @lru_cache
    def get_user_name_by(self, slack_user_id):
        if not slack_user_id:
            return None

        try:
            # Fetch the user real name using Slack client and cache it
            response = self._make_slack_call('users_info', user=slack_user_id)
            user = response['user']
            if user.get('real_name'):
                return user['real_name']
            else:
                return user['name']
        except SlackApiError as e:
            sentry.capture_exception(e)
            logger.error(f"Error fetching user info: {e.response['error']}")
            return None

    def get_slack_channel_messages(self, channel_id, oldest, latest):
        has_more = True
        next_cursor = None

        while has_more:
            response = self._make_slack_call('conversations_history',
                channel=channel_id,
                oldest=oldest,
                latest=latest,
                cursor=next_cursor
            )
            if response['ok']:
                yield from response['messages']
                has_more = response['has_more'] if response.get('has_more') else False
                next_cursor = response['response_metadata'].get('next_cursor') if response.get('response_metadata') else None
            else:
                logger.error(f"Error fetching messages: {response['error']}")
                raise FetchSlackMessagesError(f"Error fetching messages: {response['error']}")

    def get_thread_messages(self, channel_id, message_ts):
        has_more = True
        next_cursor = None

        while has_more:
            response = self._make_slack_call('conversations_replies',
                channel=channel_id,
                ts=message_ts,
                cursor=next_cursor
            )
            if response['ok']:
                # Skip the first message as it's the parent message we already have
                yield from response['messages'][1:]

                has_more = response['has_more'] if response.get('has_more') else False
                next_cursor = response['response_metadata'].get('next_cursor') if response.get('response_metadata') else None
            else:
                logger.error(f"Error fetching thread messages: {response['error']}")
                raise FetchSlackThreadsError(f"Error fetching thread messages: {response['error']}")

    def has_thread(self, message: Dict) -> bool:
        """
        Check if message has threads using message object properties
        - thread_ts: exists in both parent and reply messages
        - reply_count: exists only in parent messages with replies
        """
        return bool(message.get('thread_ts')) or message.get('reply_count', 0) > 0

    def get_permalink(self, channel_id, message_ts):
        try:
            response = self._make_slack_call('chat_getPermalink',
                channel=channel_id,
                message_ts=message_ts
            )
            return response['permalink']
        except SlackApiError as e:
            sentry.capture_exception(e)
            logger.error(f"Error fetching permalink: {e.response['error']}")
            return None

    def format_text_message(self, message_text):
        """
        Format the message text by replacing user IDs with their names
        """
        user_id_pattern = re.compile(r"<@([A-Z0-9]+)>")
        formatted_message = message_text

        for match in user_id_pattern.findall(message_text):
            user_name = self.get_user_name_by(match)
            if user_name:
                formatted_message = formatted_message.replace(f"<@{match}>", f"@{user_name}")

        return formatted_message

async def get_slack_services(db_session: AsyncSession) -> list[tuple[UUID, str, SlackService]]:
    """
    Create Slack services for all workspaces
    - Fetch all Slack credentials from the database
    - Create a Slack service for each workspace using the access token

    Returns:
    list[tuple[UUID, str, SlackService]]: List of Slack services with slack_credential_id and workspace name
    Example:
        [("xxxx-xxxx-1", 'workspace1', SlackService), ("xxxx-xxxx-2", 'workspace2', SlackService)]
    """
    slack_credentials = await SlackCredentialRepo(db_session).get_all()
    slack_services = []
    for slack_credential in slack_credentials:
        slack_service = SlackService(str(slack_credential.access_token))
        workspace = str(slack_credential.team_name)
        slack_services.append((slack_credential.id, workspace, slack_service))
    return slack_services
