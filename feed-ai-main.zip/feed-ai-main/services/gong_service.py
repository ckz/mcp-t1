import base64
import requests
from datetime import datetime, timedelta
from typing import Optional, Dict, List, Any
import logging
import time

class GongApiService:
    """
    Service class for handling Gong API interactions
    """
    
    def __init__(self, 
             access_key: Optional[str] = None, 
             access_key_secret: Optional[str] = None, 
             base_url: str = "https://api.gong.io/v2"):
        """
        Initialize the Gong API Service
        
        Args:
            access_key (str, optional): Gong API access key. If not provided, will use GONG_ACCESS_KEY from environment
            access_key_secret (str, optional): Gong API access key secret. If not provided, will use GONG_ACCESS_KEY_SECRET from environment
            base_url (str): Base URL for Gong API
        """
        import os
        
        self.access_key = access_key or os.getenv("GONG_ACCESS_KEY")
        self.access_key_secret = access_key_secret or os.getenv("GONG_ACCESS_KEY_SECRET")
        
        if not self.access_key or not self.access_key_secret:
            raise GongApiException("Missing credentials: Both access key and access key secret are required. "
                                "Provide them either as parameters or set GONG_ACCESS_KEY and GONG_ACCESS_KEY_SECRET "
                                "environment variables.")
        
        self.base_url = base_url
        self.headers = self._create_headers(self.access_key, self.access_key_secret)
        self.logger = logging.getLogger(__name__)


    def _create_headers(self, access_key: str, access_key_secret: str) -> Dict[str, str]:
        """
        Create authentication headers for API requests
        """
        credentials = f"{access_key}:{access_key_secret}"
        encoded_credentials = base64.b64encode(credentials.encode()).decode()
        return {
            "Authorization": f"Basic {encoded_credentials}",
            "Content-Type": "application/json"
        }

    def _make_request(self, 
                     endpoint: str, 
                     method: str = "GET", 
                     params: Optional[Dict] = None, 
                     data: Optional[Dict] = None) -> Optional[Dict]:
        """
        Make an API request with error handling and logging
        """
        url = f"{self.base_url}{endpoint}"
        
        try:
            self.logger.info(f"Making {method} request to {endpoint}")
            response = requests.request(
                method=method,
                url=url,
                headers=self.headers,
                params=params,
                json=data
            )
            
            if response.status_code == 404:
                self.logger.info(f"No data found for request to {endpoint}")
                return None
                
            response.raise_for_status()
            return response.json()
            
        except requests.exceptions.RequestException as e:
            self.logger.error(f"API request failed: {str(e)}")
            if response.status_code == 429:  # Rate limit exceeded
                retry_after = int(response.headers.get('Retry-After', 60))
                self.logger.warning(f"Rate limit exceeded. Retry after {retry_after} seconds")
            raise GongApiException(f"API request failed: {str(e)}")

    def get_calls(self,
             from_date: Optional[datetime] = None, 
             to_date: Optional[datetime] = None,
             fetch_all: bool = True) -> List[Dict]:
            """
            Get calls within a specified date range using cursor-based pagination
            
            Args:
                from_date (datetime): Start date for calls query
                to_date (datetime): End date for calls query  
                limit (int): Number of records per page (max 100)
                fetch_all (bool): Whether to recursively fetch all results
                    
            Returns:
                List[Dict]: List of calls
            """
            if not from_date:
                from_date = datetime.now() - timedelta(days=7)
            if not to_date:
                to_date = datetime.now()

            all_calls = []
            cursor = None
            total_records = None

            while True:
                params = {
                    "fromDateTime": from_date.strftime("%Y-%m-%dT%H:%M:%SZ"),
                    "toDateTime": to_date.strftime("%Y-%m-%dT%H:%M:%SZ"),
                }

                # Add cursor parameter if we have one
                if cursor:
                    params["cursor"] = cursor

                response = self._make_request("/calls", params=params)
                
                # Handle case when no calls are found
                if response is None:
                    self.logger.info("No calls found for the specified date range")
                    return []
                    
                if not isinstance(response, dict):
                    self.logger.error(f"Unexpected response format: {response}")
                    return []
                    
                records_info = response.get("records", {})
                total_records = records_info.get("totalRecords", 0) if total_records is None else total_records
                current_page_size = records_info.get("currentPageSize", 0)
                
                # Get the cursor for the next page
                cursor = records_info.get("cursor")
                
                calls = response.get("calls", [])
                all_calls.extend(calls)

                self.logger.info(f"Retrieved {current_page_size} calls out of {total_records} total")

                # Break conditions
                if not fetch_all:  # If fetch_all is False, return after first page
                    break
                if not calls:  # No more records to fetch
                    break
                if len(all_calls) >= total_records:  # Retrieved all records
                    break
                if not cursor:  # No cursor for next page
                    break

            self.logger.info(f"Total calls retrieved: {len(all_calls)} out of {total_records}")
            return all_calls



    def get_call_transcript(self, call_id: str, format_output: bool = True, min_chars: int = 0, simple_output: bool = False) -> Dict:
        """
        Get transcript and metadata for a specific call with speaker names

        Args:
            call_id (str): ID of the call
            format_output (bool): Whether to return formatted transcript (default: True)
            min_chars (int): Minimum number of characters for a text segment to be included (default: 0)
            simple_output (bool): If True, returns only speaker name and text (default: False)
                    
        Returns:
            Dict: Call transcript data with metadata and formatted transcript text
        """
        # First get the extensive call data for metadata
        endpoint = "/calls/extensive"
        data = {
            "contentSelector": {
                "exposedFields": {
                    "parties": True,
                    "metadata": True
                }
            },
            "filter": {
                "callIds": [call_id]
            }
        }

        extensive_response = self._make_request(
            endpoint=endpoint,
            method="POST",
            data=data
        )

        # Extract metadata and speaker information
        metadata = {}
        speaker_map = {}
        
        if extensive_response and 'calls' in extensive_response and extensive_response['calls']:
            call_data = extensive_response['calls'][0]
            if 'metaData' in call_data:
                metadata = {
                    'id': call_data['metaData'].get('id'),
                    'title': call_data['metaData'].get('title'),
                    'url': call_data['metaData'].get('url'),
                    'started': call_data['metaData'].get('started'),
                    'duration': call_data['metaData'].get('duration'),
                    'direction': call_data['metaData'].get('direction'),
                    'purpose': call_data['metaData'].get('purpose')
                }
            
            if 'parties' in call_data:
                for party in call_data['parties']:
                    if 'speakerId' in party and 'name' in party:
                        speaker_map[party['speakerId']] = {
                            'name': party.get('name'),
                            'email': party.get('emailAddress', ''),
                            'title': party.get('title', ''),
                            'affiliation': party.get('affiliation', '')
                        }

        # Get the transcript
        endpoint = "/calls/transcript"
        data = {
            "filter": {
                "callIds": [call_id]
            }
        }

        response = self._make_request(
            endpoint=endpoint,
            method="POST",
            data=data
        )

        if not format_output:
            return {
                'metadata': metadata,
                'transcript_data': response
            }
                
        # Format the transcript
        formatted_transcript = []

        if response and 'callTranscripts' in response:
            for call_transcript in response['callTranscripts']:
                if 'transcript' in call_transcript:
                    for segment in call_transcript['transcript']:
                        speaker_id = segment.get('speakerId', 'Unknown Speaker')
                        speaker_info = speaker_map.get(speaker_id, {'name': f"Speaker {speaker_id}"})
                        
                        # Combine all sentences for this speaker
                        if 'sentences' in segment:
                            sentences = [s['text'] for s in segment['sentences']]
                            text = ' '.join(sentences)
                            
                            # Skip if text is shorter than min_chars
                            if len(text) < min_chars:
                                continue

                            if simple_output:
                                # Add only speaker name and text
                                formatted_transcript.append({
                                    'speaker_name': speaker_info['name'],
                                    'text': text
                                })
                            else:
                                # Add full formatted entry
                                formatted_transcript.append({
                                    'speaker_id': speaker_id,
                                    'speaker_name': speaker_info['name'],
                                    'speaker_title': speaker_info.get('title', ''),
                                    'speaker_email': speaker_info.get('email', ''),
                                    'speaker_affiliation': speaker_info.get('affiliation', ''),
                                    'text': text,
                                    'timestamp': segment['sentences'][0]['start'] if segment['sentences'] else None
                                })

        # Sort by timestamp (only if not using simple output)
        if not simple_output:
            formatted_transcript.sort(key=lambda x: x['timestamp'] if x['timestamp'] is not None else 0)

        # Return both metadata and transcript
        return {
            'metadata': metadata,
            'transcript': formatted_transcript
        }


class GongApiException(Exception):
    """Custom exception for Gong API errors"""
    pass

# Usage example:
if __name__ == "__main__":
    from dotenv import load_dotenv

    # Set up logging
    logging.basicConfig(level=logging.INFO)
    
    # Load environment variables from .env file
    load_dotenv()
    
    # Initialize the Gong API service
    # Option 1: Using environment variables GONG_ACCESS_KEY and GONG_ACCESS_KEY_SECRET
    gong_service = GongApiService()
    
    # Option 2: Providing credentials directly
    # gong_service = GongApiService(
    #     access_key="your_access_key",
    #     access_key_secret="your_access_key_secret"
    # )
    
    try:
        # Get calls from the last 7 days
        from_date = datetime.now() - timedelta(days=7)
        to_date = datetime.now()
        
        calls = gong_service.get_calls(
            from_date=from_date,
            to_date=to_date,
            limit=10  # Get up to 10 calls
        )
        
        print(f"Retrieved {len(calls)} calls")
        
        # Process each call and get its transcript
        for call in calls:
            call_id = call.get('id')
            call_title = call.get('title')
            print(f"\nProcessing call: {call_title} (ID: {call_id})")
            
            # Get the transcript for this call
            try:
                transcript = gong_service.get_call_transcript(call_id, simple_output=True)
                print(f"Transcript retrieved successfully")
                print(transcript)
                
                # Add delay to avoid rate limiting
                time.sleep(1)
                
            except GongApiException as e:
                print(f"Error getting transcript for call {call_id}: {str(e)}")
                
    except GongApiException as e:
        print(f"Error: {str(e)}")
