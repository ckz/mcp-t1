import os

import gspread
import pandas as pd


class GoogleSheetReaderService:
    """
    A service to read data from a Google Sheet.
    Do not forget sharing the Google Sheet with the service account email `google-sheet-api@feedmob.iam.gserviceaccount.com`.
    """

    GOOGLE_API_SCOPES = [
        "https://www.googleapis.com/auth/spreadsheets.readonly",
        "https://www.googleapis.com/auth/drive",
    ]

    def __init__(self):
        self.client = self.__google_api_client()

    def get_spreadsheet_name(self, spreadsheet_id: str):
        return self.client.get_file_drive_metadata(spreadsheet_id).get("name")

    def read_spreadsheets(self, spreadsheet_id: str):
        return self.__google_api_client().open_by_key(spreadsheet_id)

    def read_worksheet(self, spreadsheet_id: str, worksheet_index: int):
        sheet = self.read_spreadsheets(spreadsheet_id)
        return sheet.get_worksheet(worksheet_index)

    def read_all_records(self, spreadsheet_id: str, worksheet_index: int):
        worksheet = self.read_worksheet(spreadsheet_id, worksheet_index)
        return worksheet.get_all_records()

    def read_all_records_as_df(
        self, spreadsheet_id: str, worksheet_index: int
    ) -> pd.DataFrame:
        return pd.DataFrame(self.read_all_records(spreadsheet_id, worksheet_index))

    def __google_api_client(self):
        if os.getenv("GOOGLE_CREDENTIALS__SERVICE_ACCOUNT__PRIVATE_KEY_ID") is None:
            raise ValueError(
                "The GOOGLE_CREDENTIALS__SERVICE_ACCOUNT__PRIVATE_KEY_ID environment variable is not set."
            )
        if os.getenv("GOOGLE_CREDENTIALS__SERVICE_ACCOUNT__PRIVATE_KEY") is None:
            raise ValueError(
                "The GOOGLE_CREDENTIALS__SERVICE_ACCOUNT__PRIVATE_KEY environment variable is not set."
            )

        credentials = {
            "type": "service_account",
            "project_id": "feedmob",
            "private_key_id": os.getenv(
                "GOOGLE_CREDENTIALS__SERVICE_ACCOUNT__PRIVATE_KEY_ID"
            ),
            "private_key": os.getenv(
                "GOOGLE_CREDENTIALS__SERVICE_ACCOUNT__PRIVATE_KEY"
            ),
            "client_email": "google-sheet-api@feedmob.iam.gserviceaccount.com",
            "client_id": "106622861908139489558",
            "auth_uri": "https://accounts.google.com/o/oauth2/auth",
            "token_uri": "https://oauth2.googleapis.com/token",
            "auth_provider_x509_cert_url": "https://www.googleapis.com/oauth2/v1/certs",
            "client_x509_cert_url": "https://www.googleapis.com/robot/v1/metadata/x509/google-sheet-api%40feedmob.iam.gserviceaccount.com",
            "universe_domain": "googleapis.com",
        }
        return gspread.service_account_from_dict(  # type: ignore
            credentials, scopes=self.GOOGLE_API_SCOPES
        )
