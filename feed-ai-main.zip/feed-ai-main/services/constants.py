"""Constants used across services"""

# Prefix used for Slack user emails
SLACK_USER_PREFIX = "slack_"
