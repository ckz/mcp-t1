from datetime import datetime
from typing import Dict

from langchain_core.documents import Document
from pgqueuer.models import Job
from sqlalchemy.ext.asyncio import AsyncSession
from tenacity import retry, stop_after_attempt, wait_exponential

from db.database import get_async_session
from db.qdrant import QdrantCollection
from jobs.base_job import BaseJob, JobPayload
from models.sync_status import SourceType
from services.record_sync_status_service import RecordSyncStatusService
from services.slack_service import SlackService, get_slack_services
from services.vector_store_service import VectorStoreService
from utils.document_splitter import split_text_document
from utils.logging_config import logger
from utils.uuid import generate_uuid_str


class SyncSlackMessagesToDbJobPayload(JobPayload):
    start_time: datetime
    end_time: datetime


class SyncSlackMessagesToDbJob(BaseJob):
    async def execute(self, job: Job, _context):
        logger.info("Running the SyncSlackMessagesToDb task")
        logger.info(f"Job: {job!r}")
        payload = SyncSlackMessagesToDbJobPayload.deserialize(job.payload)
        logger.info(f"Running the SyncSlackMessagesToDb task with Payload: {payload!r}")
        async for session in get_async_session():
            await SyncSlackMessagesToDb(
                start_time=payload.start_time,
                end_time=payload.end_time,
                db_session=session,
            ).run()


class SyncSlackMessagesToDb:
    BATCH_SIZE = 10

    def __init__(
        self,
        start_time: datetime,
        end_time: datetime,
        db_session: AsyncSession,
    ):
        self.start_time = start_time
        self.end_time = end_time
        self.db_session = db_session
        self.collection_name = QdrantCollection.SLACK_API_MESSAGES
        self.service = VectorStoreService(collection_name=self.collection_name)

    async def run(self):
        logger.info("Running the SyncSlackMessagesToDb task")

        slack_services = await get_slack_services(self.db_session)
        for _, workspace, slack_service in slack_services:
            logger.info(f"Syncing Slack messages for workspace: {workspace}")
            slack_channels = slack_service.get_slack_channels()
            if not slack_channels:
                logger.info(f"No channels found in the workspace {workspace}")
                continue
            for channel in slack_channels:
                await self.__sync_slack_messages_for_channel(
                    slack_service=slack_service, channel=channel, workspace=workspace
                )
            logger.info(f"Synced Slack messages for workspace: {workspace}")

        await RecordSyncStatusService(self.db_session).record_sync_status(
            source=SourceType.SLACK,
            payload={
                "start_time": self.start_time.isoformat(),
                "end_time": self.end_time.isoformat(),
            },
        )
        logger.info("Finished running the SyncSlackMessagesToDb task")

    @retry(
        stop=stop_after_attempt(3), wait=wait_exponential(multiplier=1, min=4, max=10)
    )
    async def __sync_slack_messages_for_channel(
        self, slack_service: SlackService, workspace: str, channel: Dict
    ):
        channel_id = channel["id"]
        channel_name = channel["name"]
        current_batch = []
        counter = 0
        for message in slack_service.get_slack_channel_messages(
            channel_id, self.start_time.timestamp(), self.end_time.timestamp()
        ):
            doc = self.__create_slack_message_document(
                slack_service, workspace, channel_id, channel_name, message
            )
            docs = split_text_document(doc)
            current_batch.extend(docs)
            docs.append(doc)
            if len(current_batch) >= self.BATCH_SIZE:
                counter += len(current_batch)
                await self.service.add_to_vector_store(current_batch)
                current_batch = []
        # process remaining documents
        if current_batch:
            counter += len(current_batch)
            await self.service.add_to_vector_store(current_batch)
        # self.vector_store.add_documents(documents=docs)
        logger.info(
            f"{workspace} - {channel_name}: Added {counter} messages to the collection {self.collection_name}"
        )

    def __create_slack_message_document(
        self,
        slack_service: SlackService,
        workspace: str,
        channel_id: str,
        channel_name: str,
        message: Dict,
    ) -> Document:
        content = f"{workspace} - {channel_name}\n"
        id = f"{channel_id}_{message['ts']}"
        content += self.__format_message_text(
            slack_service=slack_service, message=message
        )
        timestamp = datetime.fromtimestamp(float(message["ts"])).isoformat()

        # get thread messages
        if slack_service.has_thread(message):
            for thread_message in slack_service.get_thread_messages(
                channel_id, message["ts"]
            ):
                content += self.__format_message_text(
                    slack_service=slack_service, message=thread_message
                )

        # Create a Document object
        doc = Document(
            page_content=content,
            metadata={
                "id": id,
                "message_ts": message["ts"],
                "workspace": workspace,
                "channel_id": channel_id,
                "channel_name": channel_name,
                "timestamp": timestamp,
                "permalink": slack_service.get_permalink(channel_id, message["ts"]),
                "has_thread": slack_service.has_thread(message),
            },
        )
        doc.id = generate_uuid_str(id)
        return doc

    def __format_message_text(self, slack_service: SlackService, message: Dict):
        user_name = (
            slack_service.get_user_name_by(message["user"])
            if message.get("user")
            else "Unknown"
        )
        timestamp = datetime.fromtimestamp(float(message["ts"])).strftime(
            "%Y-%m-%d %H:%M:%S"
        )
        user_name = (
            slack_service.get_user_name_by(message["user"])
            if message.get("user")
            else "Unknown"
        )
        return f"{timestamp} {user_name}: {slack_service.format_text_message(message['text'])}\n"
