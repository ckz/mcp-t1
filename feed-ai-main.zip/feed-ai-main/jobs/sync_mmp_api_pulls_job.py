import os
import gspread
from langchain.docstore.document import Document
from langchain_qdrant import QdrantVectorStore
from qdrant_client.models import Filter
from qdrant_client import QdrantClient
from datetime import datetime, timedelta

from db.database import get_async_session
from jobs.base_job import BaseJob
from services.bedrock_service import BedrockAIService
from services.record_sync_status_service import RecordSyncStatusService
from models.sync_status import SourceType
from utils.logging_config import logger

class SyncMmpApiPullsJob(BaseJob):
    async def execute(self, _job, _context):
        qdrant_client = QdrantClient(url=os.environ["QDRANT_URL"], api_key=os.environ["QDRANT_API_KEY"])
        async for session in get_async_session():
            await SyncMmpApiPullsTask(qdrant_client=qdrant_client, db_session=session).run()

class SyncMmpApiPullsTask:
    COLLECTION_NAME = "mmp_api_pulls"

    GOOGLE_API_SCOPES = [
        'https://www.googleapis.com/auth/spreadsheets.readonly',
        'https://www.googleapis.com/auth/drive'
    ]
    SPREADSHEET_ID = '1Ylys5L2IXRxzZZBMJm1k8No5lxhx1Yt2TEk_v-bfAkY'

    def __init__(self, qdrant_client, db_session):
        self.qdrant_client = qdrant_client
        self.db_session = db_session

    async def run(self):
        logger.info("Running the MmpApiPullsTask")
        sheet = self.__google_api_client().open_by_key(self.SPREADSHEET_ID)
        sync_status_service = RecordSyncStatusService(self.db_session)
        if self.__skip_running(sheet):
            await sync_status_service.record_sync_status(
                source=SourceType.MMP_API_PULLS,
                payload={ "status": "skipped", "reason": "The Google Sheet was not updated yesterday", "google_sheet_id": self.SPREADSHEET_ID }
            )
            logger.info("Skipping running the task")
            return

        # Delete all points using an empty filter
        self.qdrant_client.delete(
            collection_name="mmp_api_pulls",
            points_selector=Filter(
                must=[]  # Empty filter to match all points
            )
        )

        # Select the first worksheet
        worksheet = sheet.get_worksheet(0)

        # Fetch all records
        records = worksheet.get_all_records()

        # Print the records
        for record in records:
            # Convert the record (a dictionary) to a text string
            content = ', '.join(f"{key}: {value}" for key, value in record.items())
            # Create a Document object
            doc = Document(
                page_content=content,
                metadata={
                    'source': 'Google Sheet',
                    'spreadsheet_id': self.SPREADSHEET_ID,
                    'worksheet_title': worksheet.title
                }
            )
            self.__vector_store().add_documents([doc])
        await sync_status_service.record_sync_status(
            source=SourceType.MMP_API_PULLS,
            payload={ "status": "success", "google_sheet_id": self.SPREADSHEET_ID }
        )
        logger.info("Finished running the MmpApiPullsTask")


    def __skip_running(self, sheet):
        current_date = datetime.now().date()
        last_modified_time = sheet.lastUpdateTime
        last_modified_date = datetime.strptime(last_modified_time, '%Y-%m-%dT%H:%M:%S.%fZ').date()
        yesterday_date = current_date - timedelta(days=1)
        return last_modified_date < yesterday_date

    def __google_api_client(self):
        if os.getenv('GOOGLE_CREDENTIALS__SERVICE_ACCOUNT__PRIVATE_KEY_ID') is None:
            raise ValueError("The GOOGLE_CREDENTIALS__SERVICE_ACCOUNT__PRIVATE_KEY_ID environment variable is not set.")
        if os.getenv('GOOGLE_CREDENTIALS__SERVICE_ACCOUNT__PRIVATE_KEY') is None:
            raise ValueError("The GOOGLE_CREDENTIALS__SERVICE_ACCOUNT__PRIVATE_KEY environment variable is not set.")

        credentials = {
            "type": "service_account",
            "project_id": "feedmob",
            "private_key_id": os.getenv('GOOGLE_CREDENTIALS__SERVICE_ACCOUNT__PRIVATE_KEY_ID'),
            "private_key": os.getenv('GOOGLE_CREDENTIALS__SERVICE_ACCOUNT__PRIVATE_KEY'),
            "client_email": "google-sheet-api@feedmob.iam.gserviceaccount.com",
            "client_id": "106622861908139489558",
            "auth_uri": "https://accounts.google.com/o/oauth2/auth",
            "token_uri": "https://oauth2.googleapis.com/token",
            "auth_provider_x509_cert_url": "https://www.googleapis.com/oauth2/v1/certs",
            "client_x509_cert_url": "https://www.googleapis.com/robot/v1/metadata/x509/google-sheet-api%40feedmob.iam.gserviceaccount.com",
            "universe_domain": "googleapis.com"
        }
        return gspread.service_account_from_dict(credentials, scopes=self.GOOGLE_API_SCOPES)

    def __vector_store(self):
        embeddings = BedrockAIService().embeddings()
        return QdrantVectorStore(
            client=self.qdrant_client,
            collection_name=self.COLLECTION_NAME,
            embedding=embeddings
        )
