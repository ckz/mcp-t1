import os
import tempfile

from sendgrid import SendGridAPIClient
from sendgrid.helpers.mail import Mail, Attachment, FileContent, FileName, FileType, Disposition
import base64
from datetime import datetime
from sqlalchemy.ext.asyncio import AsyncSession

from utils.logging_config import logger
from services.slack_service import SlackService
from models.slack_credential import SlackCredentialRepo
from db.database import get_async_session
from jobs.base_job import JobPayload, BaseJob

from typing import Dict

from pgqueuer.models import Job

class ExportSlackMessageViaEmailJobPayload(JobPayload):
    start_time: datetime
    end_time: datetime

class ExportSlackMessageViaEmailJob(BaseJob):
    async def execute(self, job: Job, context):
        logger.info("Running the export_slack_messages task")
        logger.info(f"Job: {job!r}")
        payload = ExportSlackMessageViaEmailJobPayload.deserialize(job.payload)
        logger.info(f"Running the export_slack_messages task with Payload: {payload!r}")
        async for session in get_async_session():
            await SlackMessagesExporter(start_time=payload.start_time, end_time=payload.end_time, db_session=session).run()


class SlackMessagesExporter:
    RECIPIENT_EMAILS = [
        "summer@feedmob.com",
        "ian@feedmob.com",
        "richard@feedmob.com"
    ]

    def __init__(self, start_time: datetime, end_time: datetime, db_session: AsyncSession):
        self.start_time = start_time
        self.end_time = end_time
        self.db_session = db_session

    async def run(self):
        logger.info("Running the SlackMessagesExporter")
        slack_services = await self.__get_slack_services()
        for workspace, slack_service in slack_services.items():
            logger.info(f"Exporting Slack messages for workspace: {workspace}")
            slack_channels = slack_service.get_slack_channels()
            if not slack_channels:
                logger.info(f"No channels found in the workspace {workspace}")
                continue
            file_path = self.__create_slack_messages_report(
                slack_service=slack_service,
                slack_channels=slack_channels,
            )
            if not file_path:
                logger.error(f"Error creating Slack messages report for workspace {workspace}")
                continue
            if not self.__send_slack_messages_via_email(workspace=workspace, file_path=file_path, recipient_emails=self.RECIPIENT_EMAILS):
                logger.error(f"Error sending Slack messages report via email for workspace {workspace}")
                continue

    async def __get_slack_services(self) -> Dict[str, SlackService]:
        slack_credentials = await SlackCredentialRepo(self.db_session).get_all()
        slack_services = {}
        for slack_credential in slack_credentials:
            slack_service = SlackService(str(slack_credential.access_token))
            workspace = str(slack_credential.team_name)
            slack_services[workspace] = slack_service
        return slack_services

    def __create_slack_messages_report(self, slack_service, slack_channels):
        with tempfile.NamedTemporaryFile(mode='w', suffix='.md', delete=False) as temp_file:
            for channel in slack_channels:
                channel_id = channel['id']
                channel_name = channel['name']
                temp_file.write(f"# {channel_name}\n")
                current_date = None

                for message in slack_service.get_slack_channel_messages(channel_id, self.start_time.timestamp(), self.end_time.timestamp()):
                    timestamp = datetime.fromtimestamp(float(message['ts']))
                    message_date = timestamp.strftime('%Y-%m-%d')
                    if current_date != message_date:
                        current_date = message_date
                        temp_file.write(f"\n## {current_date}\n")
                    temp_file.write(f"{self.__generate_message_text(slack_service=slack_service, message=message)}\n")
                    for reply in slack_service.get_thread_messages(channel_id, message['ts']):
                        temp_file.write(f"  {self.__generate_message_text(slack_service=slack_service, message=reply)}\n")
                temp_file.write("\n")

            return temp_file.name

    def __generate_message_text(self, slack_service: SlackService, message: Dict) -> str:
        message_text = slack_service.format_text_message(message['text'])
        user_name = slack_service.get_user_name_by(message['user']) if message.get('user') else "Unknown"
        message_time = datetime.fromtimestamp(float(message['ts'])).strftime('%Y-%m-%d %H:%M:%S')
        return f"- **{message_time}** {user_name}: {message_text}"

    def __send_slack_messages_via_email(self, workspace: str, file_path: str, recipient_emails: list[str]) -> bool:
        # Read the markdown file
        with open(file_path, 'rb') as f:
            content = f.read()

        # Encode the file content
        encoded_file = base64.b64encode(content).decode()

        current_date = datetime.now()

        # Create the attachment
        attachment = Attachment(
            FileContent(encoded_file),
            FileName(f"slack_messages__{workspace}__{current_date.strftime('%Y%m%d')}.md"),
            FileType('text/markdown'),
            Disposition('attachment')
        )

        # Create the email message
        subject = f"{workspace} - {current_date.strftime('%Y-%m-%d')} - Slack Messages Report"
        message = Mail(
            from_email='no-reply@feedmob.com',  # Replace with your verified sender
            to_emails=recipient_emails,
            subject=subject,
            html_content='Please find attached the Slack messages report.'
        )

        # Add the attachment to the message
        message.attachment = attachment

        try:
            # Initialize SendGrid client with your API key
            sg = SendGridAPIClient(os.getenv('SENDGRID_API_KEY'))
            response = sg.send(message)
            logger.info(f'Email {subject} sent successfully. Status code: {response.status_code}')
            return True
        except Exception as e:
            logger.error(f'Error sending email {subject}: {str(e)}')
            return False
        finally:
            # Clean up the temporary file
            try:
                os.unlink(file_path)
            except Exception as e:
                logger.error(f'Error deleting temporary file: {str(e)}')
