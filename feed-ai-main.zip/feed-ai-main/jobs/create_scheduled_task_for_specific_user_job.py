from pgqueuer import models

from jobs.base_job import BaseJob, JobPayload
from jobs.create_scheduled_task_job import CreateScheduledTaskJobPayload
from services.slack_assistant_service import (
    SlackAssistantBetaService,
    SlackAssistantService,
)
from utils.app_stage import AppStage
from utils.logging_config import logger


class CreateScheduledTaskForSpecificUserJobPayload(JobPayload):
    slack_user_email: str
    instructions: str
    schedule: str
    app_stage: AppStage


class CreateScheduledTaskForSpecificUserJob(BaseJob):
    async def execute(self, job: models.Job, context: models.Context) -> None:
        if job.payload is None:
            raise ValueError("Job payload is missing")
        payload = CreateScheduledTaskForSpecificUserJobPayload.deserialize(job.payload)
        slack_service = (
            SlackAssistantService()
            if AppStage.STABLE == payload.app_stage
            else SlackAssistantBetaService()
        )
        slack_user_id = await slack_service.get_slack_user_id_by_email(
            email=payload.slack_user_email
        )
        if not slack_user_id:
            raise ValueError(f"User with email {payload.slack_user_email} not found")

        response = await slack_service.post_message(
            channel_id=slack_user_id,
            text=f":construction: Your recurring task will be created shortly.\n*Instructions*: {payload.instructions}\n*Schedule*: {payload.schedule}",
        )
        create_payload = CreateScheduledTaskJobPayload(
            slack_user_id=slack_user_id,
            slack_thread_ts=response["ts"],
            task_instructions=payload.instructions,
            task_schedule=payload.schedule,
            app_stage=payload.app_stage,
        )
        logger.info(
            f"Creating recurring task for user {slack_user_id} with instructions '{payload.instructions}' and schedule '{payload.schedule}'"
        )
        from jobs import enqueue_job

        await enqueue_job("create_scheduled_task", create_payload)
