import os
from datetime import datetime, timezone

from pgqueuer import Job

from agents.scheduled_task_agent import ScheduledTaskAgent
from db.database import AsyncSession, get_async_session
from jobs.base_job import BaseJob, JobPayload
from models.scheduled_task import ScheduledTask, ScheduledTaskRepo
from models.scheduled_task_execution_log import (
    ScheduledTaskExecutionLog,
    ScheduledTaskExecutionLogRepo,
    ScheduledTaskExecutionStatus,
)
from models.user import User, UserRepo
from services.slack_assistant_service import (
    SlackAssistantBetaService,
    SlackAssistantService,
)
from utils.app_stage import AppStage
from utils.logging_config import logger
from utils.slack import generate_thread_id, get_user_email


class ExecuteScheduledTaskJobPayload(JobPayload):
    task_id: int


class ExecuteScheduledTaskJob(BaseJob):
    async def execute(self, job: Job, context) -> None:
        logger.info("Executing scheduled tasks job")
        if job.payload is None:
            logger.error("Job payload is missing")
            return
        payload = ExecuteScheduledTaskJobPayload.deserialize(job.payload)
        logger.info(f"Executing task {payload.task_id}")

        async for session in get_async_session():
            session = session
            execution_log = await self.__create_execution_logs(session, payload)
            task = await self.__get_scheduled_task(session, payload)
            if not task.enabled:
                logger.info(f"Skipping... Task {task.id} is disabled")
                return
            slack_service = (
                SlackAssistantService()
                if task.app_stage == AppStage.STABLE
                else SlackAssistantBetaService()
            )
            user = await self.__get_user_by_id(session, str(task.user_id))
            try:
                result = await ScheduledTaskAgent(
                    user=user,
                    thread_id=generate_thread_id(task.slack_thread_ts)
                    if task.slack_thread_ts
                    else None,
                    task_name=task.name,
                    task_instructions=task.instructions,
                ).invoke()
                await self.__send_notification(slack_service, task, user, result)
                await self.__update_execution_logs(session, execution_log, task, result)
            except Exception as e:
                logger.error(f"Error executing task {payload.task_id}: {e}")
                await self.__record_failure(session, execution_log, str(e))

    async def __get_scheduled_task(
        self, session: AsyncSession, payload: ExecuteScheduledTaskJobPayload
    ) -> ScheduledTask:
        id = payload.task_id
        scheduled_tasks_repo = ScheduledTaskRepo(session)
        task = await scheduled_tasks_repo.get_scheduled_task_by_id(id)
        if not task:
            logger.error(f"Scheduled task with id {id} not found")
            raise ValueError(f"Scheduled task with id {id} not found")
        return task

    async def __send_notification(
        self,
        slack_service: SlackAssistantService,
        task: ScheduledTask,
        user: User,
        result: str,
    ):
        next_run = task.next_run_local() if task.next_run else None
        email = self.__get_user_email(user=user)
        url = (
            f"{os.environ['CHAINLIT_URL']}/scheduled_tasks/disable/{task.disable_token}"
        )
        content = f"""
*Recurring Task*

• name: `{task.name}`
• next run at `{next_run.strftime("%Y-%m-%d %H:%M:%S") if next_run else "N/A"} ({task.timezone})`
• if you want to disable it, please visit this URL and confirm: <{url}|Disable>

*Task Instructions*

```
{task.instructions}
```

*Task Execution Result*

{result}
        """
        await slack_service.send_message_by_email(email, content, task.slack_thread_ts)

    async def __get_user_by_id(self, session: AsyncSession, user_id: str) -> User:
        user = await UserRepo(session).get_user_by_id(user_id)
        if not user:
            logger.error(f"User with id {user_id} not found")
            raise ValueError(f"User with id {user_id} not found")
        return user

    def __get_user_email(self, user: User) -> str:
        identifier = user.identifier
        return get_user_email(identifier)

    async def __create_execution_logs(
        self, session: AsyncSession, payload: ExecuteScheduledTaskJobPayload
    ) -> ScheduledTaskExecutionLog:
        log_repo = ScheduledTaskExecutionLogRepo(session)
        log = ScheduledTaskExecutionLog(
            task_id=payload.task_id,
            status=ScheduledTaskExecutionStatus.RUNNING,
            started_at=datetime.now(timezone.utc),
        )
        return await log_repo.upsert(log)

    async def __update_execution_logs(
        self,
        session: AsyncSession,
        execution_log: ScheduledTaskExecutionLog,
        task: ScheduledTask,
        result: str,
    ):
        scheduled_tasks_repo = ScheduledTaskRepo(session)
        task.last_run = datetime.now(timezone.utc)
        task.next_run = task.get_next_run()
        await scheduled_tasks_repo.upsert(task)

        log_repo = ScheduledTaskExecutionLogRepo(session)
        execution_log.status = ScheduledTaskExecutionStatus.SUCCESS
        execution_log.finished_at = datetime.now(timezone.utc)
        execution_log.output = result
        await log_repo.upsert(execution_log)

    async def __record_failure(
        self,
        session: AsyncSession,
        execution_log: ScheduledTaskExecutionLog,
        error: str,
    ):
        log_repo = ScheduledTaskExecutionLogRepo(session)
        execution_log.status = ScheduledTaskExecutionStatus.FAILURE
        execution_log.finished_at = datetime.now(timezone.utc)
        execution_log.error_message = error
        await log_repo.upsert(execution_log)
