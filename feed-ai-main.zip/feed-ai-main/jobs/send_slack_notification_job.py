from pgqueuer import Job
from pydantic import Field
from typing import Optional
from jobs.base_job import JobPayload, BaseJob
from utils.app_stage import AppStage
from services.slack_assistant_service import SlackAssistantService, SlackAssistantBetaService


class SendSlackNotificationJobPayload(JobPayload):
    slack_thread_id: Optional[str] = Field(None, description="The ID of the Slack thread")
    slack_channel_id: Optional[str] = Field(None, description="The Slack channel to send the message to")
    slack_message: str = Field(..., description="The message to send to Slack")
    user_email: str = Field(..., description="The email address of the user to send the message to")
    app_stage: AppStage = Field(..., description="Using beta or stable slack bot to send the message")

class SendSlackNotificationJob(BaseJob):
    async def execute(self, job: Job, context) -> None:
        if job.payload is None:
            raise ValueError("Job payload is missing")
        payload = SendSlackNotificationJobPayload.deserialize(job.payload)
        slack_service = SlackAssistantService() if payload.app_stage == AppStage.STABLE else SlackAssistantBetaService()
        await slack_service.send_message_by_email(
            email=payload.user_email,
            text=payload.slack_message,
            thread_id=payload.slack_thread_id,
        )
