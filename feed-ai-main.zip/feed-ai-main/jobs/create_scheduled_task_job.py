from datetime import datetime, timezone
from typing import Optional

from croniter import croniter
from pgqueuer import Job
from pydantic import BaseModel, Field

from agents.utils.llm_function_calling import StructuredOutputInstructor
from db.database import AsyncSession, get_async_session
from jobs.base_job import BaseJob, JobPayload
from models.scheduled_task import ScheduledTask, ScheduledTaskRepo
from models.user import User, UserRepo
from services.slack_assistant_service import (
    SlackAssistantBetaService,
    SlackAssistantService,
)
from utils.app_stage import AppStage
from utils.crontab import normalize_cron_expression


class CreateScheduledTaskJobPayload(JobPayload):
    slack_user_id: str
    slack_thread_ts: str
    task_instructions: str
    task_schedule: str
    app_stage: AppStage


class TaskSchedule(BaseModel):
    name: str = Field(..., description="Name of the task schedule")
    cron_expression: str = Field(
        ..., description="Cron expression for the task schedule"
    )


class CreateScheduledTaskJob(BaseJob):
    async def execute(self, job: Job, context) -> None:
        if job.payload is None:
            raise ValueError("Job payload is missing")
        payload = CreateScheduledTaskJobPayload.deserialize(job.payload)
        slack_service = (
            SlackAssistantService()
            if AppStage.STABLE == payload.app_stage
            else SlackAssistantBetaService()
        )
        slack_user_id = payload.slack_user_id
        async for session in get_async_session():
            session = session
            user = await self.__get_user_by_slack_user_id(
                session,
                slack_service,
                slack_user_id,
            )
            if user is None:
                raise ValueError("User not found")
            task_schedule = self.__parse_task_schedule(
                payload.task_instructions, payload.task_schedule
            )
            await self.__create_scheduled_task(
                session,
                slack_service,
                payload,
                str(user.id),
                task_schedule,
                payload.task_instructions,
                payload.app_stage,
            )
            await self.__post_slack_notification(
                slack_service=slack_service,
                payload=payload,
                task_schedule=task_schedule,
                task_instructions=payload.task_instructions,
            )

    def __parse_task_schedule(
        self, task_instructions: str, task_schedule: str
    ) -> TaskSchedule:
        message = f"""
Please analyze the task schedule and instructions to generate a structured schedule configuration.

Task Schedule Input:
<task_schedule>
{task_schedule}
</task_schedule>

Task Instructions:
<task_instructions>
{task_instructions}
</task_instructions>

Requirements:
1. Extract a valid cron expression from the task_schedule text
2. Generate a descriptive name based on the task_instructions
3. The cron expression must follow standard cron format (minute hour day-of-month month day-of-week)

Expected Output Format:
- name: A clear, concise name derived from the task instructions
- cron_expression: A valid cron expression extracted from the task schedule

Note: The cron expression should accurately reflect the scheduling requirements specified in the task_schedule.
"""
        schedule = StructuredOutputInstructor(TaskSchedule).invoke_pro(message)
        if not croniter.is_valid(schedule.cron_expression):
            raise ValueError(f"Invalid cron expression: {schedule.cron_expression}")

        schedule.cron_expression = normalize_cron_expression(schedule.cron_expression)
        return schedule

    async def __create_scheduled_task(
        self,
        session: AsyncSession,
        slack_service: SlackAssistantService,
        payload: CreateScheduledTaskJobPayload,
        user_id: str,
        task_schedule: TaskSchedule,
        task_instructions: str,
        app_stage: AppStage,
    ) -> None:
        task = ScheduledTask(
            user_id=user_id,
            name=task_schedule.name,
            expression=task_schedule.cron_expression,
            instructions=task_instructions,
            slack_thread_ts=payload.slack_thread_ts,
            timezone=await self.__get_user_timezone_info(
                slack_service, payload.slack_user_id
            ),
            app_stage=app_stage,
        )
        task.next_run = datetime.now(timezone.utc)
        await ScheduledTaskRepo(session).upsert(task)

    async def __get_user_by_slack_user_id(
        self,
        session: AsyncSession,
        slack_service: SlackAssistantService,
        slack_user_id: str,
    ) -> Optional[User]:
        identifier = await slack_service.get_user_email(slack_user_id)
        if not identifier:
            return None

        return await UserRepo(session).get_user_by_identifier(identifier)

    async def __get_user_timezone_info(
        self, slack_service: SlackAssistantService, slack_user_id: str
    ) -> Optional[str]:
        user = await slack_service.get_user_info(slack_user_id)
        if not user:
            return None

        return user["tz"]

    async def __post_slack_notification(
        self,
        slack_service: SlackAssistantService,
        payload: CreateScheduledTaskJobPayload,
        task_schedule: TaskSchedule,
        task_instructions: str,
    ) -> None:
        await slack_service.post_message(
            channel_id=payload.slack_user_id,
            thread_id=payload.slack_thread_ts,
            text=f"""
:tada: Task created! You will receive a preview of the task within a minute.

*Recurring Task Name:*
{task_schedule.name}

*Schedule*:
• {payload.task_schedule} (`{task_schedule.cron_expression}`)

*Instructions:*
{payload.task_instructions}
""",
        )
