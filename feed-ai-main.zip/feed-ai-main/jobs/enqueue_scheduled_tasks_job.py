from pgqueuer import Job

from db.database import get_async_session
from db.pgqueuer import PgQueuerDecorator
from jobs.base_job import BaseJob
from jobs.execute_scheduled_task_job import ExecuteScheduledTaskJobPayload
from models.scheduled_task import ScheduledTaskRepo
from utils.logging_config import logger


class EnqueueScheduledTasksJob(BaseJob):
    async def execute(self, job: Job, context) -> None:
        logger.info("Executing enqueue scheduled tasks job")

        queries = await PgQueuerDecorator().create_queries()
        async for session in get_async_session():
            session = session
            scheduled_tasks_repo = ScheduledTaskRepo(session)

            # Get tasks that need to be executed
            tasks = await scheduled_tasks_repo.get_tasks_due_for_execution()
            logger.info(f"Found {len(tasks)} tasks to enqueue")

            # Enqueue each task that should be executed
            # FIXME: need to implement something like batch_each
            for task in tasks:
                try:
                    # Create payload for execute task job
                    payload = ExecuteScheduledTaskJobPayload(
                        task_id=task.id
                    ).serialize()

                    # Enqueue the execution job
                    job_ids = await queries.enqueue(
                        "execute_scheduled_task", payload=payload
                    )

                    logger.info(
                        f"Enqueued execution job for task {task.id}, job ids: {job_ids}"
                    )

                    # Update next run time
                    task.next_run = task.get_next_run()
                    await scheduled_tasks_repo.upsert(task)

                except Exception as e:
                    logger.error(f"Error enqueueing task {task.id}: {str(e)}")
                    continue
