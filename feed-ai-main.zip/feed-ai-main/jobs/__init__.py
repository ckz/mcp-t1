from datetime import datetime, timedelta, timezone

from pgqueuer import PgQueuer
from pgqueuer.models import Job, Schedule
from pgqueuer.queries import Queries

from db.pgqueuer import PgQueuerDecorator
from utils.logging_config import logger

from .base_job import JobPayload
from .create_global_suggested_prompts_job import (
    CreateGlobalSuggestedPromptsJob,
    CreateGlobalSuggestedPromptsJobPayload,
)
from .create_scheduled_task_for_specific_user_job import (
    CreateScheduledTaskForSpecificUserJob,
    CreateScheduledTaskForSpecificUserJobPayload,
)
from .create_scheduled_task_job import (
    CreateScheduledTaskJob,
    CreateScheduledTaskJobPayload,
)
from .create_user_suggested_prompts_job import (
    CreateUserSuggestedPromptsJob,
    CreateUserSuggestedPromptsJobPayload,
)
from .enqueue_create_user_suggested_prompts_job import (
    EnqueueCreateUserSuggestedPromptsJob,
)
from .enqueue_scheduled_tasks_job import EnqueueScheduledTasksJob
from .execute_scheduled_task_job import (
    ExecuteScheduledTaskJob,
    ExecuteScheduledTaskJobPayload,
)
from .export_slack_messages_via_email_job import (
    ExportSlackMessageViaEmailJob,
    ExportSlackMessageViaEmailJobPayload,
)
from .one_off_scripts.fix_email_date_job import (
    FixEmailDateJob,
    FixEmailDateJobPayload,
)
from .send_slack_notification_job import (
    SendSlackNotificationJob,
    SendSlackNotificationJobPayload,
)
from .sync_email_documents_to_db_job import (
    SyncEmailDocumentsToDbJob,
    SyncEmailDocumentsToDbJobPayload,
)
from .sync_github_issues_to_db_job import (
    GithubRepo,
    SyncGithubIssuesToDbJob,
    SyncGithubIssuesToDbJobPayload,
)
from .sync_gong_transcripts_to_db_job import (
    SyncGongTranscriptsToDbJob,
    SyncGongTranscriptsToDbJobPayload,
)
from .sync_mmp_api_pulls_job import SyncMmpApiPullsJob
from .sync_slack_channels_to_db_job import SyncSlackChannelsToDbJob
from .sync_slack_messages_to_db_job import (
    SyncSlackMessagesToDbJob,
    SyncSlackMessagesToDbJobPayload,
)
from .sync_slack_messages_v2_to_db_job import (
    SyncSlackMessagesV2ToDbJob,
    SyncSlackMessagesV2ToDbJobPayload,
)


async def enqueue_job(entrypoint: str, payload: JobPayload):
    queries = await PgQueuerDecorator().create_queries()
    await queries.enqueue(entrypoint, payload.serialize())


def initialize_job_entrypoints(pgq: PgQueuer):
    @pgq.entrypoint(
        "one_off__fix_email_date_job",
        executor_factory=FixEmailDateJob,
    )
    async def fix_email_date_job(_job: Job):
        pass

    @pgq.entrypoint(
        "export_slack_messages_via_email",
        executor_factory=ExportSlackMessageViaEmailJob,
    )
    async def export_slack_messages_via_email(_job: Job):
        pass

    @pgq.entrypoint(
        "sync_slack_channels_to_db", executor_factory=SyncSlackChannelsToDbJob
    )
    async def sync_slack_channels_to_db(_job: Job):
        pass

    @pgq.entrypoint(
        "sync_slack_messages_to_db", executor_factory=SyncSlackMessagesToDbJob
    )
    async def sync_slack_messages_to_db(_job: Job):
        pass

    @pgq.entrypoint(
        "sync_slack_messages_v2_to_db", executor_factory=SyncSlackMessagesV2ToDbJob
    )
    async def sync_slack_messages_v2_to_db(_job: Job):
        pass

    @pgq.entrypoint("sync_mmp_api_pulls", executor_factory=SyncMmpApiPullsJob)
    async def sync_mmp_api_pulls(_job: Job):
        pass

    @pgq.entrypoint(
        "sync_gong_transcripts_to_db", executor_factory=SyncGongTranscriptsToDbJob
    )
    async def sync_gong_transcripts_to_db(_job: Job):
        pass

    @pgq.entrypoint(
        "sync_github_issues_to_db", executor_factory=SyncGithubIssuesToDbJob
    )
    async def sync_github_issues_to_db(_job: Job):
        pass

    @pgq.entrypoint(
        "sync_email_documents_to_db", executor_factory=SyncEmailDocumentsToDbJob
    )
    async def sync_email_documents_to_db(_job: Job):
        pass

    @pgq.entrypoint("execute_scheduled_task", executor_factory=ExecuteScheduledTaskJob)
    async def execute_scheduled_task(_job: Job):
        pass

    @pgq.entrypoint(
        "enqueue_scheduled_tasks", executor_factory=EnqueueScheduledTasksJob
    )
    async def enqueue_scheduled_tasks(_job: Job):
        pass

    @pgq.entrypoint("create_scheduled_task", executor_factory=CreateScheduledTaskJob)
    async def create_scheduled_task(_job: Job):
        pass

    @pgq.entrypoint(
        "create_scheduled_task_for_specific_user",
        executor_factory=CreateScheduledTaskForSpecificUserJob,
    )
    async def create_scheduled_task_for_specific_user(_job: Job):
        pass

    @pgq.entrypoint(
        "send_slack_notification", executor_factory=SendSlackNotificationJob
    )
    async def send_slack_notification(_job: Job):
        pass

    @pgq.entrypoint(
        "enqueue_create_user_suggested_prompts",
        executor_factory=EnqueueCreateUserSuggestedPromptsJob,
    )
    async def enqueue_create_user_suggested_prompts_job(_job: Job):
        pass

    @pgq.entrypoint(
        "create_user_suggested_prompts",
        executor_factory=CreateUserSuggestedPromptsJob,
    )
    async def create_user_suggested_prompts_job(_job: Job):
        pass

    @pgq.entrypoint(
        "create_global_suggested_prompts",
        executor_factory=CreateGlobalSuggestedPromptsJob,
    )
    async def create_global_suggested_prompts_job(_job: Job):
        pass


def initialize_job_schedules(pgq: PgQueuer, queries: Queries):
    @pgq.schedule("scheduled_enqueue_scheduled_tasks", "* * * * *")
    async def scheduled_enqueue_scheduled_tasks(schedule: Schedule) -> None:
        job_ids = await queries.enqueue("enqueue_scheduled_tasks", payload=None)
        logger.info(f"Enqueued job#enqueue_scheduled_tasks ids: {job_ids!r}")
        logger.info(f"Executed every minute {schedule!r} {datetime.now()!r}")

    @pgq.schedule("scheduled_enqueue_create_global_suggested_prompts", "0 3 * * 1,3,5")
    async def scheduled_enqueue_create_global_suggested_prompts(
        schedule: Schedule,
    ) -> None:
        end_time = datetime.now(timezone.utc)
        start_time = end_time - timedelta(days=7)
        payload = CreateGlobalSuggestedPromptsJobPayload(
            start_time=start_time, end_time=end_time
        ).serialize()
        job_id = await queries.enqueue(
            "create_global_suggested_prompts", payload=payload
        )
        logger.info(f"Enqueued job#create_global_suggested_prompts id: {job_id!r}")
        logger.info(f"Executed every minute {schedule!r} {datetime.now()!r}")

    @pgq.schedule("scheduled_enqueue_create_user_suggested_prompts", "0 3 * * 2,4,6")
    async def scheduled_enqueue_create_user_suggested_prompts(
        schedule: Schedule,
    ) -> None:
        job_id = await queries.enqueue(
            "enqueue_create_user_suggested_prompts", payload=None
        )
        logger.info(f"Enqueued job#create_user_suggested_prompts id: {job_id!r}")
        logger.info(f"Executed every minute {schedule!r} {datetime.now()!r}")

    @pgq.schedule("scheduled_export_slack_messages_via_email", "5 0 * * *")
    async def scheduled_export_slack_messages_via_email(schedule: Schedule) -> None:
        # export yesterday's messages (UTC Timezone)
        end_time = datetime.now(timezone.utc)
        start_time = end_time.replace(
            hour=0, minute=0, second=0, microsecond=0
        ) - timedelta(days=1)
        payload = ExportSlackMessageViaEmailJobPayload(
            start_time=start_time, end_time=end_time
        ).serialize()
        job_ids = await queries.enqueue(
            "export_slack_messages_via_email", payload=payload
        )
        logger.info(f"Enqueued job#export_slack_messages_via_email ids: {job_ids!r}")
        logger.info(f"Executed every day at 00:05 {schedule!r} {datetime.now()!r}")

    @pgq.schedule("scheduled_sync_mmp_api_pulls", "10 0 * * *")
    async def scheduled_sync_mmp_api_pulls(schedule: Schedule) -> None:
        job_ids = await queries.enqueue(
            "sync_mmp_api_pulls", payload=None, execute_after=timedelta(minutes=1)
        )
        logger.info(f"Enqueued job#sync_mmp_api_pulls ids: {job_ids!r}")
        logger.info(f"Executed every day at 00:10 {schedule!r} {datetime.now()!r}")

    @pgq.schedule("scheduled_sync_slack_messages_to_db", "15 0 * * *")
    async def scheduled_sync_slack_messages_to_db(schedule: Schedule) -> None:
        # Sync past three days' messages (UTC Timezone)
        end_time = datetime.now(timezone.utc)
        start_time = end_time.replace(
            hour=0, minute=0, second=0, microsecond=0
        ) - timedelta(days=2)
        payload = SyncSlackMessagesV2ToDbJobPayload(
            start_time=start_time, end_time=end_time
        ).serialize()
        job_ids = await queries.enqueue(
            "sync_slack_messages_v2_to_db",
            payload=payload,
            execute_after=timedelta(minutes=1),
        )
        logger.info(f"Enqueued job#sync_slack_messages_v2_to_db ids: {job_ids!r}")
        logger.info(f"Executed every day at 00:15 {schedule!r} {datetime.now()!r}")

    @pgq.schedule("periodic_sync_slack_messages_to_db", "*/30 * * * *")
    async def periodic_sync_slack_messages_to_db(schedule: Schedule) -> None:
        end_time = datetime.now(timezone.utc)
        start_time = end_time - timedelta(minutes=60)  # 60 minutes ago
        payload = SyncSlackMessagesV2ToDbJobPayload(
            start_time=start_time, end_time=end_time
        ).serialize()
        job_ids = await queries.enqueue("sync_slack_messages_v2_to_db", payload=payload)
        logger.info(f"Enqueued job#sync_slack_messages_v2_to_db ids: {job_ids!r}")
        logger.info(f"Executed every 30 minutes {schedule!r} {datetime.now()!r}")

    @pgq.schedule("scheduled_sync_github_issues_to_db__feedmob", "45 0 * * *")
    async def scheduled_sync_github_issues_to_db__feedmob(schedule: Schedule) -> None:
        end_time = datetime.now(timezone.utc)
        start_time = end_time.replace(
            hour=0, minute=0, second=0, microsecond=0
        ) - timedelta(days=2)
        payload = SyncGithubIssuesToDbJobPayload(
            repo=GithubRepo.FEEDMOB, start_time=start_time, end_time=end_time
        ).serialize()
        job_ids = await queries.enqueue("sync_github_issues_to_db", payload=payload)
        logger.info(f"Enqueued job#sync_github_issues_to_db ids: {job_ids!r}")
        logger.info(f"Executed every day at 00:45 {schedule!r} {datetime.now()!r}")

    @pgq.schedule("scheduled_sync_github_issues_to_db__tracking_admin", "50 0 * * *")
    async def scheduled_sync_github_issues_to_db__tracking_admin(
        schedule: Schedule,
    ) -> None:
        end_time = datetime.now(timezone.utc)
        start_time = end_time.replace(
            hour=0, minute=0, second=0, microsecond=0
        ) - timedelta(days=2)
        payload = SyncGithubIssuesToDbJobPayload(
            repo=GithubRepo.TRACKING_ADMIN, start_time=start_time, end_time=end_time
        ).serialize()
        job_ids = await queries.enqueue("sync_github_issues_to_db", payload=payload)
        logger.info(f"Enqueued job#sync_github_issues_to_db ids: {job_ids!r}")
        logger.info(f"Executed every day at 00:50 {schedule!r} {datetime.now()!r}")

    @pgq.schedule("scheduled_sync_slack_channels_to_db", "0 1 * * *")
    async def scheduled_sync_slack_channels_to_db(schedule: Schedule) -> None:
        job_ids = await queries.enqueue(
            "sync_slack_channels_to_db",
            payload=None,
            execute_after=timedelta(minutes=1),
        )
        logger.info(f"Enqueued job#sync_slack_channels_to_db ids: {job_ids!r}")
        logger.info(f"Executed every day at 01:00 {schedule!r} {datetime.now()!r}")

    @pgq.schedule("scheduled_sync_email_documents_to_db", "15 1 * * *")
    async def scheduled_sync_email_documents_to_db(schedule: Schedule) -> None:
        end_time = datetime.now(timezone.utc)
        start_time = end_time.replace(
            hour=0, minute=0, second=0, microsecond=0
        ) - timedelta(days=2)
        payload = SyncEmailDocumentsToDbJobPayload(
            start_time=start_time, end_time=end_time
        ).serialize()
        job_ids = await queries.enqueue("sync_email_documents_to_db", payload=payload)
        logger.info(f"Enqueued job#sync_email_documents_to_db ids: {job_ids!r}")
        logger.info(f"Executed every day at 01:15 {schedule!r} {datetime.now()!r}")

    @pgq.schedule("scheduled_sync_gong_transcripts_to_db", "40 1 * * *")
    async def scheduled_sync_gong_transcripts_to_db(schedule: Schedule) -> None:
        end_time = datetime.now(timezone.utc)
        start_time = end_time.replace(
            hour=0, minute=0, second=0, microsecond=0
        ) - timedelta(days=1)
        payload = SyncGongTranscriptsToDbJobPayload(
            start_time=start_time, end_time=end_time
        ).serialize()
        job_ids = await queries.enqueue(
            "sync_gong_transcripts_to_db",
            payload=payload,
            execute_after=timedelta(minutes=1),
        )
        logger.info(f"Enqueued job#sync_gong_transcripts_to_db ids: {job_ids!r}")
        logger.info(f"Executed every day at 01:40 {schedule!r} {datetime.now()!r}")
