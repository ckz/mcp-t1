import re
from datetime import datetime

from langchain_core.documents import Document
from pgqueuer.models import Job
from sqlalchemy.ext.asyncio import AsyncSession
from tenacity import retry, stop_after_attempt, wait_exponential

from db.database import get_async_session
from db.qdrant import QdrantCollection
from jobs.base_job import BaseJob, JobPayload
from models.sync_status import SourceType
from services.femini_service import FeminiService
from services.record_sync_status_service import RecordSyncStatusService
from services.vector_store_service import VectorStoreService
from utils.document_splitter import split_text_document
from utils.logging_config import logger
from utils.text_converter import clean_unicode_escapes, html_to_text
from utils.uuid import generate_uuid_str


class SyncEmailDocumentsToDbJobPayload(JobPayload):
    start_time: datetime
    end_time: datetime


class SyncEmailDocumentsToDbJob(BaseJob):
    async def execute(self, job: Job, context):
        logger.info("Running the SyncEmailDocumentsToDb task")
        logger.info(f"Job: {job!r}")
        if job.payload is None:
            raise ValueError("Job payload is missing")
        payload = SyncEmailDocumentsToDbJobPayload.deserialize(job.payload)
        logger.info(
            f"Running the SyncEmailDocumentsToDb task with Payload: {payload!r}"
        )
        async for session in get_async_session():
            await SyncEmailDocumentsToDb(
                start_time=payload.start_time,
                end_time=payload.end_time,
                db_session=session,
            ).run()


class SyncEmailDocumentsToDb:
    BATCH_SIZE = 10

    def __init__(
        self,
        start_time: datetime,
        end_time: datetime,
        db_session: AsyncSession,
    ):
        self.start_time = start_time
        self.end_time = end_time
        self.db_session = db_session
        self.collection_name = QdrantCollection.EMAIL_DOCUMENTS
        self.service = VectorStoreService(collection_name=self.collection_name)
        self.femini_service = FeminiService()

    @retry(
        stop=stop_after_attempt(3), wait=wait_exponential(multiplier=1, min=4, max=10)
    )
    async def run(self):
        logger.info("Running the SyncEmailDocumentsToDb task")

        current_page = 1
        current_batch = []
        total_processed = 0

        while True:
            try:
                response = self.femini_service.list_documents(
                    page=current_page,
                    limit=10,
                    sort_by="date_desc",
                    date_gteq=self.start_time.date().isoformat(),
                    date_lteq=self.end_time.date().isoformat(),
                    doc_type="email",
                )

                documents = response.get("documents", []) or []
                if not documents:
                    break

                for doc in documents:
                    langchain_doc = self.__create_email_document(doc)
                    docs = split_text_document(langchain_doc)
                    current_batch.extend(docs)

                    if len(current_batch) >= self.BATCH_SIZE:
                        await self.service.add_to_vector_store(current_batch)
                        total_processed += len(current_batch)
                        logger.info(
                            f"Added batch of {len(current_batch)} documents to vector store"
                        )
                        current_batch = []

                # Check if we've processed all pages
                pagination = response.get("pagination", {})
                if not pagination.get("next"):
                    break

                current_page += 1

            except Exception as e:
                logger.error(f"Error processing page {current_page}: {str(e)}")
                raise

        # Process any remaining documents
        if current_batch:
            await self.service.add_to_vector_store(current_batch)
            total_processed += len(current_batch)
            logger.info(
                f"Added final batch of {len(current_batch)} documents to vector store"
            )

        await RecordSyncStatusService(self.db_session).record_sync_status(
            source=SourceType.EMAIL,
            payload={
                "start_time": self.start_time.isoformat(),
                "end_time": self.end_time.isoformat(),
                "total_processed": total_processed,
            },
        )
        logger.info(
            f"Finished running the SyncEmailDocumentsToDb task. Total documents processed: {total_processed}"
        )

    def __create_email_document(self, email_doc: dict) -> Document:
        """
        Create a Document object from an email document

        Args:
            email_doc: Email document from Femini API

        Returns:
            Document: Langchain Document object
        """

        # This is the structure of the email document from Femini API
        #  {
        #       "id": 3025,
        #       "doc_type": "email",
        #       "date": "2025-02-13",
        #       "title": "Re: FeedMob / Stash Android\u003C\u003E Tapjoy // Jan 22nd 2025 - Campaign Launch",
        #       "content": "content",
        #       "source_url": "gmail://19500b8b98406554",
        #       "metadata": {
        #         "to": "Anthony Dimayuga \u003Canthony.dimayuga@unity3d.com\u003E",
        #         "date": "Thu, 13 Feb 2025 14:10:42 -0500",
        #         "from": "Wen \u003Cwen@feedmob.com\u003E",
        #         "gmail_id": "19500b8b98406554",
        #         "thread_id": "19500b8b98406554"
        #       },
        #       "created_at": "2025-02-14T00:30:03.221Z",
        #       "updated_at": "2025-02-14T00:30:03.221Z"
        #     }
        metadata = email_doc.get("metadata", {}) or {}
        title = clean_unicode_escapes(
            email_doc.get("title", "No Subject") or "No Subject"
        )
        to_email = clean_unicode_escapes(metadata.get("to", "Unknown") or "Unknown")
        from_email = clean_unicode_escapes(metadata.get("from", "Unknown") or "Unknown")

        # Clean HTML from email body
        clean_body = html_to_text(email_doc.get("content", "") or "")

        # Construct content with email metadata and cleaned body
        content = f"Subject: {title}\n"
        content += f"From: {from_email}\n"
        content += f"To: {to_email}\n"
        content += f"Date: {metadata.get('date', 'Unknown')}\n\n"
        content += clean_body

        # Create unique ID for the document
        doc_id = generate_uuid_str(f"email_{email_doc.get('id')}")
        doc_metadata = {
            "id": doc_id,
            "document_id": email_doc.get("id"),
            "subject": title,
            "from": from_email,
            "to": to_email,
            "doc_type": email_doc.get("doc_type", "Unknown") or "Unknown",
            "gmail_id": metadata.get("gmail_id", "Unknown") or "Unknown",
            "thread_id": metadata.get("thread_id", "Unknown") or "Unknown",
            "source_url": email_doc.get("source_url", "Unknown") or "Unknown",
        }
        if date := metadata.get("date", None):
            doc_metadata["date"] = self.__convert_date(date)
        if created_at := email_doc.get("created_at", None):
            doc_metadata["created_at"] = created_at
        if updated_at := email_doc.get("updated_at", None):
            doc_metadata["updated_at"] = updated_at

        # Create Document object with metadata
        doc = Document(page_content=content, metadata=doc_metadata)
        doc.id = doc_id
        return doc

    def __convert_date(self, date_str: str) -> str:
        try:
            # Remove timezone in parentheses only if it's at the end of the string
            date_str = re.sub(r" \([A-Za-z]+\)$", "", date_str)

            # Try parsing RFC 2822 format
            return datetime.strptime(date_str, "%a, %d %b %Y %H:%M:%S %z").strftime(
                "%Y-%m-%d"
            )
        except ValueError:
            try:
                # Try parsing direct "YYYY-MM-DD" format
                return datetime.strptime(date_str, "%Y-%m-%d").strftime("%Y-%m-%d")
            except ValueError:
                raise ValueError(f"Unsupported date format: {date_str}")
