import random
from datetime import datetime, timedelta, timezone

import sentry_sdk as sentry
from pgqueuer import Job

from db.database import get_async_session
from db.pgqueuer import PgQueuerDecorator
from jobs.base_job import BaseJob
from jobs.create_user_suggested_prompts_job import CreateUserSuggestedPromptsJobPayload
from models.user import UserRepo
from utils.logging_config import logger


class EnqueueCreateUserSuggestedPromptsJob(BaseJob):
    async def execute(self, job: Job, context):
        current_date = datetime.now(timezone.utc).date()
        queries = await PgQueuerDecorator().create_queries()
        async for session in get_async_session():
            for id in await UserRepo(session).get_all_slack_user_ids():
                try:
                    payload = CreateUserSuggestedPromptsJobPayload(
                        user_id=id, date=current_date
                    ).serialize()
                    delay = timedelta(seconds=random.randint(1, 300))
                    job_id = await queries.enqueue(
                        "create_user_suggested_prompts",
                        payload=payload,
                        execute_after=delay,
                    )
                    logger.info(f"Enqueued job {job_id} for user {id}")
                except Exception as e:
                    sentry.capture_exception(e)
                    logger.error(f"Error enqueuing job for user {id}, error: {e}")
                    continue
