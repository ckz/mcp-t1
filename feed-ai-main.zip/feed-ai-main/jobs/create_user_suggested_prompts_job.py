from datetime import date, datetime, timedelta, timezone
from typing import Tuple
from zoneinfo import ZoneInfo

from pgqueuer import Job

from agents.tools.personalize_slack_message_aggregator import (
    PersonalizeSlackMessageAggregator,
)
from db.database import get_async_session
from jobs.base_job import BaseJob, JobPayload
from models.suggested_prompt import SuggestedPromptRepo
from models.user import User, UserRepo
from utils.logging_config import logger


class CreateUserSuggestedPromptsJobPayload(JobPayload):
    user_id: str
    date: date


class CreateUserSuggestedPromptsJob(BaseJob):
    async def execute(self, job: Job, context) -> None:
        if job.payload is None:
            raise ValueError("Payload is missing")

        payload = CreateUserSuggestedPromptsJobPayload.deserialize(job.payload)
        user = await self.__get_current_user(payload.user_id)
        # FIXME: We are using utc timezone currently. Might be able to use user's timezone for start_time and end_time
        start_time, end_time = self.__get_datetime_range(payload.date)
        questions = await self.__get_personalized_questions(
            user,
            start_time,
            end_time,
        )
        if not questions:
            logger.info(f"No questions found for user {user.id}")
            return

        async for session in get_async_session():
            record = await SuggestedPromptRepo(session).create_suggested_prompts(
                user_id=user.id, prompts=questions, suggestion_date=payload.date
            )
            logger.info(f"Created suggested prompt#{record.id} for user {user.id}")

    async def __get_current_user(self, user_id: str) -> User:
        user = None
        async for session in get_async_session():
            user = await UserRepo(session).get_user_by_id(user_id)

        if user is None:
            logger.error(f"User with id {user_id} not found")
            raise ValueError(f"User with id {user_id} not found")
        return user

    def __get_datetime_range(
        self, reference_date: date, source_tz: ZoneInfo = ZoneInfo("UTC")
    ) -> Tuple[datetime, datetime]:
        """
        Returns a UTC timezone-aware datetime range where:
        - Dates are calculated based on the specified source timezone
        - start: 7 days ago before the day before reference date
        - end: the day before reference date (yesterday)
        - Both returned datetimes are in UTC

        Args:
            reference_date: The reference date (defaults to today if None)
            source_timezone: The timezone to use for date calculations (defaults to "UTC")

        Returns:
            Tuple[datetime, datetime]: Start and end datetimes with UTC timezone
        """
        yesterday = reference_date - timedelta(days=1)
        start_date = yesterday - timedelta(days=7)

        start_local = datetime.combine(start_date, datetime.min.time()).replace(
            tzinfo=source_tz
        )
        end_local = datetime.combine(yesterday, datetime.max.time()).replace(
            tzinfo=source_tz
        )

        # Convert to UTC
        start_utc = start_local.astimezone(timezone.utc)
        end_utc = end_local.astimezone(timezone.utc)

        return start_utc, end_utc

    async def __get_personalized_questions(
        self, user: User, start_time: datetime, end_time: datetime
    ) -> list[str]:
        tool = PersonalizeSlackMessageAggregator(user=user)
        personalized = await tool.ainvoke(
            input={"start_time": start_time, "end_time": end_time}
        )
        logger.info(f"Personalized questions for user {user.id}: {personalized}")
        return personalized.questions
