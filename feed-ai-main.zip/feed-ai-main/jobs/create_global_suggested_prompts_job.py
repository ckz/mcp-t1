from datetime import datetime, timezone

from langchain_core.prompts import PromptTemplate
from pgqueuer import Job
from pgqueuer.models import Context
from pydantic import BaseModel

from agents.utils.llm_function_calling import StructuredOutputInstructor
from db.database import get_async_session
from jobs.base_job import BaseJob, JobPayload
from models.suggested_prompt import SuggestedPromptRepo
from models.user import UserRepo
from services.bedrock_service import OpenrouterModel
from utils.logging_config import logger


class CreateGlobalSuggestedPromptsJobPayload(JobPayload):
    start_time: datetime
    end_time: datetime


class SuggestedQuestions(BaseModel):
    questions: list[str]


class CreateGlobalSuggestedPromptsJob(BaseJob):
    async def execute(self, job: Job, context: Context) -> None:
        if job.payload is None:
            raise ValueError("Job payload is missing")

        payload = CreateGlobalSuggestedPromptsJobPayload.deserialize(job.payload)
        suggested_questions = await self.__generate_suggested_questions(
            payload.start_time, payload.end_time
        )
        async for session in get_async_session():
            await SuggestedPromptRepo(session).create_global_prompts(
                prompts=suggested_questions,
                suggestion_date=datetime.now(timezone.utc).date(),
            )

    async def __get_all_users_questions(
        self, start_time: datetime, end_time: datetime
    ) -> list[dict]:
        async for session in get_async_session():
            questions = await UserRepo(session).get_all_users_questions(
                start_time, end_time, limit=500
            )
            return [
                {
                    "thread_name": question["thread_name"],
                    "user_message": question["user_message"],
                }
                for question in questions
            ]
        return []

    async def __generate_suggested_questions(
        self, start_time: datetime, end_time: datetime
    ) -> list[str]:
        all_users_questions = await self.__get_all_users_questions(start_time, end_time)
        prompt_template = """
        You are an AI assistant tasked with generating suggested prompts for users based on historical usage patterns for FeedAI, our AI assistant system.

        Today is {today_date}

        FeedAI CAPABILITIES:
        1. Data Analysis & Querying
           - Search through Hubspot tickets and notes
           - Query Slack messages and threads across channels
           - Access and analyze email documents
           - Review Gong call transcripts
           - Query MMP API Pulls and Dev Support reports

        2. Financial Information
           - Access client billing information
           - Review vendor/partner billing details
           - Track campaign spending data
           - Monitor client monthly goals
           - Analyze campaign performance metrics

        3. System Status & Monitoring
           - Check sync status for various data sources (Slack, Hubspot, MMP API, Gong, Email)
           - Track system updates and performance

        4. Search & Information Retrieval
           - Search through user and shared memories
           - Extract and validate Slack channel names
           - Search for client and partner information
           - Access historical conversations and context

        5. Data Visualization
           - Create and display Plotly charts
           - Visualize data with accompanying explanations

        Below is a list of recent questions asked by users:
        {all_users_questions}

        Based on these historical questions and FeedAI's capabilities, please generate 5-7 high-quality, diverse suggested prompts that would be valuable for users of our system. These prompts should:

        1. Cover different aspects of FeedAI's capabilities
        2. Be clear, concise, and easily understandable
        3. Be phrased as questions or instructions a user might want to ask
        4. Avoid duplicating exact questions from the historical data
        5. Be broadly useful to many users rather than being too niche
        6. Focus on productive use cases for FeedAI

        Output the suggested prompts as a list of strings, with no numbering or additional text.
        For example:
        ["Show me the latest Hubspot tickets for client XYZ",
         "Summarize Slack discussions about the recent product launch",
         "Create a chart of campaign performance for the last quarter",
         "Find all Gong calls where pricing was discussed with client ABC",
         "What's the current sync status of our data sources?"]
        """
        prompt = PromptTemplate(
            template=prompt_template,
            input_variables=["all_users_questions", "today_date"],
        ).format(
            all_users_questions=all_users_questions,
            today_date=datetime.now(timezone.utc).date(),
        )
        logger.info(f"Generating suggested prompts: {prompt}")
        suggested = StructuredOutputInstructor(SuggestedQuestions).invoke(
            model=OpenrouterModel.GEMINI_2_0, prompt=prompt
        )
        return suggested.questions
