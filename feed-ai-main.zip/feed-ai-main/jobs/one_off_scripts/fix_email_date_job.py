import re
from datetime import datetime

from pgqueuer import models
from qdrant_client import models as qdrant_models
from qdrant_client.conversions.common_types import PointStruct

from db.qdrant import QdrantCollection, create_qdrant_client
from jobs.base_job import BaseJob, JobPayload


class FixEmailDateJobPayload(JobPayload):
    start_time: datetime
    end_time: datetime


class FixEmailDateJob(BaseJob):
    async def execute(self, job: models.Job, context: models.Context) -> None:
        if job.payload is None:
            raise ValueError("Job payload is missing")

        payload = FixEmailDateJobPayload.deserialize(job.payload)
        offset = None
        while True:
            points, next_offset = self.__get_email_documents(
                payload.start_time, payload.end_time, offset
            )
            if not points:
                break

            new_points = []
            for point in points:
                # Fix the email date here
                new_point = self.__fix_date_issue(point)
                if new_point is not None:
                    new_points.append(new_point)

            self.__qdrant_client().upsert(
                collection_name=QdrantCollection.EMAIL_DOCUMENTS.value,
                points=new_points,
            )
            offset = next_offset
            if next_offset is None:
                break

    def __get_email_documents(
        self, start_time: datetime, end_time: datetime, offset=None
    ):
        response = self.__qdrant_client().scroll(
            collection_name=QdrantCollection.EMAIL_DOCUMENTS.value,
            scroll_filter=qdrant_models.Filter(
                must=[
                    qdrant_models.FieldCondition(
                        key="metadata.created_at",
                        range=qdrant_models.DatetimeRange(gte=start_time, lte=end_time),
                    )
                ]
            ),
            offset=offset,
            limit=100,
            with_payload=True,
            with_vectors=True,
        )
        return response

    def __fix_date_issue(self, point: qdrant_models.Record):
        # Fix the email date here
        payload = point.payload
        vector = point.vector
        if not payload or not vector:
            return None
        invalid_date = payload.get("metadata", {}).get("date")
        if not invalid_date:
            return None
        payload["metadata"]["date"] = self.convert_date(invalid_date)
        return PointStruct(id=point.id, payload=payload, vector=vector)

    def convert_date(self, date_str: str) -> str:
        try:
            # Remove timezone in parentheses only if it's at the end of the string
            date_str = re.sub(r" \([A-Za-z]+\)$", "", date_str)

            # Try parsing RFC 2822 format
            return datetime.strptime(date_str, "%a, %d %b %Y %H:%M:%S %z").strftime(
                "%Y-%m-%d"
            )
        except ValueError:
            try:
                # Try parsing direct "YYYY-MM-DD" format
                return datetime.strptime(date_str, "%Y-%m-%d").strftime("%Y-%m-%d")
            except ValueError:
                raise ValueError(f"Unsupported date format: {date_str}")

    def __qdrant_client(self):
        return create_qdrant_client()
