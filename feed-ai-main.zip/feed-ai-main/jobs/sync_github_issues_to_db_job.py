import os
import uuid
from datetime import datetime, timezone
from enum import Enum

from langchain_community.document_loaders import GitHubIssuesLoader
from langchain_core.documents import Document
from pgqueuer.models import Job
from tenacity import retry, stop_after_attempt, wait_exponential

from db.qdrant import QdrantCollection
from jobs.base_job import BaseJob, JobPayload
from services.vector_store_service import VectorStoreService
from utils.document_splitter import split_markdown_document
from utils.logging_config import logger


class GithubRepo(str, Enum):
    TRACKING_ADMIN = "feed-mob/tracking_admin"
    FEEDMOB = "feed-mob/feedmob"


class SyncGithubIssuesToDbJobPayload(JobPayload):
    repo: GithubRepo
    start_time: datetime
    end_time: datetime


class SyncGithubIssuesToDbJob(BaseJob):
    async def execute(self, job: Job, context):
        if job.payload is None:
            raise ValueError("Payload is required for SyncGithubIssuesToDbJob")

        payload = SyncGithubIssuesToDbJobPayload.deserialize(job.payload)
        logger.info(f"Running the SyncGithubIssuesToDb task with Payload: {payload!r}")
        await SyncGithubIssueToDb(
            service=self.__qdrant_vector_store_service(),
            repo=payload.repo,
            start_time=payload.start_time,
            end_time=payload.end_time,
        ).run()

    def __qdrant_vector_store_service(self):
        return VectorStoreService(collection_name=QdrantCollection.GITHUB_ISSUES)


class SyncGithubIssueToDb:
    BATCH_SIZE = 10

    def __init__(
        self,
        service: VectorStoreService,
        repo: GithubRepo,
        start_time: datetime,
        end_time: datetime,
    ):
        if start_time > end_time:
            raise ValueError("start_time must be before end_time")

        self.access_token = os.getenv("GITHUB_PERSONAL_ACCESS_TOKEN")
        self.repo = repo
        self.start_time = start_time
        self.end_time = end_time
        self.service = service

    @retry(
        stop=stop_after_attempt(3), wait=wait_exponential(multiplier=1, min=4, max=10)
    )
    async def run(self):
        try:
            loader = self.__loader()
            current_batch = []
            for doc in loader.lazy_load():
                created_at = datetime.strptime(
                    doc.metadata["created_at"], "%Y-%m-%dT%H:%M:%SZ"
                )  # '2025-02-04T21:00:45Z'
                if not created_at.tzinfo:
                    created_at = created_at.replace(tzinfo=timezone.utc)
                if not self.end_time.tzinfo:
                    self.end_time = self.end_time.replace(tzinfo=timezone.utc)
                if created_at > self.end_time:
                    logger.info(
                        f"Skip {doc.metadata['url']} because it's created after the end_time."
                    )
                    break

                docs = self.__process_document(doc)
                current_batch.extend(docs)
                if len(current_batch) >= self.BATCH_SIZE:
                    await self.service.add_to_vector_store(current_batch)
                    current_batch = []

            # process remaining documents
            if current_batch:
                await self.service.add_to_vector_store(current_batch)
        except Exception as e:
            logger.error(f"Error syncing GitHub issues to DB: {e}")
            raise

    def __loader(self):
        if not self.access_token:
            raise ValueError("GITHUB_PERSONAL_ACCESS_TOKEN env var is not set.")
        return GitHubIssuesLoader(
            repo=self.repo,
            access_token=self.access_token,
            include_prs=False,
            state="all",
            sort="updated",
            since=self.start_time.strftime("%Y-%m-%dT%H:%M:%SZ"),  # iso8601
            direction="asc",
        )

    def __process_document(self, doc: Document) -> list[Document]:
        url = doc.metadata["url"]
        title = doc.metadata["title"]
        doc.id = str(uuid.uuid5(uuid.NAMESPACE_DNS, url))
        doc.page_content = title + "\n\n" + doc.page_content.strip()
        doc.metadata["repo"] = self.repo.value
        return split_markdown_document(doc)
