import uuid
from datetime import datetime
from sqlalchemy.ext.asyncio import AsyncSession
from typing import Dict, Optional

from db.database import get_async_session
from jobs.base_job import BaseJob
from models.slack_channel import SlackChannelRepo, SlackChannel
from services.slack_service import get_slack_services
from utils.logging_config import logger

class SyncSlackChannelsToDbJob(BaseJob):
    async def execute(self, job, _context):
        logger.info(f"Running the SyncSlackChannelsToDbJob")
        logger.info(f"Job: {job!r}")
        async for session in get_async_session():
            await SyncSlackChannelsToDb(db_session=session).run()

class SyncSlackChannelsToDb:
    def __init__(
        self,
        db_session: AsyncSession,
    ):
        self.db_session = db_session

    async def run(self):
        logger.info("Running the SyncSlackMessagesToDb task")
        slack_services = await get_slack_services(self.db_session)
        for slack_credential_id, workspace, slack_service in slack_services:
            logger.info(f"Updating Slack Channels for workspace: {workspace}")
            slack_channels = slack_service.get_slack_channels()
            if not slack_channels:
                logger.info(f"No channels found in the workspace {workspace}")
                continue
            db_slack_channels = await self.__convert_to_db_models(slack_channels, slack_credential_id)
            await SlackChannelRepo(self.db_session).upsert(db_slack_channels)
            logger.info(f"Updated Slack Channels for workspace: {workspace}")

    async def __convert_to_db_models(self, slack_channels: list[Dict], slack_credential_id: uuid.UUID) -> list[SlackChannel]:
        slack_channel_ids = [channel['id'] for channel in slack_channels]
        slack_channel_objs = await SlackChannelRepo(self.db_session).get_by_channel_ids(slack_channel_ids)
        models = []
        for slack_channel in slack_channels:
            slack_channel_obj = next((channel for channel in slack_channel_objs if channel.channel_id == slack_channel['id']), None)
            models.append(self.__convert_slack_channel_to_db_model(slack_channel, slack_channel_obj, slack_credential_id))
        return models

    def __convert_slack_channel_to_db_model(self, slack_channel: Dict, slack_channel_obj: Optional[SlackChannel], slack_credential_id: uuid.UUID) -> SlackChannel:
        id = slack_channel_obj.id if slack_channel_obj else uuid.uuid4()
        return SlackChannel(
            id=id,
            channel_id=slack_channel['id'],
            channel_name=slack_channel['name'],
            slack_credential_id=slack_credential_id,
            updated_at=datetime.now(),
        )
