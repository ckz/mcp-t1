from pydantic import BaseModel
from typing import TypeVar, Type, Generic, cast
from utils.serializers import Object2BytesSerializer
from pgqueuer.executors import AbstractEntrypointExecutor

T = TypeVar('T', bound='JobPayload')

class JobPayload(BaseModel, Generic[T]):
    def serialize(self) -> bytes:
        return Object2BytesSerializer().serialize(self)

    @classmethod
    def deserialize(cls: Type[T], data: bytes) -> T:
        return cast(T, Object2BytesSerializer().deserialize(data, cls))

class BaseJob(AbstractEntrypointExecutor):
    pass
