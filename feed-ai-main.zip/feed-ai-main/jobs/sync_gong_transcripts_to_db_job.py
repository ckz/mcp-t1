import os
import uuid
from datetime import datetime
from qdrant_client import QdrantClient
from botocore.client import BaseClient as BotocoreBaseClient
from langchain.docstore.document import Document
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_qdrant import QdrantVectorStore
from sqlalchemy.ext.asyncio import AsyncSession
from typing import Dict, List
from pgqueuer.models import Job

from models.sync_status import SourceType
from services.gong_service import GongApiService
from services.record_sync_status_service import RecordSyncStatusService
from services.bedrock_service import BedrockAIService
from utils.logging_config import logger
from jobs.base_job import BaseJob, JobPayload
from db.database import get_async_session

class SyncGongTranscriptsToDbJobPayload(JobPayload):
    start_time: datetime
    end_time: datetime

class SyncGongTranscriptsToDbJob(BaseJob):
    async def execute(self, job: Job, _context):
        logger.info(f"Running the SyncGongTranscriptsToDb task")
        logger.info(f"Job: {job!r}")
        payload = SyncGongTranscriptsToDbJobPayload.deserialize(job.payload)
        logger.info(f"Running the SyncGongTranscriptsToDb task with Payload: {payload!r}")

        gong_service = GongApiService()  # Initialize the Gong service
        qdrant_client = QdrantClient(url=os.environ["QDRANT_URL"], api_key=os.environ["QDRANT_API_KEY"])
        async for session in get_async_session():
            await SyncGongTranscriptsToDb(
                start_time=payload.start_time,
                end_time=payload.end_time,
                qdrant_client=qdrant_client,
                db_session=session,
                gong_service=gong_service
            ).run()


class SyncGongTranscriptsToDb:
    COLLECTION_NAME = "gong_call_transcripts"
    CHUNK_SIZE = 8192
    CHUNK_OVERLAP = 200

    def __init__(
        self,
        start_time: datetime,
        end_time: datetime,
        db_session: AsyncSession,
        qdrant_client: QdrantClient,
        gong_service: GongApiService
    ):
        self.start_time = start_time
        self.end_time = end_time
        self.db_session = db_session
        self.qdrant_client = qdrant_client
        self.gong_service = gong_service
        self.vector_store = self.__vector_store()

    async def run(self):
        logger.info("Running the SyncGongTranscriptsToDb task")

        try:
            # Get all calls within the date range
            calls = self.gong_service.get_calls(
                from_date=self.start_time,
                to_date=self.end_time
            )

            if not calls:
                logger.info("No calls found in the specified date range")
                return

            # Process each call and its transcript
            for call in calls:
                logger.info(f"Processing call {call.get('id')} started at {call.get('started')}")
                await self.__sync_call_transcript(call)

            # Record sync status
            await RecordSyncStatusService(self.db_session).record_sync_status(
                source=SourceType.GONG,
                payload={
                    "start_time": self.start_time.isoformat(),
                    "end_time": self.end_time.isoformat()
                }
            )
            logger.info("Finished running the SyncGongTranscriptsToDb task")

        except Exception as e:
            logger.error(f"Error syncing Gong transcripts: {str(e)}")
            raise

    async def __sync_call_transcript(self, call: Dict):
        call_id = call.get('id')
        if not call_id:
            logger.warning("Call ID not found in call data")
            return

        try:
            # Get the transcript and metadata for this call
            transcript_data = self.gong_service.get_call_transcript(
                call_id=call_id, 
                format_output=True,
                simple_output=False
            )
            
            if not transcript_data or 'transcript' not in transcript_data:
                logger.info(f"No transcript found for call {call_id}")
                return

            # Extract metadata and transcript
            metadata = transcript_data['metadata']
            transcript = transcript_data['transcript']

            # Create base metadata
            base_metadata = {
                "call_id": metadata['id'],
                "title": metadata['title'],
                "url": metadata['url'],
                "start_time": metadata['started'],
                "duration": metadata['duration'],
                "direction": metadata['direction'],
                "purpose": metadata['purpose'],
                "source": "gong"
            }

            # Format content from transcript
            content = self.__format_transcript_content(transcript)

            # Split the content into chunks
            text_splitter = RecursiveCharacterTextSplitter(
                chunk_size=self.CHUNK_SIZE,
                chunk_overlap=self.CHUNK_OVERLAP,
                length_function=len,
                separators=["\n\n", "\n", " ", ""]
            )
            
            chunks = text_splitter.split_text(content)
            documents = []
            doc_ids = []

            # Create a document for each chunk
            for i, chunk in enumerate(chunks):
                chunk_id = f"gong_call_{metadata['id']}_chunk_{i}"
                uuid_id = str(uuid.uuid5(uuid.NAMESPACE_DNS, chunk_id))
                
                # Add chunk-specific metadata
                chunk_metadata = base_metadata.copy()
                chunk_metadata.update({
                    "id": chunk_id,
                    "chunk_index": i,
                    "total_chunks": len(chunks)
                })

                doc = Document(
                    page_content=chunk,
                    metadata=chunk_metadata
                )
                
                documents.append(doc)
                doc_ids.append(uuid_id)

            # Add all chunks to the vector store
            self.vector_store.add_documents(documents=documents, ids=doc_ids)
            logger.info(f"Added {len(chunks)} chunks for call {call_id} to collection {self.COLLECTION_NAME}")

        except Exception as e:
            logger.error(f"Error processing transcript for call {call_id}: {str(e)}")

    def __format_transcript_content(self, transcript: List[Dict]) -> str:
        """
        Format the transcript content in a minimal way, including only speaker names and text
        """
        content = []
        current_speaker = None
        current_text_parts = []

        for segment in transcript:
            speaker_name = segment['speaker_name']
            text = segment['text'].strip()
            
            # Skip empty text
            if not text:
                continue

            # If same speaker, combine text
            if speaker_name == current_speaker:
                current_text_parts.append(text)
            else:
                # Add previous speaker's combined text
                if current_speaker and current_text_parts:
                    content.append(f"{current_speaker}: {' '.join(current_text_parts)}")
                
                # Start new speaker's text
                current_speaker = speaker_name
                current_text_parts = [text]

        # Add the last speaker's text
        if current_speaker and current_text_parts:
            content.append(f"{current_speaker}: {' '.join(current_text_parts)}")

        return "\n".join(content)

    def __vector_store(self):
        embeddings = BedrockAIService().embeddings_v2()
        return QdrantVectorStore(
            client=self.qdrant_client,
            collection_name=self.COLLECTION_NAME,
            embedding=embeddings
        )
