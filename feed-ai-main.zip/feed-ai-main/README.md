# AI Chatbot powered by Amazon Bedrock 🚀 🤖

- https://claude.feedmob.com/

![Feed AI Diagram](./docs/assets/feedai-diagram.png)

## How to run this project

- Clone Gitmodules

```bash
git submodule init
git submodule update
```

- Copy `.env.example` to `.env`
- Install [just](https://github.com/casey/just) CLI on your machine
- Install [uv](https://github.com/astral-sh/uv) CLI on your machine

  ```bash
  curl -LsSf https://astral.sh/uv/install.sh | sh
  ```

- Install [bun](https://bun.sh/) CLI on your machine

```bash
curl -fsSL https://bun.sh/install | bash
```

- Install [pnpm](https://pnpm.io/) CLI on your machine

```bash
curl -fsSL https://get.pnpm.io/install.sh | sh -
```

- Start the services

  - web

  ```bash
  just run
  ```

  - slack

  ```bash
  just run-slack-app
  ```

  - worker

  ```bash
  just run-worker
  ```

## PGQueuer CLI

- Install

```bash
just pgq install
```

- Dashboard: Display a live dashboard showing job statistics.

```bash
just pgq dashboard
```
