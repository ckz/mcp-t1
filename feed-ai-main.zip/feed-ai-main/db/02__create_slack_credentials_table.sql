CREATE TABLE IF NOT EXISTS slack_credentials (
    "id" UUID PRIMARY KEY,
    "app_id" varchar(50) NOT NULL,
    "authed_user_id" varchar(50) NOT NULL,
    "scope" text NOT NULL,
    "token_type" varchar(50) NOT NULL,
    "access_token" varchar(256) NOT NULL,
    "bot_user_id" varchar(50) NOT NULL,
    "team_id" varchar(50) NOT NULL,
    "team_name" varchar(256) NOT NULL,
    "created_at" timestamp WITH TIME ZONE NOT NULL,
    "updated_at" timestamp WITH TIME ZONE NOT NULL
);
