-- Create the table to store scheduled tasks
CREATE TABLE IF NOT EXISTS scheduled_tasks (
    id SERIAL PRIMARY KEY,
    user_id UUID NOT NULL,
    expression VARCHAR(255) NOT NULL,
    name VARCHAR(255) NOT NULL,
    instructions TEXT NOT NULL,
    enabled BOOLEAN NOT NULL DEFAULT TRUE,
    slack_thread_ts VARCHAR(255),
    next_run TIMESTAMP,
    last_run TIMESTAMP,
    disable_token UUID DEFAULT gen_random_uuid (),
    app_stage VARCHAR(50) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create the table to store execution logs for scheduled tasks
CREATE TABLE IF NOT EXISTS scheduled_task_execution_logs (
    id SERIAL PRIMARY KEY,
    task_id INT NOT NULL,
    started_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    finished_at TIMESTAMP,
    status VARCHAR(50) NOT NULL,
    output TEXT,
    error_message TEXT,
    FOREIGN KEY (task_id) REFERENCES scheduled_tasks (id) ON DELETE CASCADE
);
