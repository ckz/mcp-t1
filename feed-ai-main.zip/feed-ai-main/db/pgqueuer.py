import os
import asyncpg
from pgqueuer.db import AsyncpgDriver
from pgqueuer import PgQueuer
from pgqueuer.queries import Queries

class PgQueuerDecorator:
    DATABASE_URL = os.environ["CHECKPOINTER_DATABASE_URL"]

    def __init__(self):
        self._pg_driver = None  # private variable for caching

    async def create_pgq(self):
        driver = await self.pg_driver
        return PgQueuer(driver)

    async def create_queries(self):
        driver = await self.pg_driver
        return Queries(driver)

    @property
    async def pg_driver(self):
        if self._pg_driver is None:
            connection = await asyncpg.connect(dsn=self.DATABASE_URL)
            self._pg_driver = AsyncpgDriver(connection)
        return self._pg_driver
