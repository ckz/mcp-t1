CREATE TABLE IF NOT EXISTS suggested_prompts (
    id SERIAL PRIMARY KEY,
    user_id UUID NOT NULL,
    suggestion_date DATE NOT NULL DEFAULT CURRENT_DATE,
    prompts TEXT[] NOT NULL,
    is_global BOOLEAN NOT NULL DEFAULT FALSE,
    created_at TIMESTAMP
    WITH
        TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Comments for individual columns
COMMENT ON COLUMN suggested_prompts.is_global IS
'When true, indicates these prompts are shared across all users';
COMMENT ON COLUMN suggested_prompts.user_id IS
'User ID or system UUID (00000000-0000-0000-0000-000000000000) for global prompts';
