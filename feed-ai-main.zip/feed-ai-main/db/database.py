import os
from typing import AsyncGenerator

from sqlalchemy.ext.asyncio import (
    AsyncEngine,
    AsyncSession,
    async_sessionmaker,
    create_async_engine,
)

# Database URL
DATABASE_URL = os.environ["DATABASE_URL"]

# Create engine
engine: AsyncEngine = create_async_engine(
    DATABASE_URL,
    echo=False,
    # For WebSockets, we need more connections but with shorter checkout times
    pool_size=12,
    max_overflow=10,
    pool_timeout=30,  # More aggressive recycling for WebSocket environments
    pool_recycle=300,  # More aggressive recycling for WebSocket environments
    pool_pre_ping=True,  # Critical for detecting stale connections
)

# Create async session maker
async_session_maker: async_sessionmaker[AsyncSession] = async_sessionmaker(
    bind=engine,
    class_=AsyncSession,
    expire_on_commit=False,
)


# Dependency to get async session
async def get_async_session() -> AsyncGenerator[AsyncSession, None]:
    async with async_session_maker() as session:
        try:
            yield session
            await session.commit()
        except Exception:
            await session.rollback()
            raise
        finally:
            await session.close()
