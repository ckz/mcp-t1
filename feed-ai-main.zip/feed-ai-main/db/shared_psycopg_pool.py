import os
from typing import Optional

from psycopg_pool import AsyncConnectionPool

DATABASE_URL = os.environ["CHECKPOINTER_DATABASE_URL"]


class SharedPsycopgConnectionPool:
    def __init__(self, database_url: str):
        self._pool: Optional[AsyncConnectionPool] = None
        self.database_url = database_url

    async def get_pool(self) -> AsyncConnectionPool:
        if not self._pool or self._pool.closed:
            self._pool = AsyncConnectionPool(
                conninfo=self.database_url,
                max_size=10,  # Increase size to accommodate both services
                min_size=1,
                kwargs={"autocommit": True, "prepare_threshold": 0},
                open=False,
            )
            await self._pool.open()
        return self._pool

    async def close(self):
        if self._pool and not self._pool.closed:
            await self._pool.close()
            self._pool = None


# Global shared pool instance
global_psycopg_pool = SharedPsycopgConnectionPool(database_url=DATABASE_URL)
