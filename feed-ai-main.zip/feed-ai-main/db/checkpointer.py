from contextlib import asynccontextmanager
from typing import AsyncGenerator

from langgraph.checkpoint.postgres.aio import AsyncPostgresSaver

from db.shared_psycopg_pool import global_psycopg_pool


class Checkpointer:
    @asynccontextmanager
    async def get(self) -> AsyncGenerator[AsyncPostgresSaver, None]:
        pool = await global_psycopg_pool.get_pool()
        try:
            checkpointer = AsyncPostgresSaver(conn=pool)  # type: ignore
            yield checkpointer
        finally:
            # Don't close the pool here - it's managed by the shared pool
            pass

    async def close(self):
        # Delegate closing to the shared pool manager
        await global_psycopg_pool.close()


# Global instance
global_checkpointer = Checkpointer()
