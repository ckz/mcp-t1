from enum import Enum
import os
from qdrant_client import QdrantClient
from qdrant_client.models import Distance, VectorParams, PayloadSchemaType
from utils.logging_config import logger

class QdrantCollection(str, Enum):
    # DEPRECATED: Use SLACK_API_MESSAGES_V2 instead
    SLACK_API_MESSAGES = "slack_api_messages"
    SLACK_API_MESSAGES_V2 = "slack_api_messages_v2"
    HUBSPOT_TICKETS = "hubspot_tickets"
    MMP_API_PULLS = "mmp_api_pulls"
    GONG_CALL_TRANSCRIPTS = "gong_call_transcripts"
    # DEPRECATED: Use EMAIL_DOCUMENTS instead
    EMAILS_MARKDOWN = "emails_markdown"
    EMAIL_DOCUMENTS = "email_documents"
    GITHUB_ISSUES = "github_issues"

VECTOR_SIZE_1536 = [
    QdrantCollection.SLACK_API_MESSAGES,
    QdrantCollection.HUBSPOT_TICKETS,
    QdrantCollection.MMP_API_PULLS
]

VECTOR_SIZE_1024 = [
    QdrantCollection.GONG_CALL_TRANSCRIPTS,
    QdrantCollection.EMAILS_MARKDOWN,
    QdrantCollection.EMAIL_DOCUMENTS,
    QdrantCollection.GITHUB_ISSUES,
    QdrantCollection.SLACK_API_MESSAGES_V2
]

def create_qdrant_client():
    return QdrantClient(url=os.environ["QDRANT_URL"], api_key=os.environ["QDRANT_API_KEY"])

def setup_qdrant_collection():
    qdrant_client = create_qdrant_client()
    defined_collection_names = [collection.value for collection in QdrantCollection]
    existing_collections = [
        QdrantCollection(collection.name)
        for collection in qdrant_client.get_collections().collections
        if collection.name in defined_collection_names
    ]

    for collection in VECTOR_SIZE_1536:
        if collection not in existing_collections:
            qdrant_client.create_collection(
                collection_name=collection.value,
                vectors_config=VectorParams(size=1536, distance=Distance.COSINE)
            )
            logger.info(f"Created collection {collection.value}")

    for collection in VECTOR_SIZE_1024:
        if collection not in existing_collections:
            qdrant_client.create_collection(
                collection_name=collection.value,
                vectors_config=VectorParams(size=1024, distance=Distance.COSINE)
            )
            logger.info(f"Created collection {collection.value}")

    __create_collection_payload_index(qdrant_client)

def __create_collection_payload_index(client: QdrantClient):
    # slack_api_messages
    if not __check_if_collection_payload_index_exists(client, QdrantCollection.SLACK_API_MESSAGES_V2, "metadata.message_ts"):
        client.create_payload_index(
            collection_name=QdrantCollection.SLACK_API_MESSAGES_V2.value,
            field_name="metadata.message_ts",
            field_schema=PayloadSchemaType.FLOAT
        )
        logger.info(f"Created payload index for metadata.message_ts in {QdrantCollection.SLACK_API_MESSAGES_V2.value}")
    if not __check_if_collection_payload_index_exists(client, QdrantCollection.SLACK_API_MESSAGES_V2, "metadata.timestamp"):
        client.create_payload_index(
            collection_name=QdrantCollection.SLACK_API_MESSAGES_V2.value,
            field_name="metadata.timestamp",
            field_schema=PayloadSchemaType.DATETIME
        )
        logger.info(f"Created payload index for metadata.timestamp in {QdrantCollection.SLACK_API_MESSAGES_V2.value}")

def __check_if_collection_payload_index_exists(client: QdrantClient, collection: QdrantCollection, field_name: str):
    collection_info = client.get_collection(collection_name=collection.value)
    logger.info(f"Collection Payload Schema: {collection_info.payload_schema}")

    # Check if an index exists for the payload field
    return collection_info.payload_schema and field_name in collection_info.payload_schema
