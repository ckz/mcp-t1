import os
from contextlib import asynccontextmanager
from typing import AsyncGenerator

from langgraph.store.postgres import AsyncPostgresStore

from db.shared_psycopg_pool import global_psycopg_pool
from services.bedrock_service import BedrockAIService

DATABASE_URL = os.environ["CHECKPOINTER_DATABASE_URL"]


class MemoryStore:
    @asynccontextmanager
    async def get(self) -> AsyncGenerator[AsyncPostgresStore, None]:
        pool = await global_psycopg_pool.get_pool()
        try:
            store = AsyncPostgresStore(
                pool,  # type: ignore
                index={
                    "dims": 1024,
                    "embed": BedrockAIService().embeddings_v2(),
                    "fields": [
                        "content"
                    ],  # specify which fields to embed. Default is the whole serialized value
                },
            )
            yield store
        finally:
            # Don't close the pool here - it's managed by the shared pool
            pass

    async def close(self):
        # Delegate closing to the shared pool manager
        await global_psycopg_pool.close()


# Global instance
global_memory_store = MemoryStore()
