from datetime import datetime, timezone
from sqlalchemy import Integer, DateTime, String, JSON
from sqlalchemy.orm import Mapped, mapped_column
from sqlalchemy.future import select

from enum import Enum
from typing import Any, Dict, Optional

from .base import Base

class SourceType(str, Enum):
    SLACK = "slack"
    HUBSPOT = "hubspot"
    MMP_API_PULLS = "mmp_api_pulls"
    GONG = "gong"
    EMAIL = "email"

class SyncStatus(Base):
    __tablename__ = 'sync_status'

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    last_updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=datetime.now(timezone.utc))
    source: Mapped[SourceType] = mapped_column(String)
    payload: Mapped[Dict[str, Any]] = mapped_column(JSON)

class SyncStatusRepo:
    def __init__(self, session):
        self.session = session

    async def upsert(self, sync_status: SyncStatus):
        await self.session.merge(sync_status)

    async def get_all(self) -> list[SyncStatus]:
        result = await self.session.execute(select(SyncStatus))
        return list(result.scalars().all())

    async def get_by_source(self, source: SourceType) -> Optional[SyncStatus]:
        result = await self.session.execute(select(SyncStatus).where(SyncStatus.source == source))
        return result.scalar()
