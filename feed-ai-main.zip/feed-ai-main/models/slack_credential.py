from sqlalchemy import UUID, String, Text, DateTime
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select
from sqlalchemy.orm import Mapped, mapped_column

from typing import Optional
from .base import Base
from datetime import datetime, timezone

class SlackCredential(Base):
    __tablename__ = 'slack_credentials'

    id: Mapped[UUID] = mapped_column(UUID, primary_key=True)
    app_id: Mapped[str] = mapped_column(String)
    authed_user_id: Mapped[str] = mapped_column(String)
    scope: Mapped[str] = mapped_column(Text)
    token_type: Mapped[str] = mapped_column(String)
    access_token: Mapped[str] = mapped_column(String)
    bot_user_id: Mapped[str] = mapped_column(String)
    team_id: Mapped[str] = mapped_column(String)
    team_name: Mapped[str] = mapped_column(String)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=datetime.now(timezone.utc))
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=datetime.now(timezone.utc), onupdate=datetime.now(timezone.utc))

class SlackCredentialRepo:
    def __init__(self, session: AsyncSession):
        self.session = session

    async def create(self, slack_credential: SlackCredential):
        self.session.add(slack_credential)

    async def update(self, slack_credential: SlackCredential):
        await self.session.merge(slack_credential)

    async def get_all(self) -> list[SlackCredential]:
        result = await self.session.execute(select(SlackCredential))
        return list(result.scalars().all())

    async def find_by_team_id_and_app_id(self, team_id: str, app_id: str) -> Optional[SlackCredential]:
        result = await self.session.execute(select(SlackCredential).where(SlackCredential.team_id == team_id).where(SlackCredential.app_id == app_id))
        return result.scalar()
