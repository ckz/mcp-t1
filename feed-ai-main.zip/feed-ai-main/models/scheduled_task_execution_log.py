from datetime import datetime
from enum import Enum
from sqlalchemy import Integer, DateTime, String
from sqlalchemy.orm import Mapped, mapped_column
from .base import Base

class ScheduledTaskExecutionStatus(str, Enum):
    PENDING = 'pending'
    RUNNING = 'running'
    SUCCESS = 'success'
    FAILURE = 'failure'

class ScheduledTaskExecutionLog(Base):
    __tablename__ = 'scheduled_task_execution_logs'

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    task_id: Mapped[int] = mapped_column(Integer, nullable=False)
    started_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    finished_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=True)
    status: Mapped[ScheduledTaskExecutionStatus] = mapped_column(String(50), nullable=False)
    output: Mapped[str] = mapped_column(String, nullable=True)
    error_message: Mapped[str] = mapped_column(String, nullable=True)


class ScheduledTaskExecutionLogRepo:
    def __init__(self, session):
        self.session = session

    async def upsert(self, log: ScheduledTaskExecutionLog) -> ScheduledTaskExecutionLog:
        merged_log = await self.session.merge(log)
        await self.session.flush()
        return merged_log
