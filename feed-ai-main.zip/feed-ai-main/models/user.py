import uuid
from datetime import datetime
from typing import Optional
from zoneinfo import ZoneInfo

from aiocache import Cache
from chainlit import PersistedUser
from sqlalchemy import JSON, UUID, String, cast, text
from sqlalchemy.future import select
from sqlalchemy.orm import Mapped, mapped_column

from services.slack_assistant_service import (
    SlackAssistantBetaService,
    SlackAssistantService,
)
from utils.app_stage import AppStage, get_app_stage
from utils.slack import get_user_email, is_slack_user

from .base import Base


class User(Base):
    __tablename__ = "users"

    id: Mapped[uuid.UUID] = mapped_column(UUID, primary_key=True)
    identifier: Mapped[str] = mapped_column(String, unique=True, nullable=False)
    user_metadata: Mapped[dict] = mapped_column(JSON, nullable=False, name="metadata")
    created_at: Mapped[str] = mapped_column(String, nullable=False, name="createdAt")

    @classmethod
    def from_persisted_user(cls, persisted_user: PersistedUser) -> "User":
        """
        Create a User instance from a PersistedUser object.
        """
        return cls(
            id=persisted_user.id,
            identifier=persisted_user.identifier,
            user_metadata=persisted_user.metadata,
            created_at=persisted_user.createdAt,
        )

    def user_email(self) -> str:
        return get_user_email(self.identifier)

    def get_real_name(self) -> Optional[str]:
        metadata = self.user_metadata
        if real_name := metadata.get("real_name"):
            return real_name
        return None

    # Initialize cache
    _timezone_cache = Cache(Cache.MEMORY)

    async def _get_slack_tz_info_uncached(self, email: str) -> str:
        if not is_slack_user(self.identifier):
            return "UTC"

        slack_service = (
            SlackAssistantService()
            if get_app_stage() == AppStage.STABLE
            else SlackAssistantBetaService()
        )
        slack_user_info = await slack_service.get_user_info_by_email(email)
        if not slack_user_info:
            return "UTC"
        return slack_user_info["tz"]

    async def get_slack_tz_info(self) -> str:
        email = self.user_metadata.get("email")
        if not email:
            return "UTC"

        # Create cache key
        cache_key = f"timezone:{self.identifier}:{email}"

        # Try to get from cache
        cached_tz = await self._timezone_cache.get(cache_key)
        if cached_tz is not None:
            return cached_tz

        # If not in cache, fetch and store
        tz = await self._get_slack_tz_info_uncached(email)
        await self._timezone_cache.set(cache_key, tz, ttl=3600)  # Cache for 1 hour
        return tz

    async def clear_timezone_cache(self):
        """Clear the timezone cache for this user"""
        email = self.user_metadata.get("email")
        if email:
            cache_key = f"timezone:{self.identifier}:{email}"
            await self._timezone_cache.delete(cache_key)

    async def user_local_time_now(self) -> datetime:
        timezone = await self.get_slack_tz_info()
        tz = ZoneInfo(timezone)
        return datetime.now(tz)

    async def user_info_for_llm(self) -> str:
        user_timezone = await self.get_slack_tz_info()
        user_email = self.user_email()
        current_time = await self.user_local_time_now()
        user_info = f"User Email: {user_email}\nUser Timezone: {user_timezone}\nUser Local Time: {current_time.isoformat()}"
        metadata = self.user_metadata
        if not metadata:
            return user_info

        if title := metadata.get("title"):
            user_info += f"\nUser Title: {title}"

        if real_name := metadata.get("real_name"):
            user_info += f"\nUser Real Name: {real_name}"
        if display_name := metadata.get("display_name"):
            user_info += f"\nUser Slack Display Name: {display_name}"
        return user_info


class UserRepo:
    def __init__(self, session):
        self.session = session

    async def get_user_by_id(self, user_id: str) -> Optional[User]:
        result = await self.session.execute(
            select(User).filter(User.id == cast(user_id, UUID))
        )
        return result.scalar()

    async def get_user_by_identifier(self, identifier: str) -> Optional[User]:
        result = await self.session.execute(
            select(User).filter(User.identifier == identifier)
        )
        return result.scalar()

    async def get_all_slack_user_ids(self) -> list[str]:
        sql = text("""
            select id from users where identifier like 'slack_%';
        """)
        result = await self.session.execute(sql)
        return [str(row[0]) for row in result.fetchall()]

    async def get_all_users_questions(
        self, start_time: datetime, end_time: datetime, limit: int = 200
    ) -> list[dict]:
        sql = text("""
        SELECT
            u.identifier as user,
            t.name as thread_name,
            t.id as thread_id,
            s.input as user_message,
            s."createdAt" as created_at
        FROM threads AS t
        LEFT JOIN users AS u ON t."userId" = u.id
        LEFT JOIN steps AS s ON t.id = s."threadId" and s."type" = 'run' and s."name" = 'on_message'
        WHERE u.identifier ilike 'slack_%'
            AND s."createdAt" >= :start_time
            AND s."createdAt" <= :end_time
        ORDER BY s."createdAt" ASC
        LIMIT :limit
        """)

        result = await self.session.execute(
            sql,
            {
                "start_time": start_time.isoformat(),
                "end_time": end_time.isoformat(),
                "limit": limit,
            },
        )

        # Convert the result to a list of dictionaries
        questions = []
        for row in result:
            email = get_user_email(row.user)

            questions.append(
                {
                    "email": email,
                    "thread_id": row.thread_id,
                    "thread_name": row.thread_name,
                    "user_message": row.user_message,
                    "created_at": row.created_at,
                }
            )

        return questions

    async def get_users_questions(
        self, start_time: datetime, end_time: datetime, identifier: str
    ) -> list[dict]:
        """
        Get all questions from a specific user within a specified time range.

        Args:
            start_time: The earliest time to include messages from
            end_time: The latest time to include messages until
            identifier: The user identifier (usually in the format 'slack_email@domain.com')

        Returns:
            A list of dictionaries containing user questions and related information
        """
        sql = text("""
        SELECT
            u.identifier as user,
            t.name as thread_name,
            t.id as thread_id,
            s.input as user_message,
            s."createdAt" as created_at
        FROM threads AS t
        LEFT JOIN users AS u ON t."userId" = u.id
        LEFT JOIN steps AS s ON t.id = s."threadId" and s."type" = 'run' and s."name" = 'on_message'
        WHERE u.identifier = :identifier
            AND s."createdAt" >= :start_time
            AND s."createdAt" <= :end_time
        ORDER BY s."createdAt" ASC
        LIMIT 100
        """)

        result = await self.session.execute(
            sql,
            {
                "identifier": identifier,
                "start_time": start_time.isoformat(),
                "end_time": end_time.isoformat(),
            },
        )

        # Convert the result to a list of dictionaries
        questions = []
        for row in result:
            email = get_user_email(row.user)

            questions.append(
                {
                    "email": email,
                    "thread_id": row.thread_id,
                    "thread_name": row.thread_name,
                    "user_message": row.user_message,
                    "created_at": row.created_at,
                }
            )

        return questions

    # async def update_timezone(self, user: User, timezone: str):
    #     metadata = user.user_metadata or {}
    #     metadata['timezone'] = timezone
    #     sql = text("""
    #     UPDATE users
    #     SET metadata = :metadata
    #     WHERE id = :id
    #     """)
    #     await self.session.execute(sql, {'metadata': json.dumps(metadata), 'id': user.id})
    #     await self.session.commit()
