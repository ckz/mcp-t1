import uuid
from datetime import date, datetime, timedelta, timezone
from typing import List, Optional

from sqlalchemy import ARRAY, UUID, Boolean, Date, DateTime, Integer, String
from sqlalchemy.future import select
from sqlalchemy.orm import Mapped, mapped_column

from .base import Base


class SuggestedPrompt(Base):
    __tablename__ = "suggested_prompts"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    user_id: Mapped[uuid.UUID] = mapped_column(UUID, nullable=False)
    prompts: Mapped[List[str]] = mapped_column(ARRAY(String), nullable=False)
    suggestion_date: Mapped[date] = mapped_column(
        Date, nullable=False, default=lambda: datetime.now(timezone.utc).date()
    )
    is_global: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        default=lambda: datetime.now(timezone.utc),
    )


class SuggestedPromptRepo:
    def __init__(self, session):
        self.session = session

    async def get_suggested_prompt_by_id(self, id: int) -> Optional[SuggestedPrompt]:
        result = await self.session.execute(
            select(SuggestedPrompt).filter(SuggestedPrompt.id == id)
        )
        return result.scalar()

    async def get_prompts_for_user(
        self, user_id: uuid.UUID
    ) -> Optional[SuggestedPrompt]:
        """
        Get suggested prompts for a specific user
        """
        result = await self.session.execute(
            select(SuggestedPrompt)
            .filter(
                SuggestedPrompt.user_id == user_id,
                SuggestedPrompt.is_global == False,
            )
            .order_by(SuggestedPrompt.created_at.desc())
            .limit(1)
        )
        return result.scalar()

    async def get_global_prompts(self) -> Optional[SuggestedPrompt]:
        """
        Get global suggested prompts
        """
        result = await self.session.execute(
            select(SuggestedPrompt)
            .filter(
                SuggestedPrompt.is_global == True,
            )
            .order_by(SuggestedPrompt.created_at.desc())
            .limit(1)
        )
        return result.scalar()

    async def create_suggested_prompts(
        self,
        user_id: uuid.UUID,
        prompts: List[str],
        suggestion_date: date,
        is_global: bool = False,
    ) -> SuggestedPrompt:
        """
        Create new suggested prompts for a user or as global prompts
        """
        suggested_prompt = SuggestedPrompt(
            user_id=user_id,
            prompts=prompts,
            suggestion_date=suggestion_date,
            is_global=is_global,
        )

        self.session.add(suggested_prompt)
        await self.session.commit()
        return suggested_prompt

    async def create_global_prompts(
        self, prompts: List[str], suggestion_date: date
    ) -> SuggestedPrompt:
        """
        Create new global suggested prompts shared across all users
        Uses a special system UUID for the user_id
        """
        # Using a special UUID for system/global prompts
        system_uuid = uuid.UUID("00000000-0000-0000-0000-000000000000")

        return await self.create_suggested_prompts(
            user_id=system_uuid,
            prompts=prompts,
            suggestion_date=suggestion_date,
            is_global=True,
        )

    async def delete_old_prompts(self, days_to_keep: int = 30) -> int:
        """
        Delete prompts older than the specified number of days
        Returns the number of rows deleted
        """
        cutoff_date = datetime.now(timezone.utc).date() - timedelta(days=days_to_keep)

        result = await self.session.execute(
            select(SuggestedPrompt).filter(
                SuggestedPrompt.suggestion_date < cutoff_date
            )
        )
        to_delete = result.scalars().all()

        for prompt in to_delete:
            await self.session.delete(prompt)

        await self.session.commit()
        return len(to_delete)
