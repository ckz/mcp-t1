from enum import Enum
from sqlalchemy import JSON, Integer, String, Boolean, or_, and_, cast, UUID
from sqlalchemy.orm import Mapped, mapped_column
from sqlalchemy.future import select

from .base import Base

class StepType(str, Enum):
    ASSISTANT_MESSAGE = "assistant_message"
    USER_MESSAGE = "user_message"
    RUN = "run"
    UNDEFINED = "undefined"
    TOOL = "tool"
    LLM = "llm"

class Step(Base):
    __tablename__ = 'steps'

    id: Mapped[str] = mapped_column(String, primary_key=True)
    name: Mapped[str] = mapped_column(String, nullable=False)
    step_type: Mapped[StepType] = mapped_column(String, nullable=False, name="type")
    thread_id: Mapped[str] = mapped_column(String, nullable=False, name="threadId")
    parent_id: Mapped[str] = mapped_column(String, name="parentId")
    disable_feedback: Mapped[bool] = mapped_column(Boolean, nullable=False, name="disableFeedback", default=False)
    streaming: Mapped[bool] = mapped_column(Boolean, nullable=False)
    wait_for_answer: Mapped[bool] = mapped_column(Boolean, name="waitForAnswer")
    is_error: Mapped[bool] = mapped_column(Boolean, nullable=False, name="isError")
    step_metadata: Mapped[dict] = mapped_column(JSON, name="metadata")
    tags: Mapped[list] = mapped_column(String, nullable=False)
    input: Mapped[str] = mapped_column(String)
    output: Mapped[str] = mapped_column(String)
    created_at: Mapped[str] = mapped_column(String, nullable=False, name="createdAt")
    start: Mapped[str] = mapped_column(String)
    end: Mapped[str] = mapped_column(String)
    generation: Mapped[dict] = mapped_column(JSON)
    show_input: Mapped[str] = mapped_column(String, name="showInput")
    language: Mapped[str] = mapped_column(String)
    indent: Mapped[int] = mapped_column(Integer)

class StepRepo:
    def __init__(self, session):
        self.session = session

    async def get_steps_by_id(self, step_id: str) -> list[Step]:
        result = await self.session.execute(
            select(Step)
            .where(
                and_(
                    or_(Step.id == cast(step_id, UUID), Step.parent_id == cast(step_id, UUID)),
                    Step.step_type.in_([StepType.ASSISTANT_MESSAGE, StepType.RUN])
                )
            )
            .order_by(Step.created_at.asc())
        )
        return list(result.scalars().all())

