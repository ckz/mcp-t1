import uuid
from datetime import datetime, timezone
from typing import Optional
from zoneinfo import ZoneInfo

from croniter import croniter
from sqlalchemy import UUID, Boolean, DateTime, Integer, String, cast
from sqlalchemy.future import select
from sqlalchemy.orm import Mapped, mapped_column

from utils.app_stage import AppStage

from .base import Base


class ScheduledTask(Base):
    __tablename__ = "scheduled_tasks"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    user_id: Mapped[uuid.UUID] = mapped_column(UUID, nullable=False)
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    instructions: Mapped[str] = mapped_column(String(255), nullable=False)
    expression: Mapped[str] = mapped_column(String(255), nullable=False)
    enabled: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True)
    slack_thread_ts: Mapped[str | None] = mapped_column(String(255), nullable=True)
    next_run: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    last_run: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    disable_token: Mapped[uuid.UUID] = mapped_column(
        UUID, nullable=False, default=uuid.uuid4
    )
    app_stage: Mapped[AppStage] = mapped_column(
        String, nullable=False, default=AppStage.BETA
    )
    timezone: Mapped[str] = mapped_column(String(50), nullable=False, default="UTC")
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        default=lambda: datetime.now(timezone.utc),
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        default=lambda: datetime.now(timezone.utc),
        onupdate=lambda: datetime.now(timezone.utc),
    )

    def timezone_info(self) -> ZoneInfo:
        return ZoneInfo(self.timezone) if self.timezone else ZoneInfo("UTC")

    def get_next_run(self) -> datetime:
        user_local_time = datetime.now(self.timezone_info())
        next_run = croniter(
            expr_format=self.expression, start_time=user_local_time
        ).get_next(datetime)
        return next_run.astimezone(timezone.utc)

    def next_run_local(self) -> Optional[datetime]:
        if not self.next_run:
            return None
        return self.next_run.astimezone(self.timezone_info())


class ScheduledTaskRepo:
    def __init__(self, session):
        self.session = session

    async def get_scheduled_task_by_id(self, id: int) -> Optional[ScheduledTask]:
        result = await self.session.execute(
            select(ScheduledTask).filter(ScheduledTask.id == id)
        )
        return result.scalar()

    async def upsert(self, task: ScheduledTask) -> None:
        await self.session.merge(task)
        await self.session.commit()

    async def get_tasks_due_for_execution(self) -> list[ScheduledTask]:
        """
        Get all tasks that are due for execution (next_run <= current time)
        """
        now = datetime.now(timezone.utc)
        query = select(ScheduledTask).where(
            ScheduledTask.next_run <= now, ScheduledTask.enabled == True
        )
        result = await self.session.execute(query)
        return result.scalars().all()

    async def get_task_by_disable_token(
        self, disable_token: str
    ) -> Optional[ScheduledTask]:
        result = await self.session.execute(
            select(ScheduledTask).filter(
                ScheduledTask.disable_token == cast(disable_token, UUID)
            )
        )
        return result.scalar()

    async def disable_task(self, disable_token: str):
        task = await self.get_task_by_disable_token(disable_token)
        if task:
            task.enabled = False
            task.disable_token = uuid.uuid4()
            await self.upsert(task)
