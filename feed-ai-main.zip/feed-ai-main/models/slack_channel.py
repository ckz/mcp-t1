from typing import Optional
from sqlalchemy import UUID, String, DateTime
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select
from sqlalchemy.orm import Mapped, mapped_column

from .base import Base
from datetime import datetime, timezone


class SlackChannel(Base):
    __tablename__ = 'slack_channels'

    id: Mapped[UUID] = mapped_column(UUID, primary_key=True)
    channel_id: Mapped[str] = mapped_column(String)
    channel_name: Mapped[str] = mapped_column(String)
    slack_credential_id: Mapped[UUID] = mapped_column(UUID)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=datetime.now(timezone.utc))
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=datetime.now(timezone.utc), onupdate=datetime.now(timezone.utc))

class SlackChannelRepo:
    def __init__(self, session: AsyncSession):
        self.session = session

    async def upsert(self, slack_channels: list[SlackChannel]):
        for slack_channel in slack_channels:
            await self.session.merge(slack_channel)
        await self.session.commit()

    async def get_all(self) -> list[SlackChannel]:
        result = await self.session.execute(select(SlackChannel))
        return list(result.scalars().all())

    async def get_by_channel_ids(self, channel_ids: list[str]) -> list[SlackChannel]:
        result = await self.session.execute(select(SlackChannel).filter(SlackChannel.channel_id.in_(channel_ids)))
        return list(result.scalars().all())

    async def get_by_channel_id(self, channel_id: str) -> Optional[SlackChannel]:
        result = await self.session.execute(select(SlackChannel).filter(SlackChannel.channel_id == channel_id))
        return result.scalar()
