from datetime import date
from typing import Any

from mcp.server.fastmcp import FastMCP
from typing_extensions import Optional

import adjust.integration_configs as integration
from adjust.adjust_api_service import AdjustAPIService

mcp = FastMCP(name="Adjust Report")


@mcp.tool()
def get_adjust_all_supported_clients() -> list[dict[str, Any]]:
    """Get all supported clients for loading Adjust reports."""
    return integration.get_all_supported_clients()


@mcp.tool()
def get_adjust_metrics_params_for_client(client: integration.Client) -> list[str]:
    """Get report metrics parameters for the client."""
    return integration.get_metrics(client)


@mcp.tool()
def get_adjust_channels_params_for_client(client: integration.Client) -> list[str]:
    """Get report channels parameters for the client."""
    return integration.get_channels(client)


@mcp.tool()
def get_adjust_reports(
    client: integration.Client,
    start_date: date,
    end_date: date,
    channels: list[str] = [],
    metrics: list[str] = [],
    app_token: Optional[str] = None,
) -> str:
    """Get Adjust reports for the client."""
    credentials = integration.get_credentials(client)
    adjust_service = AdjustAPIService(credentials)
    channels = integration.get_channels(client) if not channels else channels
    metrics = integration.get_metrics(client) if not metrics else metrics
    return adjust_service.load(
        start_date=start_date.isoformat(),
        end_date=end_date.isoformat(),
        channels=channels,
        metrics=metrics,
        app_token=app_token,
    )


async def main():
    await mcp.run_stdio_async()
