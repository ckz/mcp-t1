from typing import Dict, Optional

import httpx
from httpx import Timeout


class AdjustAPIService:
    # https://dev.adjust.com/en/api/rs-api/
    BASE_URL = "https://automate.adjust.com/control-center/reports-service"

    def __init__(self, access_config: Dict[str, str]):
        self.access_token = access_config.get("access_token")
        self.account_id = access_config.get("account_id")

    def load(
        self,
        start_date: str,
        end_date: str,
        channels: list[str],
        metrics: list[str],
        app_token: Optional[str] = None,
    ) -> str:
        request_params = {
            "date_period": f"{start_date}:{end_date}",
            "dimensions": "day,store_id,app,os_name,partner_name,campaign,campaign_id_network,campaign_network",
            "metrics": ",".join(metrics),
            "attribution_type": "all",
            "attribution_source": "first",
            "utc_offset": "+00:00",
            "os_names": "ios,android",
            "channel__in": ",".join(channels),
        }

        if (
            app_token and app_token.strip()
        ):  # Check if app_token exists and is not empty
            request_params["app_token__in"] = app_token

        headers = {
            "Authorization": f"Bearer {self.access_token}",
            "x-account-id": self.account_id,
        }

        try:
            response = httpx.get(
                f"{self.BASE_URL}/csv_report",
                params=request_params,
                headers=headers,
                timeout=Timeout(120, connect=60, read=60, write=60),
            )
            # raise Exception(f"Response Status: {response.status_code}")
            response.raise_for_status()  # Raise exception for HTTP errors

            return response.content.decode("utf-8")
        except httpx.HTTPError as e:
            raise Exception(f"Failed to load report: {e}")
