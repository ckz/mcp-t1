import os
from enum import Enum
from typing import Any


class Client(str, Enum):
    textnow = "TextNow"
    scopely = "Scopely"


DEFAULT_METRICS = ["clicks", "installs", "impressions"]

# Credential Configs: https://assistant.feedmob.ai/track_party_integrations/12
CREDENTIALS = {
    Client.textnow: {
        "account_id": "5595",
        "access_token": os.environ.get("TEXTNOW_ACCESS_TOKEN", ""),
        "addtional_metrics": [
            "retained_d3_events",
            "early_mover_event_events",
            "unique_signup_events",
            "sim_purchase_events",
        ],
        "channels": [  # channels https://admin.feedmob.com/tracking_configs/352
            "Applovin",
            "茄子快传 | SHAREit",
            "Apptimus",
            "Jampp",
            "Aarki",
            "InMobi",
            "Mintegral",
            "FeedMob",
            "Glance",
            "AdAction",
            "Appnext",
            "Kaden",
            "Tapjoy",
            "Reddit Inc",
            "Scrambly",
        ],
    },
}


def get_all_supported_clients() -> list[dict[str, Any]]:
    """Get all supported clients."""
    return [
        {
            "account_id": credentials["account_id"],
            "metrics": get_metrics(client),
            "channels": credentials["channels"],
            "client": client.value,
        }
        for client, credentials in CREDENTIALS.items()
    ]


def get_credentials(client: Client) -> dict:
    """Get credentials for the client."""
    return CREDENTIALS[client]


def get_channels(client: Client) -> list[str]:
    """Get channels for the client."""
    return CREDENTIALS[client]["channels"]


def get_metrics(client: Client) -> list[str]:
    """Get metrics for the client."""
    return DEFAULT_METRICS + CREDENTIALS[client]["addtional_metrics"]
