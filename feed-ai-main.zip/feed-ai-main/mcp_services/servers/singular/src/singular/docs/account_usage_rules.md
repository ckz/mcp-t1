# Clarification of Singular Account Usage Rules

## Available Login Accounts

The most commonly used Singular login accounts are:

- **feedmobadops@gmail.com** (referred to as "Feedmobadops account")
- **vanessa+agency@feedmob.com** (referred to as "Vanessa account")

## Client-Specific Rules

### Possible Finance

- Uses the share report from the Vanessa account (vanessa+agency@feedmob.com)

### Uber

- Does not use Singular data for spend calculations
- When using the Vanessa account (vanessa+agency@feedmob.com):
  - Exclude data where source = 'FeedMob', 'Organic', or 'AdWords'
- When using the Feedmobadops account (feedmobadops@gmail.com):
  - Only extract data where source = 'FeedMob'
  - Note: This account only contains FeedMob source data

### InMarket

- Uses the Vanessa account (vanessa+agency@feedmob.com)
- Note: This client currently has no active data
