import pathlib

from mcp.server.fastmcp import FastMCP

mcp = FastMCP(name="Singular")


@mcp.resource(uri="resource://singular-account-usage-rules", mime_type="text/markdown")
def singular_account_usage_rules() -> str:
    """Return the account usage rules for Singular."""
    current_dir = pathlib.Path(__file__).parent
    docs_dir = current_dir / "docs"
    rules_path = docs_dir / "account_usage_rules.md"

    # Read and return the content of the file
    with open(rules_path, "r") as file:
        return file.read()


@mcp.tool()
def get_singular_account_usage_rules() -> str:
    """Get the account usage rules for Singular."""
    return singular_account_usage_rules()


async def main():
    await mcp.run_stdio_async()
