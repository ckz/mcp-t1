# Install MCP servers

- Google Docs: [FeedAI - Install MCP Servers with Docker](https://docs.google.com/document/d/1TG4TxkAP0hkzshkxpZj0CRa91AOxvMzl0Kl9ct5q1RM/edit?usp=sharing)
- [The Model Context Protocol: Simplifying Building AI apps with Anthropic Claude Desktop and Docker](https://www.docker.com/blog/the-model-context-protocol-simplifying-building-ai-apps-with-anthropic-claude-desktop-and-docker/)

## Prerequisites

### Install Docker for MacOS/Linux

- [Docker Desktop](https://www.docker.com/products/docker-desktop) or [OrbStack](https://orbstack.dev/download)

### Install Docker for Windows

- Enable [Windows Subsystem for Linux (WSL)](https://docs.microsoft.com/en-us/windows/wsl/install)
- Turn on [Docker Desktop WSL 2](https://docs.docker.com/desktop/features/wsl/#turn-on-docker-desktop-wsl-2)
- Download latest version of [Docker Desktop](https://desktop.docker.com/win/main/amd64/Docker%20Desktop%20Installer.exe)

### Creating a GitHub Personal Access Token

If you don't have a personal access token:

1. Go to GitHub.com and log in
2. Click your profile picture in the top right → Settings
3. Scroll down to "Developer settings" in the left sidebar
4. Select "Personal access tokens" → "Tokens (classic)"
5. Click "Generate new token"
6. Give it a name and select the necessary scopes:
   - At minimum, you need `read:packages` scope
7. Click "Generate token"
8. Copy the token (you won't be able to see it again)

Use this token as your password when running the `docker login` command.

## Login to GitHub Container Registry

> You must have a GitHub account and be a member of the `feed-mob` organization to access the `feed-ai` repository.

1. Make sure Docker Desktop is installed and running on your system
2. Open a terminal or command prompt
3. Run the login command, replacing the username with your GitHub username:

   ```bash
   docker login ghcr.io --username your_github_username
   ```

4. When prompted, enter your GitHub personal access token (PAT) as the password

- Note: GitHub doesn't allow using your regular account password for container registry authentication

## Install

### Singular

```json
{
  "mcpServers": {
    "singular": {
      "command": "docker",
      "args": [
        "run",
        "-i",
        "--rm",
        "--init",
        "ghcr.io/feed-mob/singular:latest"
      ]
    }
  }
}
```

### Inmobi

```json
{
  "mcpServers": {
    "inmobi": {
      "command": "docker",
      "args": [
        "run",
        "-i",
        "--rm",
        "--init",
        "-e",
        "INMOBI_CLIENT_ID=xxx",
        "-e",
        "INMOBI_CLIENT_SECRET=xxx",
        "ghcr.io/feed-mob/inmobi:latest"
      ]
    }
  }
}
```

### Jampp

```json
{
  "mcpServers": {
    "jampp": {
      "command": "docker",
      "args": [
        "run",
        "-i",
        "--rm",
        "--init",
        "-e",
        "TEXTNOW_API_CLIENT_SECRET=xxx",
        "ghcr.io/feed-mob/jampp:latest"
      ]
    }
  }
}
```

### Adjust

```json
{
  "mcpServers": {
    "adjust": {
      "command": "docker",
      "args": [
        "run",
        "-i",
        "--rm",
        "--init",
        "-e",
        "TEXTNOW_ACCESS_TOKEN=xxx",
        "ghcr.io/feed-mob/adjust:latest"
      ]
    }
  }
}
```

### Debugging

Since MCP servers run over stdio, debugging can be challenging. For the best debugging
experience, we strongly recommend using the [MCP Inspector](https://github.com/modelcontextprotocol/inspector).

You can launch the MCP Inspector via [`bun`](https://bun.sh/docs/cli/install) with this command:

```bash
bunx @modelcontextprotocol/inspector docker run -i ghcr.io/feed-mob/xxx
```

Upon launching, the Inspector will display a URL that you can access in your browser to begin debugging.
