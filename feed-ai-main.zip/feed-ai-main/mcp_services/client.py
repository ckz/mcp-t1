import os
from typing import Optional

from fastapi import FastAPI
from langchain_mcp_adapters.client import MultiServerMCPClient
from mcp.client.stdio import get_default_environment

from utils.feature_flag import FeatureFlag

_app: Optional[FastAPI] = None


def initialize_app_reference(app: FastAPI):
    """
    Initialize the FastAPI app reference for MCP tools.
    """
    global _app
    _app = app


def get_mcp_tools():
    """
    Get MCP tools for the application.
    """
    if _app is None:
        raise ValueError("FastAPI App reference not initialized")
    return _app.state.mcp_tools


def create_mcp_client():
    """
    Create an MCP client for the application.
    """

    default_env = get_default_environment()
    current_dir = os.path.abspath(os.path.dirname(__file__))
    flux_schnell_command_path = os.path.join(
        current_dir, "servers", "flux-schnell-mcp", "build", "index.js"
    )

    mcp_configs = {
        "flux-schnell": {
            "command": "bun",
            "args": ["run", flux_schnell_command_path],
            "transport": "stdio",
            "env": {
                **default_env,
                "REPLICATE_API_TOKEN": os.environ.get("REPLICATE_API_TOKEN", ""),
            },
        },
    }

    feature_flag = FeatureFlag()
    if feature_flag.is_enabled("sequential-thinking", "all"):
        mcp_configs["sequential-thinking"] = {
            "command": "bun",
            "args": ["x", "@modelcontextprotocol/server-sequential-thinking"],
            "transport": "stdio",
        }

    if feature_flag.is_enabled("singular_mmp_report", "all"):
        mcp_configs["singular_mmp_report"] = {
            "command": "uv",
            "args": [
                "--directory",
                os.path.join(current_dir, "servers", "singular"),
                "run",
                "singular",
            ],
            "transport": "stdio",
        }

    if feature_flag.is_enabled("adjust_mmp_report", "all"):
        mcp_configs["adjust_mmp_report"] = {
            "command": "uv",
            "args": [
                "--directory",
                os.path.join(current_dir, "servers", "adjust"),
                "run",
                "adjust",
            ],
            "env": {
                **default_env,
                "TEXTNOW_ACCESS_TOKEN": os.environ.get(
                    "ADJUST_TEXTNOW_ACCESS_TOKEN", ""
                ),
            },
            "transport": "stdio",
        }

    if feature_flag.is_enabled("jampp_partner_report", "all"):
        mcp_configs["jampp_partner_report"] = {
            "command": "uv",
            "args": [
                "--directory",
                os.path.join(current_dir, "servers", "jampp"),
                "run",
                "jampp",
            ],
            "env": {
                **default_env,
                "TEXTNOW_API_CLIENT_SECRET": os.environ.get(
                    "JAMPP_TEXTNOW_CLIENT_SECRET", ""
                ),
            },
            "transport": "stdio",
        }

    if feature_flag.is_enabled("inmobi_partner_report", "all"):
        mcp_configs["inmobi_partner_report"] = {
            "command": "uv",
            "args": [
                "--directory",
                os.path.join(current_dir, "servers", "inmobi"),
                "run",
                "inmobi",
            ],
            "env": {
                **default_env,
                "INMOBI_CLIENT_ID": os.environ.get("INMOBI_API_CLIENT_ID", ""),
                "INMOBI_CLIENT_SECRET": os.environ.get("INMOBI_API_CLIENT_SECRET", ""),
            },
            "transport": "stdio",
        }

    return MultiServerMCPClient(mcp_configs)  # type: ignore
