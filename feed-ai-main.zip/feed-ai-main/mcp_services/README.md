## MCP (Model Context Protocol)

- Using Inspector to debug MCP Servers

```shell

bun x @modelcontextprotocol/inspector

```
