import sys
import os

# Add the parent directory to the system path
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '../')))


import asyncio
import chainlit as cl
from utils.logging_config import logger
from chainlit.auth import authenticate_user
from chainlit.auth import create_jwt

async def main():
    access_token = create_jwt(cl.User(identifier="richard+copilot@feedmob.com", metadata={"client_type": "copilot"}))
    logger.info(access_token)
    logger.info(await authenticate_user(access_token))

if __name__ == "__main__":
    try:
        asyncio.run(main())
    except (KeyboardInterrupt, SystemExit):
        pass
