import base64
import io
import mimetypes
import os
import sys
from pathlib import Path
from typing import Dict, List, Optional

from mcp import ClientSession

import boto3
import chainlit as cl
import chainlit.data as cl_data
import pandas as pd
import sentry_sdk as sentry
from db.chainlit_data_layer import SQLAlchemyDataLayer
from chainlit.data.storage_clients.s3 import S3StorageClient
from chainlit.input_widget import Select, Slider
from chainlit.types import ThreadDict
from langchain_core.language_models import BaseChatModel
from langchain_core.messages import HumanMessage
from langchain_experimental.agents import create_pandas_dataframe_agent
from langgraph.checkpoint.postgres.aio import AsyncPostgresSaver
from langgraph.store.postgres import AsyncPostgresStore

# Add the parent directory to the system path
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "../")))

from agents.analyze_slack_bot_agent import create_analyze_slack_bot_agent
from agents.chat import create_chat_bot_agent
from agents.db_query import create_db_query_agent
from agents.export_slack_message import create_export_slack_messages_agent
from agents.feed_ai_thinking import create_feed_ai_thinking_agent
from agents.feedmob import create_feedmob_agent
from agents.feedmob_v2 import create_feedmob_agent as create_feedmob_agent_v2
from agents.github_issues_agent import create_github_issues_agent
from agents.hubspot import create_hubspot_ticket_agent
from agents.pgqueuer_agent import create_pgqueuer_agent
from agents.slack import create_slack_messages_agent
from agents.store_user_memory import create_store_user_memory_agent
from db.database import async_session_maker as db_sessionmaker
from db.checkpointer import global_checkpointer
from db.memory_store import global_memory_store
from services.bedrock_service import (
    BedrockAIService,
    BedrockModel,
    BedrockRuntimeService,
)
from utils.logging_config import logger

DEFAULT_TEMPTERATURE = 0.3
DEFAULT_MAX_TOKEN_SIZE = 4096
AWS_REGION_NAME = os.environ["AWS_REGION_NAME"]
PROVIDER = ""

storage_client = S3StorageClient(bucket=os.environ["S3_BUCKET"])
cl_data._data_layer = SQLAlchemyDataLayer(
    async_session=db_sessionmaker,
    storage_provider=storage_client,
    user_thread_limit=100,
    show_logger=True,
)


@cl.on_chat_start
async def main():
    current_user = __current_user()
    if current_user is not None:
        logger.info(f"Chainlit::Starting chat with user {current_user.identifier}")
        sentry.set_user({"email": current_user.identifier})
    logger.info(f"Chainlit Client Type: {cl.context.session.client_type}")
    await __setup_chat_requirements()
    if __is_copilot():
        fn = cl.CopilotFunction(name="ready", args={})
        await fn.acall()


async def __setup_chat_requirements():
    settings = await __get_chat_settings()
    await setup_runnable(settings)
    cl.user_session.set("agent", None)


@cl.on_settings_update
async def setup_runnable(settings):
    bedrock_model_id = settings["Model"]

    bedrock_client = boto3.client(
        service_name="bedrock-runtime",
        region_name=AWS_REGION_NAME,
    )
    cl.user_session.set("bedrock_client", bedrock_client)

    chat_profile = cl.user_session.get("chat_profile")
    if chat_profile is None:
        raise ValueError("Chat profile is not set.")

    temperature = settings["Temperature"] if chat_profile == "Chat" else 0
    llm = BedrockAIService().llm_converse(
        model=bedrock_model_id,
        temperature=temperature,
        max_tokens=settings["MAX_TOKEN_SIZE"],
    )

    global PROVIDER
    PROVIDER = bedrock_model_id.split(".")[0]

    cl.user_session.set("llm", llm)


@cl.on_message
async def on_message(message: cl.Message):
    if len(message.content.strip()) <= 0:
        await cl.Message(content="Please enter a valid message.").send()
        return

    llm = cl.user_session.get("llm")
    chat_profile = cl.user_session.get("chat_profile")

    if not chat_profile:
        raise ValueError("Chat profile is not set.")

    if not llm:
        raise ValueError("LLM is not set.")

    async with global_checkpointer.get() as cp, global_memory_store.get() as store:
        try:
            await __handle_message(
                llm=llm,
                message=message,
                chat_profile=chat_profile,
                checkpointer=cp,
                store=store,
            )
        except Exception as e:
            thread_id = cl.context.session.thread_id
            with sentry.new_scope() as scope:
                scope.set_extra("thread_id", thread_id)
                sentry.capture_exception(e)
            logger.error(f"Error in handling message {thread_id}: {e}")
            await cl.Message(
                content=f"An error occurred while processing your message. Please try again. If the issue persists, please contact the dev team with your thread ID: {thread_id}"
            ).send()


async def __handle_message(
    llm: BaseChatModel,
    message: cl.Message,
    chat_profile: Optional[str],
    checkpointer: AsyncPostgresSaver,
    store: AsyncPostgresStore,
):
    # file handling
    content = []
    for file in message.elements or []:
        mime_type, _ = mimetypes.guess_type(file.name)

        file_name_path = Path(file.name)
        file_name = file_name_path.stem.replace(".", "-")
        file_format = file_name_path.suffix.lstrip(".")

        with open(file.path, "rb") as f:
            file_data = f.read()

        if mime_type:
            match True:
                case _ if mime_type.startswith("image"):
                    content.append(
                        {
                            "type": "image_url",
                            "image_url": f"data:{mime_type};base64,{base64.b64encode(file_data).decode('utf-8')}",
                        }
                    )
                case _ if mime_type == "text/csv":
                    from agents.utils.agent_wrapper import LangchainAgentWrapper

                    csv_file = io.BytesIO(file_data)
                    df = pd.read_csv(csv_file, encoding="utf-8")
                    agent = create_pandas_dataframe_agent(
                        llm,
                        df,
                        verbose=False,
                        allow_dangerous_code=True,
                        agent_executor_kwargs={"handle_parsing_errors": True},
                    )
                    wrapper = LangchainAgentWrapper(agent)
                    cl.user_session.set("agent", wrapper)
                case _ if mime_type.startswith("application") or mime_type.startswith(
                    "text"
                ):
                    # FIXME: This is not supported by the model. 2024-08-18
                    content.append(
                        {
                            "document": {
                                "name": file_name,
                                "format": file_format,
                                "source": {"bytes": file_data},
                            }
                        }
                    )

    # profile handling
    if chat_profile == "Chat" and cl.user_session.get("agent") is None:
        agent = create_chat_bot_agent(llm, checkpointer)
        cl.user_session.set("agent", agent)

    if (
        chat_profile == "Analyzing FeedAI Usage"
        and cl.user_session.get("agent") is None
    ):
        agent = create_analyze_slack_bot_agent(llm=llm, checkpointer=checkpointer)
        cl.user_session.set("agent", agent)

    if (
        chat_profile == "Bedrock AI Chatbot Database"
        and cl.user_session.get("agent") is None
    ):
        agent = create_db_query_agent(
            llm=llm,
            db_url=os.environ["SQL_AGENT__BEDROCK_AI_CHATBOT_DATABASE_URL"],
            checkpointer=checkpointer,
            ignore_tables=["slack_credentials"],
        )
        cl.user_session.set("agent", agent)

    if chat_profile == "Time-off Database" and cl.user_session.get("agent") is None:
        agent = create_db_query_agent(
            llm=llm,
            db_url=os.environ["SQL_AGENT__TIME_OFF_DATABASE_URL"],
            checkpointer=checkpointer,
            suffix_system_prompt=(
                "Then following aliases are used to refer to the tables:\n"
                "- `work log`, `工作日志` for the `journals` table\n"
                "- `work summary & incident report`, `工作总结 & 事故报告` for the `reports` table"
            ),
        )
        cl.user_session.set("agent", agent)

    if chat_profile == "PgQueuer Queue Dash" and cl.user_session.get("agent") is None:
        agent = create_pgqueuer_agent(llm=llm, checkpointer=checkpointer)
        cl.user_session.set("agent", agent)

    if chat_profile == "Hubspot Ticket" and cl.user_session.get("agent") is None:
        bedrock_client = cl.user_session.get("bedrock_client")
        agent = create_hubspot_ticket_agent(
            llm=llm, bedrock_client=bedrock_client, checkpointer=checkpointer
        )
        cl.user_session.set("agent", agent)

    if chat_profile == "Slack" and cl.user_session.get("agent") is None:
        bedrock_client = cl.user_session.get("bedrock_client")
        if bedrock_client is None:
            raise ValueError("Bedrock client is not set.")
        agent = create_slack_messages_agent(
            llm=llm, bedrock_client=bedrock_client, checkpointer=checkpointer
        )
        cl.user_session.set("agent", agent)

    if chat_profile == "FeedMob AI" and cl.user_session.get("agent") is None:
        bedrock_client = cl.user_session.get("bedrock_client")
        user = __current_user()
        if user is None:
            raise ValueError("User is not set.")
        if bedrock_client is None:
            raise ValueError("Bedrock client is not set.")
        agent = await create_feedmob_agent(
            user=user,
            llm=llm,
            bedrock_client=bedrock_client,
            checkpointer=checkpointer,
            memory_store=store,
        )

        cl.user_session.set("agent", agent)

    if chat_profile == "Feed AI - Thinking" and cl.user_session.get("agent") is None:
        bedrock_client = cl.user_session.get("bedrock_client")
        user = __current_user()
        if user is None:
            raise ValueError("User is not set.")
        if bedrock_client is None:
            raise ValueError("Bedrock client is not set.")
        agent = await create_feed_ai_thinking_agent(
            user=user,
            llm=llm,
            bedrock_client=bedrock_client,
            checkpointer=checkpointer,
            memory_store=store,
        )
        cl.user_session.set("agent", agent)

    if chat_profile == "FeedMob AI V2" and cl.user_session.get("agent") is None:
        bedrock_client = cl.user_session.get("bedrock_client")
        if bedrock_client is None:
            raise ValueError("Bedrock client is not set.")
        agent = create_feedmob_agent_v2(
            llm=llm, bedrock_client=bedrock_client, checkpointer=checkpointer
        )
        cl.user_session.set("agent", agent)

    if chat_profile == "Export Slack Messages" and cl.user_session.get("agent") is None:
        bedrock_client = cl.user_session.get("bedrock_client")
        if bedrock_client is None:
            raise ValueError("Bedrock client is not set.")
        agent = create_export_slack_messages_agent(
            llm=llm, bedrock_client=bedrock_client, checkpointer=checkpointer
        )
        cl.user_session.set("agent", agent)

    if chat_profile == "User Memory Beta" and cl.user_session.get("agent") is None:
        user_id = __current_user().id
        agent = create_store_user_memory_agent(llm=llm, user_id=user_id, store=store)
        cl.user_session.set("agent", agent)

    if chat_profile == "Github Issues" and cl.user_session.get("agent") is None:
        agent = create_github_issues_agent(llm=llm, checkpointer=checkpointer)
        cl.user_session.set("agent", agent)

    # message handling
    if agent := cl.user_session.get("agent"):
        content.append({"type": "text", "text": message.content})
        await agent.ainvoke(HumanMessage(content=content))


@cl.on_chat_resume
async def on_chat_resume(thread: ThreadDict):
    chainlit_thread_id = thread.get("id")
    logger.info(rf"Chainlit::Resuming chat with thread id {chainlit_thread_id}")

    # Get the chat profile from the thread metadata
    chat_profile = thread.get("metadata", {}).get("chat_profile")  # type: ignore
    cl.user_session.set("chat_profile", chat_profile)
    logger.info(f"Resuming chat with profile: {chat_profile}")

    await __setup_chat_requirements()


@cl.on_mcp_connect  # type: ignore
async def on_mcp(connection, session: ClientSession):
    result = await session.list_tools()
    tools = [
        {
            "name": t.name,
            "description": t.description,
            "input_schema": t.inputSchema,
        }
        for t in result.tools
    ]

    mcp_tools = cl.user_session.get("mcp_tools", {}) or {}
    mcp_tools[connection.name] = tools
    cl.user_session.set("mcp_tools", mcp_tools)


@cl.oauth_callback  # type: ignore
def oauth_callback(
    provider_id: str,
    _token: str,
    raw_user_data: Dict[str, str],
    default_user: cl.User,
) -> Optional[cl.User]:
    if provider_id == "google":
        if raw_user_data["hd"] == "feedmob.com":
            return default_user
    return None


@cl.set_chat_profiles  # type: ignore
async def chat_profile(current_user: Optional[cl.User]) -> List[cl.ChatProfile]:
    profiles = [
        cl.ChatProfile(
            name="FeedMob AI",
            markdown_description="All in one AI assistant for FeedMob. Includes Hubspot Tickets, Slack, FeedMob Billing Information etc.",
            icon="/chat/avatars/FeedMob%20AI%20Assistant",
            starters=[
                cl.Starter(
                    label="Sync Status Overview",
                    message="Show me the current sync status in table format",
                    icon="/assets/images/sync.png",
                ),
                cl.Starter(
                    label="Yesterday's Slack Summary",
                    message="Show me yesterday's key Slack messages",
                    icon="/assets/images/slack.png",
                ),
                cl.Starter(
                    label="High Priority Hubspot Tickets",
                    message="Show me the high priority Hubspot tickets from the last 7 days",
                    icon="/assets/images/hubspot.png",
                ),
                cl.Starter(
                    label="Last Month's Client Goals",
                    message="Please show me the last month's client monthly goal",
                    icon="/assets/images/billing.png",
                ),
            ],
        ),
        cl.ChatProfile(
            name="Chat",
            icon="/assets/images/chat.png",
            markdown_description="Chat with the **Claude 3.7 Sonnet** model.",
        ),
    ]

    if __is_executive(user=current_user) or __is_admin(user=current_user):
        profiles.extend(
            [
                cl.ChatProfile(
                    name="Analyzing FeedAI Usage",
                    markdown_description="Analyzing FeedAI Slack Bot Usage",
                    icon="/assets/images/database.png",
                    starters=[
                        cl.Starter(
                            label="User Count",
                            message="How many slack users do we have?",
                        ),
                        cl.Starter(
                            label="Top 10 Users by Messages (Last 3 Days)",
                            message="Show me the top 10 users with the most messages in the last 3 days",
                        ),
                        cl.Starter(
                            label="Conversation Counts",
                            message="Show me the conversation (threads) counts for each user from the last 30 days, ordered by most active to least active",
                        ),
                        cl.Starter(
                            label="Historical Usage",
                            message="please compare the historical usage of slack users and visualize it",
                        ),
                    ],
                )
            ]
        )

    if __is_admin(user=current_user):
        profiles.extend(
            [
                cl.ChatProfile(
                    name="Feed AI - Thinking",
                    markdown_description="All in one AI assistant for FeedMob. Includes Hubspot Tickets, Slack, FeedMob Billing Information etc.",
                    icon="/chat/avatars/FeedMob%20AI%20Assistant",
                    starters=[
                        cl.Starter(
                            label="Sync Status Overview",
                            message="Show me the current sync status in table format",
                            icon="/assets/images/sync.png",
                        ),
                        cl.Starter(
                            label="Yesterday's Slack Summary",
                            message="Show me yesterday's key Slack messages",
                            icon="/assets/images/slack.png",
                        ),
                        cl.Starter(
                            label="High Priority Hubspot Tickets",
                            message="Show me the high priority Hubspot tickets from the last 7 days",
                            icon="/assets/images/hubspot.png",
                        ),
                        cl.Starter(
                            label="Last Month's Client Goals",
                            message="Please show me the last month's client monthly goal",
                            icon="/assets/images/billing.png",
                        ),
                    ],
                ),
                cl.ChatProfile(
                    name="Github Issues",
                    markdown_description="Query GitHub issues to answer the user's question.",
                    icon="/assets/images/github.png",
                ),
                cl.ChatProfile(
                    name="Hubspot Ticket",
                    markdown_description="Answer questions from Hubspot tickets.",
                    icon="/assets/images/hubspot.png",
                ),
                cl.ChatProfile(
                    name="Slack",
                    markdown_description="Answer questions from Slack messages.",
                    icon="/assets/images/slack.png",
                ),
                cl.ChatProfile(
                    name="Bedrock AI Chatbot Database",
                    markdown_description="Query the Bedrock AI Chatbot database.",
                    icon="/assets/images/database.png",
                    starters=[
                        cl.Starter(
                            label="User Count",
                            message="How many users do we have?",
                        ),
                        cl.Starter(
                            label="Slack Users",
                            message="Please provide a list of all users with email addresses containing the 'slack_' prefix, along with the total count.",
                        ),
                        cl.Starter(
                            label="Top 10 Users by Messages",
                            message="Show me the top 10 users with the most messages",
                        ),
                        cl.Starter(
                            label="Top 10 Users by Messages (Last 3 Days)",
                            message="Show me the top 10 users with the most messages in the last 3 days",
                        ),
                    ],
                ),
                cl.ChatProfile(
                    name="Time-off Database",
                    markdown_description="Query the Time-off database.",
                    icon="/assets/images/database.png",
                    starters=[
                        cl.Starter(
                            label="昨天的工作日志",
                            message="请总结昨天的工作日志",
                        ),
                        cl.Starter(
                            label="今天的工作日志",
                            message="请总结今天的工作日志",
                        ),
                        cl.Starter(
                            label="最近一个月的工作总结 & 事故报告",
                            message="请总结最近一个月的工作总结 & 事故报告",
                        ),
                    ],
                ),
                cl.ChatProfile(
                    name="Export Slack Messages",
                    markdown_description="Export Slack Messages and email them to the users.",
                    icon="/assets/images/export.png",
                    starters=[
                        cl.Starter(
                            label="Export Yesterday's Slack Messages",
                            message="Please export yesterday's Slack messages",
                        ),
                        cl.Starter(
                            label="Export Last 30 Days of Slack Messages",
                            message="Please export the last 30 days of Slack messages",
                        ),
                        cl.Starter(
                            label="Export Last 60 Days of Slack Messages",
                            message="Please export the last 60 days of Slack messages",
                        ),
                    ],
                ),
                cl.ChatProfile(
                    name="User Memory Beta",
                    markdown_description="User Memory Beta",
                    icon="/assets/images/test.png",
                ),
                cl.ChatProfile(
                    name="PgQueuer Queue Dash",
                    markdown_description="Query Queue Information",
                    icon="/assets/images/construction.png",
                    starters=[
                        cl.Starter(
                            label="Queue Statistics",
                            message="please show me the queue statistics",
                        ),
                    ],
                ),
            ]
        )

    if __is_super_admin(user=current_user):
        profiles.extend(
            [
                cl.ChatProfile(
                    name="FeedMob AI V2",
                    markdown_description="All in one AI assistant for FeedMob. Includes Hubspot Tickets, Slack, FeedMob Billing Information etc.",
                    icon="/chat/avatars/FeedMob%20AI%20Assistant",
                    starters=[
                        cl.Starter(
                            label="Sync Status Overview",
                            message="Show me the current sync status in table format",
                            icon="/assets/images/sync.png",
                        ),
                        cl.Starter(
                            label="Yesterday's Slack Summary",
                            message="Show me yesterday's key Slack messages",
                            icon="/assets/images/slack.png",
                        ),
                        cl.Starter(
                            label="High Priority Hubspot Tickets",
                            message="Show me the high priority Hubspot tickets from the last 7 days",
                            icon="/assets/images/hubspot.png",
                        ),
                        cl.Starter(
                            label="Last Month's Client Goals",
                            message="Please show me the last month's client monthly goal",
                            icon="/assets/images/billing.png",
                        ),
                    ],
                )
            ]
        )

    return profiles


async def __get_chat_settings():
    settings = {
        "Model": BedrockModel.PRO_MODEL_ID.value,
        "Temperature": DEFAULT_TEMPTERATURE,
        "MAX_TOKEN_SIZE": DEFAULT_MAX_TOKEN_SIZE,
    }
    if __is_admin():
        model_ids = BedrockRuntimeService().list_models()
        settings = await cl.ChatSettings(
            [
                Select(
                    id="Model",
                    label="Amazon Bedrock - Model",
                    values=model_ids,
                    initial_index=model_ids.index(BedrockModel.PRO_MODEL_ID),
                ),
                Slider(
                    id="Temperature",
                    label="Temperature",
                    initial=DEFAULT_TEMPTERATURE,
                    min=0,
                    max=1,
                    step=0.1,
                ),
                Slider(
                    id="MAX_TOKEN_SIZE",
                    label="Max Token Size",
                    initial=DEFAULT_MAX_TOKEN_SIZE,
                    min=256,
                    max=8192,
                    step=256,
                ),
            ]
        ).send()
    return settings


def __is_executive(user=None) -> bool:
    user = user or __current_user()
    if user is None:
        return False
    return user.identifier in os.environ.get("EXECUTIVE_EMAILS", "").split(",")


def __is_admin(user=None) -> bool:
    user = user or __current_user()
    if user is None:
        return False
    return user.identifier in os.environ.get("ADMIN_EMAILS", "").split(",")


def __is_super_admin(user=None) -> bool:
    user = user or __current_user()
    if user is None:
        return False
    return user.identifier in os.environ.get("SUPER_ADMIN_EMAILS", "").split(",")


def __current_user() -> Optional[cl.PersistedUser]:
    return cl.user_session.get("user")


def __is_copilot() -> bool:
    return cl.context.session.client_type == "copilot"
