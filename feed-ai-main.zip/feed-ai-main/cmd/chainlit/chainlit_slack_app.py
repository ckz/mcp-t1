import os
import sys
from typing import Optional

import boto3
import chainlit as cl
import chainlit.data as cl_data
import sentry_sdk as sentry
from chainlit.data.storage_clients.s3 import S3StorageClient
from langchain_core.language_models import BaseChatModel
from langchain_core.messages import HumanMessage
from langgraph.checkpoint.postgres.aio import AsyncPostgresSaver
from langgraph.store.base import BaseStore

from db.chainlit_data_layer import SQLAlchemyDataLayer
from services.bedrock_service import BedrockAIService, BedrockModel

# Add the parent directory to the system path
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "../")))

from cmd.utils.chainlit.multi_modality import create_multi_modality_content

from agents.feed_ai_slack import create_feed_ai_slack_agent
from db.checkpointer import global_checkpointer
from db.database import async_session_maker as db_sessionmaker
from db.memory_store import global_memory_store
from utils.app_stage import get_app_stage
from utils.logging_config import logger

DEFAULT_TEMPTERATURE = 0
DEFAULT_MAX_TOKEN_SIZE = 4096
AWS_REGION_NAME = os.environ["AWS_REGION_NAME"]
PROVIDER = ""

storage_client = S3StorageClient(bucket=os.environ["S3_BUCKET"])
cl_data._data_layer = SQLAlchemyDataLayer(
    async_session=db_sessionmaker,
    storage_provider=storage_client,
    show_logger=True,
)


@cl.on_chat_start
async def main():
    logger.info(f"{get_app_stage()} - Starting Chainlit Slack App")
    if cl.context.session.client_type != "slack":
        return await cl.Message(content="This app is only available for Slack.").send()

    current_user = __current_user()
    if current_user is not None:
        logger.info(f"Chainlit::Starting chat with user {current_user.identifier}")
        sentry.set_user({"email": current_user.identifier})
    logger.info(f"Chainlit Client Type: {cl.context.session.client_type}")
    await __setup_chat_requirements()


async def __setup_chat_requirements():
    bedrock_client = boto3.client(
        service_name="bedrock-runtime",
        region_name=AWS_REGION_NAME,
    )
    cl.user_session.set("bedrock_client", bedrock_client)

    model_id = BedrockModel.PRO_MODEL_ID.value
    llm = BedrockAIService().llm_converse(
        model=model_id,
    )

    global PROVIDER
    PROVIDER = model_id.split(".")[0]

    cl.user_session.set("llm", llm)
    cl.user_session.set("agent", None)


@cl.on_message
async def on_message(message: cl.Message):
    if cl.context.session.client_type != "slack":
        await cl.Message(content="This app is only available for Slack.").send()
        return

    llm = cl.user_session.get("llm")

    if not llm:
        raise ValueError("LLM is not set.")

    async with global_checkpointer.get() as cp, global_memory_store.get() as store:
        try:
            await __handle_message(
                llm=llm, message=message, checkpointer=cp, store=store
            )
        except Exception as e:
            thread_id = cl.context.session.thread_id
            with sentry.new_scope() as scope:
                scope.set_extra("thread_id", thread_id)
                sentry.capture_exception(e)
            logger.error(f"Error in handling message {thread_id}: {e}")
            await cl.Message(
                content=f"An error occurred while processing your message. Please try again. If the issue persists, please contact the dev team with your thread ID: {thread_id}."
            ).send()


async def __handle_message(
    llm: BaseChatModel,
    message: cl.Message,
    checkpointer: AsyncPostgresSaver,
    store: BaseStore,
):
    bedrock_client = cl.user_session.get("bedrock_client")
    if bedrock_client is None:
        raise ValueError("Bedrock client is not set.")

    user = __current_user()
    if user is None:
        raise ValueError("User is not set.")

    content = []
    if len(message.content.strip()) > 0:
        content.append({"type": "text", "text": message.content})

    # Access potential attached files
    attached_files = message.elements
    content.extend(create_multi_modality_content(attached_files, user))

    if len(content) <= 0:
        await cl.Message(content="Please enter a valid message.").send()
        return

    agent = await create_feed_ai_slack_agent(
        user=user,
        llm=llm,
        bedrock_client=bedrock_client,
        checkpointer=checkpointer,
        memory_store=store,
    )
    await agent.ainvoke(HumanMessage(content=content))  # type: ignore


def __current_user() -> Optional[cl.PersistedUser]:
    return cl.user_session.get("user")
