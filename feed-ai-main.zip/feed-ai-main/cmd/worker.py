from __future__ import annotations
import sys
import os

# Add the parent directory to the system path
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '../')))

from contextlib import asynccontextmanager
from typing import AsyncGenerator

import sentry_sdk
from pgqueuer import PgQueuer

from utils.logging_config import logger
from jobs import initialize_job_entrypoints, initialize_job_schedules
from db.pgqueuer import PgQueuerDecorator

async def create_pgqueuer() -> PgQueuer:
    decorator = PgQueuerDecorator()
    pgq = await decorator.create_pgq()
    queries = await decorator.create_queries()

    initialize_job_entrypoints(pgq)
    initialize_job_schedules(pgq=pgq, queries=queries)

    return pgq


@asynccontextmanager
async def main() -> AsyncGenerator[PgQueuer, None]:
    """
    A context manager for setting up and tearing down the PgQueuer instance.

    This function manages the lifecycle of the PgQueuer instance, ensuring proper setup and teardown
    when used in an asynchronous context. It includes the following steps:

    Setup:
        - Logs the start of the setup process.
        - Creates and configures a PgQueuer instance by connecting to the database and initializing
          entrypoints and schedules.

    Teardown:
        - Logs the start of the teardown process.
        - Ensures cleanup actions for the PgQueuer instance, releasing resources like database
          connections.

    Yields:
        PgQueuer: The configured instance ready for processing jobs and schedules.
    """
    logger.info("setup")

    sentry_sdk.init(
        dsn=os.environ.get("SENTRY_DSN"),
        # Set traces_sample_rate to 1.0 to capture 100%
        # of transactions for tracing.
        traces_sample_rate=1.0,
        # Set profiles_sample_rate to 1.0 to profile 100%
        # of sampled transactions.
        # We recommend adjusting this value in production.
        profiles_sample_rate=1.0,
        release=f"worker@{os.environ.get("GITHUB_SHA")}",
    )
    logger.info("Starting the worker service")

    try:
        pgq = await create_pgqueuer()
        yield pgq
    finally:
        logger.info("teardown")
