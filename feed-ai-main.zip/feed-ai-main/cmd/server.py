import os
import sys

from utils.app_stage import enable_db_migration

# Add the parent directory to the system path
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "../")))

from asyncio import CancelledError
from cmd.utils.migration import setup_db_schema
from contextlib import asynccontextmanager

import sentry_sdk
from chainlit.utils import mount_chainlit
from fastapi import FastAPI
from fastapi.responses import RedirectResponse
from fastapi.staticfiles import StaticFiles

import mcp_services.client as mcp_client
from db.qdrant import setup_qdrant_collection
from endpoints import routers

sentry_sdk.init(
    dsn=os.environ.get("SENTRY_DSN"),
    # Set traces_sample_rate to 1.0 to capture 100%
    # of transactions for tracing.
    traces_sample_rate=1.0,
    # Set profiles_sample_rate to 1.0 to profile 100%
    # of sampled transactions.
    # We recommend adjusting this value in production.
    profiles_sample_rate=1.0,
    release=f"web@{os.environ.get('GITHUB_SHA')}",
    ignore_errors=[CancelledError],
)


@asynccontextmanager
async def lifespan(app: FastAPI):
    # Startup: setup code here
    if enable_db_migration():
        await setup_db_schema()
        setup_qdrant_collection()

    # start mcp servers
    mcp_client_instance = mcp_client.create_mcp_client()
    await mcp_client_instance.__aenter__()
    app.state.mcp_client = mcp_client_instance
    app.state.mcp_tools = mcp_client_instance.get_tools()

    yield
    # Shutdown: cleanup code here (if any)
    await app.state.mcp_client.__aexit__(None, None, None)


# Create the FastAPI app
app = FastAPI(lifespan=lifespan)
mcp_client.initialize_app_reference(app)


@app.get("/", response_class=RedirectResponse)
async def root():
    return "/chat"


for router in routers:
    app.include_router(router)

app.mount("/assets", StaticFiles(directory="public"), name="assets")
mount_chainlit(app=app, target="cmd/chainlit/chainlit_app.py", path="/chat")
