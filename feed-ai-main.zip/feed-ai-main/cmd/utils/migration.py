import sentry_sdk
from db.checkpointer import global_checkpointer
from db.memory_store import global_memory_store
from utils.logging_config import logger

async def setup_db_schema():
    logger.info("Setting up database schema")
    try:
        await __setup_checkpointer()
        await __setup_memory_store()
        logger.info("Database schema setup complete")
    except Exception as e:
        logger.error(f"Error setting up database schema: {e}")
        sentry_sdk.capture_exception(e)

async def __setup_checkpointer():
    async with global_checkpointer.get() as cp:
        await cp.setup()

async def __setup_memory_store():
    async with global_memory_store.get() as store:
        await store.setup()
