from chainlit.user import PersistedUser
from chainlit.element import Element
import re
import mimetypes
import base64
from typing import Sequence

from utils.feature_flag import FeatureFlag
from utils.logging_config import logger

def create_multi_modality_content(elements: Sequence[Element], user: PersistedUser):
    content = []
    for element in elements:
        file = File(element, user)
        if image_content := file.get_image_content():
            content.append(image_content)
        if document_content := file.get_document_content():
            content.extend(document_content)
        if text_content := file.get_text_content():
            content.extend(text_content)

    return content

class File:
    def __init__(self, file: Element, user: PersistedUser):
        self.user = user
        self.file = file
        self.mime_type, _ = mimetypes.guess_type(file.name)
        if self.mime_type is None:
            self.mime_type = file.mime
        self.feature_flag = FeatureFlag()
        logger.info(f"File: {file.name}, mime_type: {self.mime_type}")

    def get_image_content(self):
        if not self.feature_flag.is_enabled("image_upload", self.user.identifier):
            return None

        if not self.__is_image():
            return None

        return {
            "type": "image_url",
            "image_url": f"data:{self.mime_type};base64,{self.__base64()}"
        }

    def get_document_content(self):
        if not self.feature_flag.is_enabled("document_upload", self.user.identifier):
            return None
        if not self.__is_document():
            return None

        return [
            {
                "type": "text",
                "text": f"Document: {self.__sanitize_filename(self.file.name)}",
            },
            {
                "type": "image_url",
                "image_url": f"data:{self.mime_type};base64,{self.__base64()}"
            }
        ]

    def get_text_content(self):
        if not self.feature_flag.is_enabled("document_upload", self.user.identifier):
            return None
        if not self.__is_text():
            return None

        return [
            {
                "type": "text",
                "text": f"Document: {self.__sanitize_filename(self.file.name)}",
            },
            {
                "type": "image_url",
                "image_url": f"data:{self.mime_type};base64,{self.__base64()}"
            }
        ]

    def __base64(self):
        return base64.b64encode(self.__read()).decode("utf-8")

    def __read(self):
        if not self.file.path:
            raise ValueError("File path is not set")

        with open(self.file.path, "rb") as f:
            return f.read()

    def __is_image(self):
        return self.mime_type and self.mime_type.startswith("image")

    def __is_text(self):
        return self.mime_type and self.mime_type.startswith("text")

    def __is_document(self):
        # "pdf", "csv", "doc", "docx", "xls", "xlsx"
        return self.mime_type and self.mime_type in ["application/pdf", "text/csv", "application/msword", "application/vnd.openxmlformats-officedocument.wordprocessingml.document", "application/vnd.ms-excel",  "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"]

    def __sanitize_filename(self, filename):
        # Only allow alphanumeric, whitespace, hyphens, parentheses, and square brackets
        name = re.sub(r'[^a-zA-Z0-9\s\-\(\)\[\]]', '', filename)
        # Replace multiple consecutive whitespaces with a single space
        name = re.sub(r'\s+', ' ', name)
        # Remove leading/trailing whitespace
        name = name.strip()
        # Ensure the name is not empty after sanitization
        return name if name else 'untitled'

