from fastapi import APIRouter
from typing import Dict, Any

router = APIRouter(prefix="/healthz", tags=["health"])

@router.get("")
async def healthz() -> Dict[str, Any]:
    return {"ok": True}
