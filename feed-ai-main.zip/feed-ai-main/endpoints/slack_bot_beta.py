from fastapi import APIRouter
from fastapi.requests import Request

from services.slack_app.handler import slack_app_handler

router = APIRouter(prefix="", tags=["slack_bot"])


@router.post("/beta/slack/events")
async def slack_endpoint(req: Request):
    return await slack_app_handler.handle(req)
