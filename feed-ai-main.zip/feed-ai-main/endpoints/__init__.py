from .healthz import router as healthz_router
from .slack import router as slack_router
from .internal_api import router as internal_api_router
from .copilot import router as copilot_router
from .scheduled_task import router as scheduled_task_router

routers = [
    healthz_router,
    slack_router,
    internal_api_router,
    copilot_router,
    scheduled_task_router
]
