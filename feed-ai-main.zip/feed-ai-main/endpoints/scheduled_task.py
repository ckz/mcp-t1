from fastapi import APIRouter, Depends, Request
from fastapi.templating import Jinja2Templates
from fastapi.responses import HTMLResponse
from typing import Dict, Any
from sqlalchemy.ext.asyncio import AsyncSession
from db.pgqueuer import PgQueuerDecorator
from models.scheduled_task import ScheduledTask, ScheduledTaskRepo
from models.user import User, UserRepo
from db.database import get_async_session
from utils.slack import get_user_email
from jobs.send_slack_notification_job import SendSlackNotificationJobPayload

router = APIRouter(prefix="/scheduled_tasks")

templates = Jinja2Templates(directory="templates/scheduled_task")

@router.get("/disable/{token}", response_class=HTMLResponse)
async def disable_task_page(
    request: Request,
    token: str,
    session: AsyncSession = Depends(get_async_session)
):
    repo = ScheduledTaskRepo(session)
    task = await repo.get_task_by_disable_token(token)

    if not task:
        return templates.TemplateResponse(
            "disable_task.html",
            {"request": request, "error": "Task not found"}
        )

    return templates.TemplateResponse(
        "disable_task.html",
        {"request": request, "task": task, "token": token}
    )

@router.post("/disable/{token}")
async def disable_task(
    token: str,
    session: AsyncSession = Depends(get_async_session)
) -> Dict[str, Any]:
    repo = ScheduledTaskRepo(session)
    task = await repo.get_task_by_disable_token(token)
    if task:
        await repo.disable_task(token)
        user = await UserRepo(session).get_user_by_id(str(task.user_id))
        if user:
            await __send_slack_notification(user, task)
        return {"message": "Task disabled successfully"}
    else:
        return {"error": "Invalid Request"}

async def __send_slack_notification(user: User, task: ScheduledTask):
    email = get_user_email(user.identifier)
    queries = await PgQueuerDecorator().create_queries()
    # send_slack_notification
    payload = SendSlackNotificationJobPayload(
        slack_channel_id=None,
        slack_thread_id=task.slack_thread_ts,
        slack_message=f":white_check_mark: Your task {task.name} has been disabled. Please create a new task if you want to use it again.",
        user_email=email,
        app_stage=task.app_stage,
    )
    await queries.enqueue(
        entrypoint="send_slack_notification",
        payload=payload.serialize()
    )
