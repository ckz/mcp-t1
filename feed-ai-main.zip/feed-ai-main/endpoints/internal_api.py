import os
from fastapi import APIRouter, Depends
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from fastapi.responses import JSONResponse
from sqlalchemy.ext.asyncio import AsyncSession
from typing import Dict, Any, Annotated
from pydantic import BaseModel

from db.database import get_async_session
from models.sync_status import SourceType
from services.record_sync_status_service import RecordSyncStatusService

router = APIRouter(prefix="/api/internal", tags=["internal_api"])
security = HTTPBearer()
INTERNAL_API_TOKEN = os.environ.get("INTERNAL_API_TOKEN")

class RecordSyncStatusRequest(BaseModel):
    source: SourceType
    payload: Dict[str, Any] = {}

# curl -X POST http://localhost:8081/api/internal/record_sync_status \
#        -H "Authorization: Bearer supersecret" \
#        -H "Content-Type: application/json" \
#        -d '{"source": "hubspot", "payload": {}}'
@router.post("/record_sync_status")
async def record_sync_status(
        credentials: Annotated[HTTPAuthorizationCredentials, Depends(security)],
        request: RecordSyncStatusRequest,
        session: AsyncSession = Depends(get_async_session)) -> JSONResponse:
    if credentials.scheme != "Bearer" or credentials.credentials != INTERNAL_API_TOKEN:
        return JSONResponse(status_code=401, content={"ok": False, "error": "Invalid credentials"})

    await RecordSyncStatusService(session).record_sync_status(
        source=request.source,
        payload=request.payload
    )
    return JSONResponse(status_code=200, content={"ok": True})
