from fastapi import APIRouter, Depends
from fastapi.responses import HTMLResponse
from chainlit.auth import create_jwt, get_current_user
from chainlit.user import PersistedUser, User
from typing_extensions import Annotated
from typing import Any, Union, Dict
from utils.logging_config import logger

router = APIRouter(prefix="/chat/copilot", tags=["copilot"])

@router.get("/index", response_class=HTMLResponse)
async def copilot_home() -> str:
    html = """
<!doctype html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>FeedMob AI</title>
    <style>
      /* Set the dimensions of the popup */
      html, body {
        margin: 0;
        padding: 0;
        width: 350px; /* Desired width */
        height: 1000px; /* Desired height */
        overflow: hidden;
      }
    </style>
  </head>
  <body>
     <script src="/chat/copilot/index.js"></script>
     <script src="/chat/public/copilot.js?version=v1"></script>
  </body>
</html>
    """
    return html

@router.get("/access_token", response_class=HTMLResponse)
async def copilot_access_token() -> str:
    html = """
        <center>
            <h1>Copilot Access Token</h1>
            <p>Click the button below to copy the access token</p>
            <h3>Identifer</h3>
            <p><b id="identifier"></b></p>
            <h3>Access Token</h3>
            <textarea id="access_token" rows="5" cols="50"></textarea>
            <br>
            <button id="copy">Copy Token</button>
        </center>
        <script>
            document.getElementById("access_token").readOnly = true
            fetch("/chat/copilot/access_token", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    "Authorization": `Bearer ${localStorage.getItem("token")}`
                }
            }).then(response => {
                if (response.status === 401) {
                    alert("Unauthorized access. Please login to access this page")
                    window.location.href = "/chat/login"
                }
                if (!response.ok) {
                    throw new Error("Failed to generate access token")
                }
                return response.json()
            }).then(data => {
                document.getElementById("identifier").innerText = data.identifier
                document.getElementById("access_token").value = data.access_token
                document.getElementById("copy").onclick = () => {
                    document.getElementById("access_token").select()
                    setTimeout(() => {
                        navigator.clipboard.writeText(document.getElementById('access_token').value)
                        alert("Copied to clipboard")
                    }, 100)
                }
            }).catch(error => {
                console.error("Error:", error)
            })
        </script>
    """
    return html

@router.post("/access_token", response_model=Dict[str, Any])
async def generate_copilot_access_token(current_user: Annotated[Union[User, PersistedUser], Depends(get_current_user)]) -> Dict[str, Any]:
    identifier = current_user.identifier
    logger.info(f"Generating access token for {identifier}")
    access_token = create_jwt(User(identifier=identifier, metadata={"client_type": "copilot"}))
    return {"access_token": access_token, "identifier": identifier}

@router.post("/validate_access_token")
async def validate_access_token(_current_user: Annotated[Union[User, PersistedUser], Depends(get_current_user)]) -> None:
    pass
