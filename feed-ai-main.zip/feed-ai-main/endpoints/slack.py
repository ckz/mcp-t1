import uuid
from fastapi import APIRouter, Depends
from fastapi.responses import HTMLResponse
from typing import Dict, Any
from sqlalchemy.ext.asyncio import AsyncSession
from services.slack_auth_service import SlackAuthService
from db.database import get_async_session
from models.slack_credential import SlackCredentialRepo, SlackCredential

router = APIRouter(prefix="/auth/oauth/slack", tags=["slack"])

@router.get("", response_class=HTMLResponse)
async def slack_oauth() -> str:
    html = """
    <center>
        <a href="https://slack.com/oauth/v2/authorize?client_id=18928954435.7236829281989&scope=channels:history,groups:history,im:history,mpim:history,users:read,channels:read,groups:read&user_scope="><img alt="Add to Slack" height="40" width="139" src="https://platform.slack-edge.com/img/add_to_slack.png" srcSet="https://platform.slack-edge.com/img/add_to_slack.png 1x, https://platform.slack-edge.com/img/add_to_slack@2x.png 2x" /></a>
    </center>
    """
    return html

@router.get("/authorize")
async def slack_oauth_callback(
    code: str,
    session: AsyncSession = Depends(get_async_session)
) -> Dict[str, Any]:
    service = SlackAuthService()
    access_info = service.get_oauth_acess(code)

    if not access_info:
        return {"error": "Failed to fetch Slack OAuth access"}

    repo = SlackCredentialRepo(session)
    slack_credential = await repo.find_by_team_id_and_app_id(access_info.team_id, access_info.app_id)
    if slack_credential:
        slack_credential.authed_user_id = access_info.authed_user_id
        slack_credential.scope = access_info.scope
        slack_credential.token_type = access_info.token_type
        slack_credential.access_token = access_info.access_token
        slack_credential.bot_user_id = access_info.bot_user_id
        slack_credential.team_name = access_info.team_name
        await repo.update(slack_credential)
    else:
        slack_credential = SlackCredential(
            id=uuid.uuid4(),
            app_id=access_info.app_id,
            authed_user_id=access_info.authed_user_id,
            scope=access_info.scope,
            token_type=access_info.token_type,
            access_token=access_info.access_token,
            bot_user_id=access_info.bot_user_id,
            team_id=access_info.team_id,
            team_name=access_info.team_name
        )
        await repo.create(slack_credential)

    return {"ok": True}
