# FeedMob AI Chatbot powered by Amazon Bedrock 🚀🤖

## AI

### Models
The default value is Claude v3 Sonnet (`anthropic.claude-3-5-sonnet-20241022-v2:0`).

### Parameters
**Temperature:** Default: 0.3
**Max Token Size:** Default: 2048

## Slack

## Add Slack Bot `Slack to GPT` to your workspace

- https://claude.feedmob.com/auth/oauth/slack
