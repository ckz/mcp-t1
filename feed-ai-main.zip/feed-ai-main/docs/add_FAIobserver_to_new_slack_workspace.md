# Add FAIobserver to a new Slack workspace

> **FAIobserver** is a Slack bot that helps you pull slack messages and store them in a database. This document will guide you on how to add FAIobserver to a new Slack workspace.

## Add FAIobserver to a new Slack workspace

- Visit the [FAIobserver Slack OAuth](https://claude.feedmob.com/auth/oauth/slack) page.
- Click on the `Add to Slack` button.

![Add to Slack](./assets/FAIobserver__add-to-slack-button.png)

- Select the workspace you want to add FAIobserver to.

![Select Workspace](./assets/FAIobserver__select-a-workspace-to-add-to.png)

- Click on the `Allow` button to grant FAIobserver the necessary permissions.

![Allow](./assets/FAIobserver__click-on-allow-button.png)

## Add FAIobserver to a channel

- Once you have added FAIobserver to your workspace, you can invite it to a channel by typing the following command in the channel:

```text
/invite @FAIobserver
```

## References

- [FAIobserver Slack OAuth](https://claude.feedmob.com/auth/oauth/slack)
- Github Issue: https://github.com/feed-mob/tracking_admin/issues/18265
