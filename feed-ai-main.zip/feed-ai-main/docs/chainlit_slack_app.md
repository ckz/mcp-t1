# Make AI Chatbot available on Slack

> - [Github Ticket](https://github.com/feed-mob/tracking_admin/issues/18465)
> - [Chainlit docs](https://docs.chainlit.io/deploy/slack)

## Description

This document describes the steps to make the AI Chatbot available on Slack.

## Development

### Testing Slack App

- The testing Slack App is available at [Feed AI Dev Testing](https://api.slack.com/apps/A086M032EBT/general)
- The testing Slack App name is `Feed AI Dev Testing`
- You could update the request URL to point to the local server at [app-manifest](https://app.slack.com/app-settings/T0JTAU2CT/A086M032EBT/app-manifest)

### Run your local server

- Run the local server using the command `just just run-slack-app`
- Expose the local server to the internet using ngrok `ngrok http 8000`
- Update the request URL in the Slack App to point to the ngrok URL at [app-manifest](https://app.slack.com/app-settings/T0JTAU2CT/A086M032EBT/app-manifest)

## Crate a new Slack App

- Follow the steps in the [Chainlit Docs](https://docs.chainlit.io/deploy/slack) to create a new Slack App

```yaml

display_information:
  name: { APP_NAME }
features:
  app_home:
    home_tab_enabled: false
    messages_tab_enabled: true
    messages_tab_read_only_enabled: false
  bot_user:
    name: { APP_NAME }
    always_online: true
  shortcuts:
    - name: Create Scheduled Task
      type: global
      callback_id: create_scheduled_task
      description: FeedAI will schedule and automate recurring tasks according to your specified timing
  assistant_view:
    assistant_description: { ASSISTANT_DESCRIPTION }
    suggested_prompts: []
oauth_config:
  scopes:
    user:
      - im:history
      - channels:history
    bot:
      - app_mentions:read
      - channels:read
      - chat:write
      - files:read
      - files:write
      - im:history
      - im:read
      - im:write
      - users:read
      - users:read.email
      - channels:history
      - groups:history
      - reactions:write
      - assistant:write
      - commands
settings:
  event_subscriptions:
    request_url: https://{ CHAINLIT_APP_HOST }/slack/events
    bot_events:
      - app_home_opened
      - app_mention
      - assistant_thread_context_changed
      - assistant_thread_started
      - message.im
  interactivity:
    is_enabled: true
    request_url: https://{ CHAINLIT_APP_HOST }/slack/events
  org_deploy_enabled: false
  socket_mode_enabled: false
  token_rotation_enabled: false
```
