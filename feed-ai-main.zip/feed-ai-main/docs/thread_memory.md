# FeedAI - Understanding AI Conversation Context in Slack Threads (aka Thread Memory)

The FeedAI's memory is limited to individual Slack threads. This means:

- The AI maintains context within the same thread where it was initiated
- Each thread has its own separate conversation history
- Starting a new thread creates a fresh conversation context
- Previous thread conversations are not accessible in new threads

Let me give you an example to illustrate how thread-level memory works:

- First, I will initiate a conversation with AI in a brand new slack thread

```text
Hey, my name is Richard. Please tell me what you can do.
```

- Then I will ask the AI if it remembers my name in the same thread

```text
Do you know my name?
```

- The AI will respond with the name I provided earlier
- Now, I will start a new thread and ask the AI if it remembers my name

```text
Hey, Do you know my name?
```

- The AI will not remember my name because it is a new thread

For more information, you can refer to the [Google Document](https://docs.google.com/document/d/1LPzs5sTSvaUlGqaXdFI2bz2g8T99KhPbejxlZNsyFao/edit?tab=t.0#heading=h.r3ybk2fe7c2y).
