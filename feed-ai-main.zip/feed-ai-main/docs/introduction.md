# FeedMob AI (Claude) - Introduction

Created By: Richard Hao
Last Edited: December 24, 2024 3:28 PM

- Github Repo: https://github.com/feed-mob/bedrock-ai-chatbot
- Starting to pull new Slack workspace: [https://claude.feedmob.com/auth/oauth/slack](https://claude.feedmob.com/auth/oauth/slack)
- AI Chatbot: https://claude.feedmob.com/chat/
    - **FeedMob AI**: Integrated with Slack Messages, Hubspot tickets, Basic Billing Info, etc.
        - All FeedMob Users have the access.
    - **Chat**: Chat with the **Claude 3.5 Sonnet** model.
        - All FeedMob Users have the access.
    - **Hubspot Ticket**: Answer questions from Hubspot tickets.
        - A few users from the Dev team have access.
        - 用来验证 FeedMob AI 的功能
    - **Slack**: Answer questions from Slack messages.
        - A few users from the Dev team have access.
        - 用来验证 FeedMob AI 的功能
    - **Bedrock AI Chatbot Database**: Query the Bedrock AI Chatbot database.
        - A few users from the Dev team have access.
        - FeedMob AI 项目的数据库，可以通过和 AI 聊天来查询数据 （如用户的使用情况)
    - **Time-off Database:** Query the Time-off database**.**
        - A few users from the Dev team have access.
        - 连接了 [https://time-off.feedmob.com/](https://time-off.feedmob.com/reports) 的数据库，可以查询工作日志，工作总结，事故报告等情况
    - **Export Slack Messages**: Export Slack Messages and email them to the users.
        - A few users from the Dev team have access.
        - 导出 Slack 消息，目前主要提供给 Summer 使用
    - **FeedMob AI V2**:
        - Only Richard has access.
        - 实验性的，再尝试不同的实现方式
- Chrome Extension: [https://github.com/feed-mob/feedmob/issues/12128#issuecomment-2514128975](https://github.com/feed-mob/feedmob/issues/12128#issuecomment-2514128975)
- **FeedMob AI (Claude) - Make AI Chatbot available on Slack**  [https://github.com/feed-mob/tracking_admin/issues/18465](https://github.com/feed-mob/tracking_admin/issues/18465)
    - 目前正在开发中
- 其他计划要做的事情：[https://github.com/feed-mob/bedrock-ai-chatbot/issues](https://github.com/feed-mob/bedrock-ai-chatbot/issues)
