## Scheduled Tasks

```mermaid
graph TB
    %% Create Task Flow
    subgraph "Create Task Flow"
    U[User] -->|Uses Slack shortcut| S[Create Scheduled Task]
    S -->|Input| F[Schedule + Instructions Form]
    F -->|Submit| B[FeedAI Backend]
    B -->|Creates task| D[(Database)]
    B -->|Sends preview| P[Preview Message]
    P --> U
    end

    %% Cancel Task Flow
    subgraph "Cancel Task Flow"
    U2[User] -->|Clicks cancel URL| C[Cancel Request]
    C --> B2[FeedAI Backend]
    B2 -->|Removes task| D
    end

    %% Periodic Execution Flow
    subgraph "Periodic Execution Loop"
    direction TB
    D -->|Read tasks| E[Task Executor]
    E -->|Execute task| M[Generate Message]
    M -->|Send to Slack| U3[User]
    E -->|Schedule next run| E
    end

    style U fill:#f9f,stroke:#333,stroke-width:2px
    style U2 fill:#f9f,stroke:#333,stroke-width:2px
    style U3 fill:#f9f,stroke:#333,stroke-width:2px
    style D fill:#bbf,stroke:#333,stroke-width:2px
```
